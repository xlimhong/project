<?php
// 1. Start session to access existing session data
session_start();

// 2. Clear all session variables array
$_SESSION = array();

// 3. Delete the session cookie in the browser
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(), 
        '', 
        time() - 42000,
        $params["path"], 
        $params["domain"],
        $params["secure"], 
        $params["httponly"]
    );
}

// 4. Destroy the session on the server
session_destroy();

// 5. Instruct browser not to cache this redirect
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

// 6. Redirect to login page
header("Location: index.php");
exit();
?>