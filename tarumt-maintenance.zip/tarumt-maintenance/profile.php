<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'config/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$message = '';

// Auto-add 'phone' column if missing from users table
try {
    $pdo->exec("ALTER TABLE users ADD COLUMN phone VARCHAR(20) NULL");
} catch (PDOException $e) {
    // Column already exists or table structure is fine
}

// Handle Profile Update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');

    if (!empty($name) && !empty($email)) {
        try {
            $stmt = $pdo->prepare("UPDATE users SET name = ?, email = ?, phone = ? WHERE id = ?");
            $stmt->execute([$name, $email, $phone, $user_id]);
            $_SESSION['name'] = $name;
            $message = "<div class='alert success'>Profile updated successfully!</div>";
        } catch (PDOException $e) {
            $message = "<div class='alert error'>Update failed: " . htmlspecialchars($e->getMessage()) . "</div>";
        }
    } else {
        $message = "<div class='alert error'>Name and Email are required fields.</div>";
    }
}

// Fetch current user details safely
try {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $user = [];
}
?>

<?php include 'includes/header.php'; ?>

<div class="container-centered" style="max-width: 600px;">
    <div class="card" style="padding: 2rem;">
        <div class="card-header" style="padding: 0 0 1rem 0; margin-bottom: 1.5rem;">
            <h2>User Profile</h2>
        </div>

        <?= $message; ?>

        <form action="profile.php" method="POST">
            <div class="form-group">
                <label for="name">Full Name</label>
                <input type="text" id="name" name="name" value="<?= htmlspecialchars($user['name'] ?? $_SESSION['name'] ?? ''); ?>" required>
            </div>

            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" id="email" name="email" value="<?= htmlspecialchars($user['email'] ?? ''); ?>" required>
            </div>

            <div class="form-group">
                <label for="phone">Phone Number</label>
                <input type="text" id="phone" name="phone" placeholder="e.g. +60123456789" value="<?= htmlspecialchars($user['phone'] ?? ''); ?>">
            </div>

            <div class="form-group">
                <label>System Role</label>
                <input type="text" value="<?= strtoupper(htmlspecialchars($_SESSION['role'] ?? 'STUDENT')); ?>" disabled style="background: #f1f5f9; cursor: not-allowed;">
            </div>

            <div style="margin-top: 1.5rem; display: flex; gap: 1rem;">
                <button type="submit" class="btn">Save Changes</button>
                <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
            </div>
        </form>
    </div>
</div>

<?php include 'includes/footer.php'; ?>