<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/db.php';
require_once 'includes/helpers.php';

require_auth();

// Ensure required database tables and columns exist
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS maintenance_requests (
        id INT AUTO_INCREMENT PRIMARY KEY,
        ticket_no VARCHAR(50) NULL,
        user_id INT NOT NULL,
        block_location VARCHAR(255) NULL,
        room_number VARCHAR(100) NULL,
        location VARCHAR(255) NULL,
        category VARCHAR(100) NOT NULL,
        description TEXT NULL,
        priority VARCHAR(50) DEFAULT 'Medium',
        status VARCHAR(50) DEFAULT 'Pending',
        attachment VARCHAR(255) NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS notifications (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NULL,
        role VARCHAR(50) NULL,
        title VARCHAR(255) NOT NULL,
        message TEXT NOT NULL,
        type VARCHAR(50) DEFAULT 'info',
        is_read TINYINT(1) DEFAULT 0,
        link VARCHAR(255) DEFAULT 'dashboard.php',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");

    // Add missing columns if legacy maintenance_requests table exists
    $columns = $pdo->query("SHOW COLUMNS FROM maintenance_requests")->fetchAll(PDO::FETCH_COLUMN);
    if (!in_array('ticket_no', $columns)) {
        $pdo->exec("ALTER TABLE maintenance_requests ADD COLUMN ticket_no VARCHAR(50) NULL");
    }
    if (!in_array('block_location', $columns)) {
        $pdo->exec("ALTER TABLE maintenance_requests ADD COLUMN block_location VARCHAR(255) NULL");
    }
    if (!in_array('room_number', $columns)) {
        $pdo->exec("ALTER TABLE maintenance_requests ADD COLUMN room_number VARCHAR(100) NULL");
    }
    if (!in_array('location', $columns)) {
        $pdo->exec("ALTER TABLE maintenance_requests ADD COLUMN location VARCHAR(255) NULL");
    }
    if (!in_array('attachment', $columns)) {
        $pdo->exec("ALTER TABLE maintenance_requests ADD COLUMN attachment VARCHAR(255) NULL");
    }

    // Add missing 'link' column if legacy notifications table exists
    $notifColumns = $pdo->query("SHOW COLUMNS FROM notifications")->fetchAll(PDO::FETCH_COLUMN);
    if (!in_array('link', $notifColumns)) {
        $pdo->exec("ALTER TABLE notifications ADD COLUMN link VARCHAR(255) DEFAULT 'dashboard.php'");
    }
    if (!in_array('role', $notifColumns)) {
        $pdo->exec("ALTER TABLE notifications ADD COLUMN role VARCHAR(50) NULL");
    }
} catch (PDOException $e) {
    die("Database initialization failed: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $block       = trim($_POST['block_location'] ?? '');
    $room        = trim($_POST['room_number'] ?? '');
    $category    = $_POST['category'] ?? 'Other';
    $priority    = $_POST['priority'] ?? 'Medium';
    $description = trim($_POST['description'] ?? '');
    $user_id     = $_SESSION['user_id'];
    $ticket_no   = 'TKT-' . date('Ymd') . '-' . rand(1000, 9999);

    // Combine into location for Dashboard & History view compatibility
    $full_location = trim($block . ($room ? " - {$room}" : ''));

    // Handle File Upload
    $attachment_path = null;
    if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath   = $_FILES['attachment']['tmp_name'];
        $fileName      = $_FILES['attachment']['name'];
        $fileSize      = $_FILES['attachment']['size'];
        $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

        $allowedExtensions = ['jpg', 'jpeg', 'png', 'webp'];
        $maxFileSize       = 5 * 1024 * 1024; // 5MB limit

        if (in_array($fileExtension, $allowedExtensions) && $fileSize <= $maxFileSize) {
            $newFileName = 'ticket_' . time() . '_' . rand(1000, 9999) . '.' . $fileExtension;
            $uploadDir   = 'uploads/';

            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }

            $destination = $uploadDir . $newFileName;
            if (move_uploaded_file($fileTmpPath, $destination)) {
                $attachment_path = $destination;
            }
        }
    }

    if (!empty($block) && !empty($description)) {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO maintenance_requests 
                (ticket_no, user_id, block_location, room_number, location, category, priority, description, status, attachment) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Pending', ?)
            ");
            $stmt->execute([$ticket_no, $user_id, $block, $room, $full_location, $category, $priority, $description, $attachment_path]);

            // 1. Notify technicians about the new request
            $notifType = ($priority === 'Emergency') ? 'danger' : 'info';
            create_notification(
                $pdo,
                "New Request: {$ticket_no}",
                "A new {$priority} priority {$category} request was submitted for {$full_location}.",
                $notifType,
                'work_orders.php',
                null,
                'technician'
            );

            // 2. Send confirmation notification to the user
            create_notification(
                $pdo,
                "Ticket Submitted",
                "Your request {$ticket_no} has been received and is pending review.",
                'success',
                'history.php',
                $user_id,
                null
            );

            set_flash('success', "Ticket <strong>{$ticket_no}</strong> submitted successfully! <a href='dashboard.php'>View on Dashboard</a>");
            header("Location: submit_request.php");
            exit();
        } catch (PDOException $e) {
            set_flash('error', "Database Error: " . $e->getMessage());
        }
    } else {
        set_flash('error', "Please fill in all required fields.");
    }
}

// Preview ticket number shown on the stub before submission
$preview_ticket = 'TKT-' . date('Ymd') . '-' . str_pad((string) rand(0, 9999), 4, '0', STR_PAD_LEFT);
$today_display  = date('d M Y');
?>

<?php include 'includes/header.php'; ?>

<style>
    .wo-wrap {
        max-width: 720px;
        margin: 0 auto;
    }

    .wo-slip {
        background: #fff;
        border: 1px solid #dcdfe3;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 1px 2px rgba(20, 24, 30, 0.04);
    }

    .wo-stub {
        background: #1E2A35;
        color: #F3F1EC;
        padding: 1.5rem 2rem;
        display: flex;
        justify-content: space-between;
        align-items: flex-end;
        gap: 1rem;
        flex-wrap: wrap;
        position: relative;
    }

    .wo-stub::after {
        content: "";
        position: absolute;
        left: 0;
        right: 0;
        bottom: -1px;
        height: 1px;
        background-image: repeating-linear-gradient(90deg, rgba(255,255,255,0.35) 0 10px, transparent 10px 18px);
    }

    .wo-stub-title h2 {
        margin: 0 0 0.35rem 0;
        font-size: 1.35rem;
        font-weight: 700;
        color: #fff;
    }

    .wo-stub-title p {
        margin: 0;
        font-size: 0.85rem;
        color: #AEB8C2;
        max-width: 34ch;
    }

    .wo-stub-meta {
        text-align: right;
    }

    .wo-stub-meta .wo-ticket-no {
        font-family: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, monospace;
        font-size: 1rem;
        letter-spacing: 0.02em;
        color: #F3C969;
    }

    .wo-stub-meta .wo-date {
        display: block;
        font-size: 0.78rem;
        color: #AEB8C2;
        margin-top: 0.2rem;
    }

    .wo-body {
        padding: 2rem;
    }

    .wo-flash {
        margin-bottom: 1.25rem;
    }

    .wo-section {
        margin-bottom: 1.75rem;
    }

    .wo-section:last-of-type {
        margin-bottom: 0;
    }

    .wo-section-title {
        font-size: 0.95rem;
        font-weight: 700;
        color: #1E2A35;
        margin: 0 0 0.85rem 0;
        padding-bottom: 0.5rem;
        border-bottom: 1px solid #ECEEF1;
    }

    .wo-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 1rem;
    }

    .wo-field {
        margin-bottom: 1rem;
    }

    .wo-field:last-child {
        margin-bottom: 0;
    }

    .wo-field label {
        display: block;
        font-size: 0.82rem;
        font-weight: 600;
        color: #465063;
        margin-bottom: 0.4rem;
    }

    .wo-field input[type="text"],
    .wo-field select,
    .wo-field textarea {
        width: 100%;
        border: 1px solid #D3D8DE;
        border-radius: 7px;
        padding: 0.6rem 0.75rem;
        font-size: 0.92rem;
        color: #1E2A35;
        background: #FBFBFA;
        transition: border-color 0.15s ease, box-shadow 0.15s ease;
    }

    .wo-field input[type="text"]:focus,
    .wo-field select:focus,
    .wo-field textarea:focus {
        outline: none;
        border-color: #1E2A35;
        box-shadow: 0 0 0 3px rgba(30, 42, 53, 0.1);
        background: #fff;
    }

    .wo-field textarea {
        resize: vertical;
        min-height: 100px;
        line-height: 1.5;
    }

    .wo-priority {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 0.5rem;
    }

    .wo-priority input {
        position: absolute;
        opacity: 0;
        pointer-events: none;
    }

    .wo-priority label {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0.4rem;
        margin: 0;
        padding: 0.55rem 0.4rem;
        border: 1px solid #D3D8DE;
        border-radius: 7px;
        font-size: 0.82rem;
        font-weight: 600;
        color: #5B6472;
        background: #FBFBFA;
        cursor: pointer;
        transition: all 0.15s ease;
        text-align: center;
    }

    .wo-priority label .dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: currentColor;
        flex-shrink: 0;
    }

    .wo-priority input:checked + label {
        border-color: transparent;
        color: #fff;
    }

    .wo-priority .p-low input:checked + label { background: #6B7684; }
    .wo-priority .p-medium input:checked + label { background: #35506B; }
    .wo-priority .p-high input:checked + label { background: #B5762A; }
    .wo-priority .p-emergency input:checked + label { background: #B4432F; }

    .wo-priority label:hover {
        border-color: #AEB8C2;
    }

    .wo-drop {
        border: 1.5px dashed #C6CCD3;
        border-radius: 9px;
        padding: 1.5rem;
        text-align: center;
        background: #FBFBFA;
        cursor: pointer;
        transition: border-color 0.15s ease, background 0.15s ease;
        position: relative;
    }

    .wo-drop:hover,
    .wo-drop.is-dragover {
        border-color: #35506B;
        background: #F2F5F8;
    }

    .wo-drop input[type="file"] {
        position: absolute;
        inset: 0;
        opacity: 0;
        cursor: pointer;
    }

    .wo-drop-icon {
        font-size: 1.4rem;
        color: #8A93A0;
        margin-bottom: 0.4rem;
    }

    .wo-drop-text {
        font-size: 0.85rem;
        color: #5B6472;
        margin: 0;
    }

    .wo-drop-hint {
        font-size: 0.75rem;
        color: #9AA3AF;
        margin: 0.2rem 0 0 0;
    }

    .wo-drop-filename {
        display: none;
        margin-top: 0.6rem;
        font-size: 0.82rem;
        font-weight: 600;
        color: #1E2A35;
    }

    .wo-drop-filename.is-visible {
        display: inline-flex;
        align-items: center;
        gap: 0.4rem;
    }

    .wo-actions {
        display: flex;
        gap: 0.75rem;
        margin-top: 2rem;
        padding-top: 1.5rem;
        border-top: 1px solid #ECEEF1;
    }

    .wo-btn-submit {
        background: #1E2A35;
        color: #fff;
        border: none;
        padding: 0.7rem 1.5rem;
        border-radius: 7px;
        font-size: 0.92rem;
        font-weight: 600;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        transition: background 0.15s ease;
    }

    .wo-btn-submit:hover {
        background: #16202A;
    }

    .wo-btn-cancel {
        background: transparent;
        color: #5B6472;
        border: 1px solid #D3D8DE;
        padding: 0.7rem 1.25rem;
        border-radius: 7px;
        font-size: 0.92rem;
        font-weight: 600;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
    }

    .wo-btn-cancel:hover {
        border-color: #AEB8C2;
        color: #1E2A35;
    }

    @media (max-width: 560px) {
        .wo-row { grid-template-columns: 1fr; }
        .wo-priority { grid-template-columns: repeat(2, 1fr); }
        .wo-stub { padding: 1.25rem 1.25rem; }
        .wo-stub-meta { text-align: left; }
        .wo-body { padding: 1.25rem; }
    }
</style>

<div class="wo-wrap">
    <div class="wo-slip">
        <div class="wo-stub">
            <div class="wo-stub-title">
                <h2>Submit Maintenance Ticket</h2>
                <p>Report a facilities issue and route it to the right crew.</p>
            </div>
            <div class="wo-stub-meta">
                <span class="wo-ticket-no"><?= htmlspecialchars($preview_ticket); ?></span>
                <span class="wo-date">Opened <?= htmlspecialchars($today_display); ?></span>
            </div>
        </div>

        <div class="wo-body">
            <div class="wo-flash"><?= display_flash(); ?></div>

            <form action="submit_request.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?= csrf_token(); ?>">

                <div class="wo-section">
                    <h3 class="wo-section-title">Where's the issue?</h3>
                    <div class="wo-row">
                        <div class="wo-field">
                            <label for="block_location">Campus location / block</label>
                            <input type="text" id="block_location" name="block_location" placeholder="e.g. Block A, Library" required>
                        </div>
                        <div class="wo-field">
                            <label for="room_number">Room number / area</label>
                            <input type="text" id="room_number" name="room_number" placeholder="e.g. A201, Lab 3" required>
                        </div>
                    </div>
                </div>

                <div class="wo-section">
                    <h3 class="wo-section-title">What's wrong?</h3>
                    <div class="wo-row">
                        <div class="wo-field">
                            <label for="category">Category</label>
                            <select id="category" name="category" required>
                                <option value="Air-Conditioning">Air-Conditioning</option>
                                <option value="Electrical">Electrical</option>
                                <option value="Plumbing">Plumbing</option>
                                <option value="Furniture">Furniture</option>
                                <option value="IT Equipment">IT Equipment</option>
                                <option value="Building">Building / Cleaning</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        <div class="wo-field">
                            <label>Priority level</label>
                            <div class="wo-priority">
                                <span class="p-low">
                                    <input type="radio" id="p-low" name="priority" value="Low">
                                    <label for="p-low"><span class="dot"></span>Low</label>
                                </span>
                                <span class="p-medium">
                                    <input type="radio" id="p-medium" name="priority" value="Medium" checked>
                                    <label for="p-medium"><span class="dot"></span>Medium</label>
                                </span>
                                <span class="p-high">
                                    <input type="radio" id="p-high" name="priority" value="High">
                                    <label for="p-high"><span class="dot"></span>High</label>
                                </span>
                                <span class="p-emergency">
                                    <input type="radio" id="p-emergency" name="priority" value="Emergency">
                                    <label for="p-emergency"><span class="dot"></span>Emergency</label>
                                </span>
                            </div>
                        </div>
                    </div>

                    <div class="wo-field" style="margin-top: 1rem;">
                        <label for="description">Issue description</label>
                        <textarea id="description" name="description" rows="4" placeholder="Detail the maintenance problem..." required></textarea>
                    </div>
                </div>

                <div class="wo-section">
                    <h3 class="wo-section-title">Attach a photo (optional)</h3>
                    <div class="wo-drop" id="woDrop">
                        <input type="file" id="attachment" name="attachment" accept="image/png, image/jpeg, image/jpg, image/webp">
                        <div class="wo-drop-icon"><i class="fa-solid fa-paperclip"></i></div>
                        <p class="wo-drop-text">Drag a photo here, or click to browse</p>
                        <p class="wo-drop-hint">JPG, PNG, or WEBP — up to 5MB</p>
                        <span class="wo-drop-filename" id="woFilename"></span>
                    </div>
                </div>

                <div class="wo-actions">
                    <button type="submit" class="wo-btn-submit"><i class="fa-solid fa-paper-plane"></i> Submit ticket</button>
                    <a href="dashboard.php" class="wo-btn-cancel">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    (function () {
        var drop = document.getElementById('woDrop');
        var input = document.getElementById('attachment');
        var filenameEl = document.getElementById('woFilename');

        function showFilename(file) {
            if (!file) {
                filenameEl.classList.remove('is-visible');
                filenameEl.textContent = '';
                return;
            }
            filenameEl.innerHTML = '<i class="fa-solid fa-circle-check"></i> ' + file.name;
            filenameEl.classList.add('is-visible');
        }

        input.addEventListener('change', function () {
            showFilename(input.files && input.files[0]);
        });

        ['dragenter', 'dragover'].forEach(function (evt) {
            drop.addEventListener(evt, function (e) {
                e.preventDefault();
                drop.classList.add('is-dragover');
            });
        });

        ['dragleave', 'drop'].forEach(function (evt) {
            drop.addEventListener(evt, function (e) {
                e.preventDefault();
                drop.classList.remove('is-dragover');
            });
        });

        drop.addEventListener('drop', function (e) {
            var files = e.dataTransfer.files;
            if (files && files.length) {
                input.files = files;
                showFilename(files[0]);
            }
        });
    })();
</script>

<?php include 'includes/footer.php'; ?>