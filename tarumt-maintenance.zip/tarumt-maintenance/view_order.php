<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/db.php';
require_once 'includes/helpers.php';

require_auth();

// Restrict access to admin/staff only
$user_role = strtolower($_SESSION['role'] ?? 'student');
if (!in_array($user_role, ['admin', 'staff', 'technician'])) {
    set_flash('error', 'Unauthorized access.');
    header('Location: history.php');
    exit();
}

$ticket_id = (int)($_GET['id'] ?? 0);

if (!$ticket_id) {
    set_flash('error', 'Invalid ticket ID.');
    header('Location: work_orders.php');
    exit();
}

// Handle Ticket Status & Priority Updates
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_order') {
    verify_csrf();
    
    $new_status   = trim($_POST['status'] ?? 'Pending');
    $new_priority = trim($_POST['priority'] ?? 'Medium');

    try {
        $stmt = $pdo->prepare("UPDATE maintenance_requests SET status = ?, priority = ? WHERE id = ?");
        $stmt->execute([$new_status, $new_priority, $ticket_id]);
        set_flash('success', "Work Order #{$ticket_id} updated successfully.");
    } catch (PDOException $e) {
        set_flash('error', "Failed to update work order.");
    }

    header("Location: view_order.php?id=" . $ticket_id);
    exit();
}

// Fetch Ticket Details with Requester Info
try {
    $stmt = $pdo->prepare("
        SELECT r.*, u.name as requester_name, u.email as requester_email 
        FROM maintenance_requests r 
        LEFT JOIN users u ON r.user_id = u.id 
        WHERE r.id = ?
    ");
    $stmt->execute([$ticket_id]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$order) {
        set_flash('error', 'Work order not found.');
        header('Location: work_orders.php');
        exit();
    }
} catch (PDOException $e) {
    set_flash('error', 'Database error.');
    header('Location: work_orders.php');
    exit();
}
?>

<?php include 'includes/header.php'; ?>

<div class="page-content">
    <?= display_flash(); ?>

    <!-- Header Navigation -->
    <div style="margin-bottom: 1.5rem; display: flex; justify-content: space-between; align-items: center;">
        <a href="work_orders.php" class="btn btn-secondary" style="display: inline-flex; align-items: center; gap: 8px;">
            <i class="fa-solid fa-arrow-left"></i> Back to Work Orders
        </a>
        <span class="ticket-tag" style="font-size: 1rem; padding: 6px 14px;">
            Ticket #<?= str_pad($order['id'], 4, '0', STR_PAD_LEFT); ?>
        </span>
    </div>

    <!-- Main Content Grid -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 1.5rem;">
        
        <!-- Left Column: Order Details & Update Form -->
        <div class="card" style="margin-bottom: 0;">
            <div class="card-header">
                <h3><i class="fa-solid fa-clipboard-list"></i> Ticket Details</h3>
            </div>
            
            <div style="padding: 1rem 0; border-bottom: 1px solid #eee;">
                <p style="margin-bottom: 0.5rem;"><strong>Reported By:</strong> <?= htmlspecialchars($order['requester_name'] ?? 'Unknown'); ?> (<?= htmlspecialchars($order['requester_email'] ?? 'N/A'); ?>)</p>
                <p style="margin-bottom: 0.5rem;"><strong>Location:</strong> <?= htmlspecialchars($order['location'] ?? 'N/A'); ?></p>
                <p style="margin-bottom: 0.5rem;"><strong>Category:</strong> <?= htmlspecialchars($order['category'] ?? 'General'); ?></p>
                <p style="margin-bottom: 0.5rem;"><strong>Date Submitted:</strong> <?= date('d M Y, h:i A', strtotime($order['created_at'] ?? 'now')); ?></p>
                <p style="margin-bottom: 0.5rem;"><strong>Description:</strong></p>
                <div style="background: #f8f9fa; padding: 0.8rem; border-radius: 6px; border: 1px solid #e9ecef; font-size: 0.95rem;">
                    <?= nl2br(htmlspecialchars($order['description'] ?? 'No description provided.')); ?>
                </div>
            </div>

            <!-- Management Form -->
            <form action="view_order.php?id=<?= $order['id']; ?>" method="POST" style="margin-top: 1.5rem;">
                <input type="hidden" name="csrf_token" value="<?= csrf_token(); ?>">
                <input type="hidden" name="action" value="update_order">

                <h4 style="margin-bottom: 1rem;"><i class="fa-solid fa-sliders"></i> Update Status & Priority</h4>
                
                <div style="margin-bottom: 1rem;">
                    <label style="display: block; font-weight: 600; margin-bottom: 0.4rem;">Priority Level</label>
                    <select name="priority" style="width: 100%; height: 42px; font-size: 0.95rem; border-radius: 6px; border: 1px solid #ccc; padding: 0 10px;">
                        <option value="Low" <?= $order['priority'] === 'Low' ? 'selected' : ''; ?>>Low</option>
                        <option value="Medium" <?= $order['priority'] === 'Medium' ? 'selected' : ''; ?>>Medium</option>
                        <option value="High" <?= $order['priority'] === 'High' ? 'selected' : ''; ?>>High</option>
                    </select>
                </div>

                <div style="margin-bottom: 1.5rem;">
                    <label style="display: block; font-weight: 600; margin-bottom: 0.4rem;">Work Order Status</label>
                    <select name="status" style="width: 100%; height: 42px; font-size: 0.95rem; border-radius: 6px; border: 1px solid #ccc; padding: 0 10px;">
                        <option value="Pending" <?= $order['status'] === 'Pending' ? 'selected' : ''; ?>>Pending</option>
                        <option value="In Progress" <?= $order['status'] === 'In Progress' ? 'selected' : ''; ?>>In Progress</option>
                        <option value="Completed" <?= $order['status'] === 'Completed' ? 'selected' : ''; ?>>Completed</option>
                        <option value="Cancelled" <?= $order['status'] === 'Cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                    </select>
                </div>

                <button type="submit" class="btn" style="width: 100%; height: 44px; background-color: #800000; color: #fff; font-size: 1rem; border-radius: 6px; border: none; cursor: pointer;">
                    <i class="fa-solid fa-floppy-disk"></i> Save Changes
                </button>
            </form>
        </div>

        <!-- Right Column: User Uploaded Image Preview -->
        <div class="card" style="margin-bottom: 0;">
            <div class="card-header">
                <h3><i class="fa-solid fa-image"></i> Issue Attachment</h3>
            </div>

            <div style="text-align: center; padding: 1rem 0;">
                <?php if (!empty($order['attachment'])): ?>
                    <div style="position: relative; display: inline-block; width: 100%;">
                        <img src="<?= htmlspecialchars($order['attachment']); ?>" 
                             alt="Maintenance Attachment" 
                             onclick="openImageModal('<?= htmlspecialchars($order['attachment']); ?>')"
                             style="width: 100%; max-height: 380px; object-fit: contain; border-radius: 8px; border: 1px solid #ddd; cursor: pointer; background: #fafafa; transition: opacity 0.2s;"
                             onmouseover="this.style.opacity='0.9'"
                             onmouseout="this.style.opacity='1'"
                             title="Click to view full screen">
                        <p style="margin-top: 0.75rem; color: var(--text-muted); font-size: 0.85rem;">
                            <i class="fa-solid fa-magnifying-glass-plus"></i> Click image to inspect full size
                        </p>
                    </div>
                <?php else: ?>
                    <div style="padding: 4rem 1rem; background: #f8f9fa; border: 2px dashed #ccc; border-radius: 8px; color: #888;">
                        <i class="fa-solid fa-camera-retro" style="font-size: 3rem; margin-bottom: 1rem; color: #bbb;"></i>
                        <p style="margin: 0; font-size: 0.95rem;">No photo was attached to this request.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

    </div>
</div>

<!-- Modal Lightbox Overlay -->
<div id="imageModal" onclick="closeImageModal()" style="display: none; position: fixed; z-index: 99999; top: 0; left: 0; width: 100vw; height: 100vh; background-color: rgba(0,0,0,0.85); align-items: center; justify-content: center; cursor: pointer;">
    <span style="position: absolute; top: 25px; right: 35px; color: #fff; font-size: 35px; font-weight: bold;">&times;</span>
    <img id="modalImg" src="" style="max-width: 90vw; max-height: 90vh; border-radius: 8px; box-shadow: 0 5px 25px rgba(0,0,0,0.5); object-fit: contain;">
</div>

<script>
function openImageModal(imgSrc) {
    document.getElementById('modalImg').src = imgSrc;
    document.getElementById('imageModal').style.display = 'flex';
}

function closeImageModal() {
    document.getElementById('imageModal').style.display = 'none';
}
</script>

<?php include 'includes/footer.php'; ?>