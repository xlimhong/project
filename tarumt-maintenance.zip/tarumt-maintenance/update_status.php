<?php
session_start();
require_once 'config/db.php';

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'] ?? '', ['technician', 'admin'])) {
    header("Location: dashboard.php");
    exit();
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ticket_id'], $_POST['status'])) {
    $ticket_id = (int)$_POST['ticket_id'];
    $status = $_POST['status'];

    $stmt = $pdo->prepare("UPDATE maintenance_requests SET status = ? WHERE id = ?");
    if ($stmt->execute([$status, $ticket_id])) {
        $message = "<div class='alert success'>Status updated for Ticket #".sprintf('%04d', $ticket_id).".</div>";
    } else {
        $message = "<div class='alert error'>Failed to update ticket status.</div>";
    }
}

$stmt = $pdo->prepare("SELECT r.*, u.name, u.tarumt_id FROM maintenance_requests r JOIN users u ON r.user_id = u.id ORDER BY r.created_at DESC");
$stmt->execute();
$requests = $stmt->fetchAll();
?>

<?php include 'includes/header.php'; ?>

<div class="container wide">
    <div class="dashboard-card">
        <div class="dashboard-header">
            <h2>Manage Maintenance Tickets</h2>
        </div>

        <div style="padding: 1rem 1.75rem 0 1.75rem;">
            <?= $message; ?>
        </div>

        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Ticket ID</th>
                        <th>Requester</th>
                        <th>Location</th>
                        <th>Category</th>
                        <th>Description</th>
                        <th>Current Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($requests as $req): ?>
                        <tr>
                            <td><strong>#<?= sprintf('%04d', $req['id']); ?></strong></td>
                            <td><?= htmlspecialchars($req['name']); ?> <br><small style="color:var(--text-muted);"><?= htmlspecialchars($req['tarumt_id']); ?></small></td>
                            <td><?= htmlspecialchars($req['block_location']) . ' (' . htmlspecialchars($req['room_number']) . ')'; ?></td>
                            <td><?= htmlspecialchars($req['category']); ?></td>
                            <td><?= htmlspecialchars($req['description']); ?></td>
                            <td><span class="badge status-<?= strtolower(str_replace(' ', '-', $req['status'])); ?>"><?= htmlspecialchars($req['status']); ?></span></td>
                            <td>
                                <form action="update_status.php" method="POST" style="display:flex; gap: 6px; align-items:center;">
                                    <input type="hidden" name="ticket_id" value="<?= $req['id']; ?>">
                                    <select name="status" style="padding: 4px 8px; font-size: 0.85rem;">
                                        <option value="Pending" <?= $req['status'] === 'Pending' ? 'selected' : ''; ?>>Pending</option>
                                        <option value="In Progress" <?= $req['status'] === 'In Progress' ? 'selected' : ''; ?>>In Progress</option>
                                        <option value="Completed" <?= $req['status'] === 'Completed' ? 'selected' : ''; ?>>Completed</option>
                                        <option value="Cancelled" <?= $req['status'] === 'Cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                    </select>
                                    <button type="submit" class="btn btn-inline" style="padding: 5px 12px; font-size: 0.85rem;">Update</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>