<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/db.php';
require_once 'includes/helpers.php';

require_auth(['admin', 'staff','Technician']);

// Auto-create assets table if missing
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS assets (
        id INT AUTO_INCREMENT PRIMARY KEY,
        asset_tag VARCHAR(50) NOT NULL UNIQUE,
        name VARCHAR(150) NOT NULL,
        category VARCHAR(100) NOT NULL,
        location VARCHAR(100) NOT NULL,
        status ENUM('Operational', 'Under Maintenance', 'Decommissioned') DEFAULT 'Operational',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
} catch (PDOException $e) {}

// Add New Asset
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $asset_tag = trim($_POST['asset_tag'] ?? '');
    $name      = trim($_POST['name'] ?? '');
    $category  = trim($_POST['category'] ?? '');
    $location  = trim($_POST['location'] ?? '');
    $status    = trim($_POST['status'] ?? 'Operational');

    if (!empty($asset_tag) && !empty($name)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO assets (asset_tag, name, category, location, status) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$asset_tag, $name, $category, $location, $status]);
            
            set_flash('success', "Asset {$asset_tag} registered successfully.");
            header("Location: assets.php");
            exit();
        } catch (PDOException $e) {
            set_flash('error', "Failed to register asset: " . $e->getMessage());
            header("Location: assets.php");
            exit();
        }
    }
}

// Fetch all assets
try {
    $stmt = $pdo->query("SELECT * FROM assets ORDER BY id DESC");
    $assets = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $assets = [];
}
?>

<?php include 'includes/header.php'; ?>

<div class="page-content">
    <?= display_flash(); ?>

    <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 1.5rem;">
        <!-- Register Asset Form -->
        <div class="card" style="padding: 1.5rem;">
            <div class="card-header">
                <h2>Register Asset</h2>
            </div>
            <form action="assets.php" method="POST">
                <input type="hidden" name="csrf_token" value="<?= csrf_token(); ?>">

                <div class="form-group">
                    <label for="asset_tag">Asset Tag ID</label>
                    <input type="text" id="asset_tag" name="asset_tag" placeholder="e.g. AST-BLK-201" required>
                </div>

                <div class="form-group">
                    <label for="name">Asset Name</label>
                    <input type="text" id="name" name="name" placeholder="e.g. Panasonic Inverter AC" required>
                </div>

                <div class="form-group">
                    <label for="category">Category</label>
                    <input type="text" id="category" name="category" placeholder="e.g. HVAC / Electrical" required>
                </div>

                <div class="form-group">
                    <label for="location">Location</label>
                    <input type="text" id="location" name="location" placeholder="e.g. Block A, Room 201" required>
                </div>

                <div class="form-group">
                    <label for="status">Condition Status</label>
                    <select id="status" name="status">
                        <option value="Operational">Operational</option>
                        <option value="Under Maintenance">Under Maintenance</option>
                        <option value="Decommissioned">Decommissioned</option>
                    </select>
                </div>

                <button type="submit" class="btn" style="width: 100%; margin-top: 0.5rem;">Register Asset</button>
            </form>
        </div>

        <!-- Asset Inventory List -->
        <div class="card" style="padding: 1.5rem;">
            <div class="card-header">
                <h2>Registered Campus Assets</h2>
            </div>
            <div class="table-container" style="margin-top: 1rem;">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Tag ID</th>
                            <th>Asset Name</th>
                            <th>Category</th>
                            <th>Location</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($assets)): ?>
                            <?php foreach ($assets as $a): ?>
                                <tr>
                                    <td><span class="ticket-tag"><?= htmlspecialchars($a['asset_tag']); ?></span></td>
                                    <td><strong><?= htmlspecialchars($a['name']); ?></strong></td>
                                    <td><?= htmlspecialchars($a['category']); ?></td>
                                    <td><?= htmlspecialchars($a['location']); ?></td>
                                    <td>
                                        <span class="badge <?= $a['status'] === 'Operational' ? 'badge-completed' : 'badge-pending'; ?>">
                                            <?= htmlspecialchars($a['status']); ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" style="text-align: center; color: var(--ink-muted); padding: 2rem;">No registered assets in database.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>