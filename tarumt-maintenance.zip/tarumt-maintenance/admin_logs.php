<?php
require_once 'config/db.php';
require_once 'includes/helpers.php';
require_auth(['admin']);

$logs = $pdo->query("SELECT l.*, u.name, u.tarumt_id 
                     FROM system_logs l 
                     LEFT JOIN users u ON l.user_id = u.id 
                     ORDER BY l.created_at DESC LIMIT 100")->fetchAll();
?>

<?php include 'includes/header.php'; ?>

<div class="container-centered">
    <div class="card">
        <div class="card-header">
            <h2>System Audit Logs (Last 100 Activities)</h2>
        </div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Timestamp</th>
                        <th>User</th>
                        <th>Action</th>
                        <th>Activity Details</th>
                        <th>IP Address</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $lg): ?>
                        <tr>
                            <td><small><?= $lg['created_at']; ?></small></td>
                            <td><?= htmlspecialchars($lg['name'] ?? 'System / Anonymous'); ?></td>
                            <td><strong><?= htmlspecialchars($lg['action']); ?></strong></td>
                            <td><?= htmlspecialchars($lg['details']); ?></td>
                            <td><code><?= $lg['ip_address']; ?></code></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>