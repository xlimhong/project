<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/db.php';
require_once 'includes/helpers.php';

require_auth();

$user_id   = $_SESSION['user_id'] ?? 0;
$user_name = $_SESSION['name'] ?? 'User';
$user_role = strtolower($_SESSION['role'] ?? 'student');

// Include 'technician' along with admin and staff
$is_admin_or_staff = in_array($user_role, ['admin', 'staff', 'technician']);

// Ensure database table exists
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS maintenance_requests (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        location VARCHAR(255) NOT NULL,
        category VARCHAR(100) NOT NULL,
        description TEXT NULL,
        priority VARCHAR(50) DEFAULT 'Medium',
        status VARCHAR(50) DEFAULT 'Pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
} catch (PDOException $e) {
    die("Database table initialization error: " . $e->getMessage());
}

// Handle Status Updates & Send Notifications to Users
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_status') {
    verify_csrf();
    if ($is_admin_or_staff) {
        $req_id     = (int)($_POST['request_id'] ?? 0);
        $new_status = trim($_POST['status'] ?? 'Pending');

        try {
            // 1. Retrieve the original ticket & requester ID
            $ticketStmt = $pdo->prepare("SELECT ticket_no, user_id, category FROM maintenance_requests WHERE id = ?");
            $ticketStmt->execute([$req_id]);
            $ticket = $ticketStmt->fetch(PDO::FETCH_ASSOC);

            if ($ticket) {
                // 2. Update status in database
                $stmt = $pdo->prepare("UPDATE maintenance_requests SET status = ? WHERE id = ?");
                $stmt->execute([$new_status, $req_id]);

                $ticket_label = !empty($ticket['ticket_no']) ? $ticket['ticket_no'] : "#" . str_pad($req_id, 4, '0', STR_PAD_LEFT);

                // 3. Craft tailored notification message for the user
                if ($new_status === 'Completed') {
                    $notifTitle = "Request Completed: {$ticket_label}";
                    $notifMsg   = "Your maintenance request for {$ticket['category']} ({$ticket_label}) has been completed!";
                    $notifType  = 'success';
                } elseif ($new_status === 'In Progress') {
                    $notifTitle = "Work Started: {$ticket_label}";
                    $notifMsg   = "A technician is currently working on your request ({$ticket_label}).";
                    $notifType  = 'info';
                } elseif ($new_status === 'Cancelled') {
                    $notifTitle = "Request Cancelled: {$ticket_label}";
                    $notifMsg   = "Your request ({$ticket_label}) was cancelled.";
                    $notifType  = 'danger';
                } else {
                    $notifTitle = "Status Update: {$ticket_label}";
                    $notifMsg   = "Your request ({$ticket_label}) status was updated to '{$new_status}'.";
                    $notifType  = 'info';
                }

                // 4. Send notification directly to the user who requested it
                create_notification(
                    $pdo,
                    $notifTitle,
                    $notifMsg,
                    $notifType,
                    null,               // role is null for specific user target
                    $ticket['user_id'], // target user ID
                    'dashboard.php'
                );

                set_flash('success', "Ticket {$ticket_label} status updated to {$new_status} and user notified.");
            }
        } catch (PDOException $e) {
            set_flash('error', "Failed to update status: " . $e->getMessage());
        }
    }
    header("Location: dashboard.php");
    exit();
}

// Smart Search
$search = trim($_GET['search'] ?? '');

// KPI Counters + Recent Requests
try {
    if ($is_admin_or_staff) {
        $total_requests     = $pdo->query("SELECT COUNT(*) FROM maintenance_requests")->fetchColumn();
        $pending_requests   = $pdo->query("SELECT COUNT(*) FROM maintenance_requests WHERE status = 'Pending'")->fetchColumn();
        $in_progress_reqs   = $pdo->query("SELECT COUNT(*) FROM maintenance_requests WHERE status = 'In Progress'")->fetchColumn();
        $completed_requests = $pdo->query("SELECT COUNT(*) FROM maintenance_requests WHERE status = 'Completed'")->fetchColumn();

        $sql = "SELECT r.*, COALESCE(u.name, 'User') as requester_name
                FROM maintenance_requests r
                LEFT JOIN users u ON r.user_id = u.id";
        $params = [];
        if ($search !== '') {
            $sql .= " WHERE r.location LIKE :q OR r.category LIKE :q OR r.description LIKE :q";
            $params['q'] = "%{$search}%";
        }
        $sql .= " ORDER BY r.id DESC LIMIT 20";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $recent_requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $total_stmt = $pdo->prepare("SELECT COUNT(*) FROM maintenance_requests WHERE user_id = ?");
        $total_stmt->execute([$user_id]);
        $total_requests = $total_stmt->fetchColumn();

        $pending_stmt = $pdo->prepare("SELECT COUNT(*) FROM maintenance_requests WHERE user_id = ? AND status = 'Pending'");
        $pending_stmt->execute([$user_id]);
        $pending_requests = $pending_stmt->fetchColumn();

        $progress_stmt = $pdo->prepare("SELECT COUNT(*) FROM maintenance_requests WHERE user_id = ? AND status = 'In Progress'");
        $progress_stmt->execute([$user_id]);
        $in_progress_reqs = $progress_stmt->fetchColumn();

        $completed_stmt = $pdo->prepare("SELECT COUNT(*) FROM maintenance_requests WHERE user_id = ? AND status = 'Completed'");
        $completed_stmt->execute([$user_id]);
        $completed_requests = $completed_stmt->fetchColumn();

        $sql = "SELECT * FROM maintenance_requests WHERE user_id = :uid";
        $params = ['uid' => $user_id];
        if ($search !== '') {
            $sql .= " AND (location LIKE :q OR category LIKE :q OR description LIKE :q)";
            $params['q'] = "%{$search}%";
        }
        $sql .= " ORDER BY id DESC LIMIT 20";
        $recent_stmt = $pdo->prepare($sql);
        $recent_stmt->execute($params);
        $recent_requests = $recent_stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (PDOException $e) {
    echo "<div style='color:red; background:#fee2e2; padding:10px; border-radius:5px;'><strong>Database Query Error:</strong> " . htmlspecialchars($e->getMessage()) . "</div>";
    $total_requests = $pending_requests = $in_progress_reqs = $completed_requests = 0;
    $recent_requests = [];
}

// Quick search categories
$quick_categories = [];
try {
    $cat_stmt = $pdo->query("SELECT DISTINCT category FROM maintenance_requests WHERE category IS NOT NULL AND category != '' LIMIT 5");
    $quick_categories = $cat_stmt->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {}
?>

<?php include 'includes/header.php'; ?>

<style>
.search-tag {
    font-size: 0.78rem;
    padding: 4px 10px;
    background: #f1f5f9;
    color: #334155;
    border-radius: 999px;
    text-decoration: none;
    font-weight: 600;
}
.search-tag:hover { background: #e2e8f0; }

.priority-badge {
    padding: 3px 10px;
    border-radius: 999px;
    font-size: 0.75rem;
    font-weight: 700;
}
.priority-emergency { background: #fee2e2; color: #b91c1c; }
.priority-high       { background: #ffedd5; color: #c2410c; }
.priority-medium     { background: #fef9c3; color: #a16207; }
.priority-low        { background: #dcfce7; color: #15803d; }

.timeline-container { display: flex; align-items: center; gap: 4px; }
.timeline-step { display: flex; flex-direction: column; align-items: center; opacity: 0.35; flex: 1; }
.timeline-step.completed { opacity: 1; }
.timeline-icon {
    width: 26px; height: 26px; border-radius: 50%;
    background: #e2e8f0; color: #64748b;
    display: flex; align-items: center; justify-content: center;
    font-size: 0.7rem; margin-bottom: 4px;
}
.timeline-step.completed .timeline-icon { background: #c8102e; color: #fff; }
.timeline-label { font-size: 0.65rem; color: #64748b; }
</style>

<div class="welcome-hero">
    <h1>Good Day, <?= htmlspecialchars($user_name); ?> 👋</h1>
    <p>Here is your maintenance activity overview today.</p>
</div>

<?= display_flash(); ?>

<!-- Smart Search -->
<div class="card" style="padding: 18px; margin-bottom: 1.5rem;">
    <form method="GET" action="dashboard.php" style="display: flex; gap: 10px;">
        <div style="position: relative; flex: 1;">
            <i class="fa-solid fa-magnifying-glass" style="position: absolute; left: 14px; top: 50%; transform: translateY(-50%); color: #94a3b8;"></i>
            <input type="text" name="search" value="<?= htmlspecialchars($search); ?>"
                   placeholder="Search by location, category, or description..."
                   style="width: 100%; padding: 10px 14px 10px 40px; border: 1px solid #cbd5e1; border-radius: 8px; outline: none; font-size: 0.95rem;">
        </div>
        <button type="submit" class="btn">Search</button>
        <?php if ($search !== ''): ?>
            <a href="dashboard.php" style="display: inline-flex; align-items: center; padding: 0 16px; background: #e2e8f0; color: #334155; text-decoration: none; border-radius: 8px; font-weight: 600;">Clear</a>
        <?php endif; ?>
    </form>

    <?php if (!empty($quick_categories)): ?>
    <div style="display: flex; gap: 8px; align-items: center; margin-top: 12px; flex-wrap: wrap;">
        <span style="font-size: 0.78rem; color: #64748b; font-weight: 600;">Quick Filters:</span>
        <?php foreach ($quick_categories as $cat): ?>
            <a href="dashboard.php?search=<?= urlencode($cat); ?>" class="search-tag"><?= htmlspecialchars($cat); ?></a>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>

<!-- KPI Metrics Grid -->
<div class="stat-grid">
    <div class="stat-card tarumt">
        <div class="stat-header">
            <span class="stat-label">Total Reports</span>
            <i class="fa-solid fa-clipboard-list stat-icon"></i>
        </div>
        <div class="stat-value"><?= $total_requests; ?></div>
    </div>

    <div class="stat-card orange">
        <div class="stat-header">
            <span class="stat-label">Pending</span>
            <i class="fa-solid fa-clock stat-icon"></i>
        </div>
        <div class="stat-value"><?= $pending_requests; ?></div>
    </div>

    <div class="stat-card blue">
        <div class="stat-header">
            <span class="stat-label">In Progress</span>
            <i class="fa-solid fa-spinner stat-icon"></i>
        </div>
        <div class="stat-value"><?= $in_progress_reqs; ?></div>
    </div>

    <div class="stat-card green">
        <div class="stat-header">
            <span class="stat-label">Completed</span>
            <i class="fa-solid fa-circle-check stat-icon"></i>
        </div>
        <div class="stat-value"><?= $completed_requests; ?></div>
    </div>
</div>

<!-- Quick Module Nav -->
<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-bottom: 2rem;">
    <a href="submit_request.php" style="text-decoration: none; color: inherit;">
        <div class="card" style="margin-bottom:0; padding: 1.25rem; border-left: 5px solid var(--tarumt-red);">
            <h3><i class="fa-solid fa-pen-to-square" style="color: var(--tarumt-red);"></i> Report Maintenance</h3>
            <p style="color: var(--text-muted); font-size: 0.85rem;">Submit new repair tickets</p>
        </div>
    </a>
    <a href="feedback.php" style="text-decoration: none; color: inherit;">
        <div class="card" style="margin-bottom:0; padding: 1.25rem; border-left: 5px solid var(--success);">
            <h3><i class="fa-solid fa-star" style="color: var(--warning);"></i> Service Feedback</h3>
            <p style="color: var(--text-muted); font-size: 0.85rem;">Rate completed repairs & discussions</p>
        </div>
    </a>
</div>

<!-- Maintenance Requests Table -->
<div class="card">
    <div class="card-header">
        <h2><i class="fa-solid fa-clock-rotate-left"></i> Recent Maintenance Requests</h2>
        <a href="submit_request.php" class="btn"><i class="fa-solid fa-plus"></i> + Report New Issue</a>
    </div>

    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Ticket ID</th>
                    <?php if ($is_admin_or_staff): ?><th>Reported By</th><?php endif; ?>
                    <th>Location</th>
                    <th>Category</th>
                    <th>Priority</th>
                    <th>Status & Timeline</th>
                    <th>Date Reported</th>
                    <?php if ($is_admin_or_staff): ?><th>Action</th><?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($recent_requests)): ?>
                    <?php foreach ($recent_requests as $req): ?>
                        <?php $priorityClass = strtolower($req['priority'] ?? 'medium'); ?>
                        <tr>
                            <td><span class="ticket-tag">#<?= str_pad($req['id'], 4, '0', STR_PAD_LEFT); ?></span></td>
                            <?php if ($is_admin_or_staff): ?>
                                <td><strong><?= htmlspecialchars($req['requester_name'] ?? 'User'); ?></strong></td>
                            <?php endif; ?>
                            <td><?= htmlspecialchars($req['location'] ?? 'N/A'); ?></td>
                            <td><?= htmlspecialchars($req['category'] ?? 'General'); ?></td>
                            <td><span class="priority-badge priority-<?= htmlspecialchars($priorityClass); ?>"><?= htmlspecialchars($req['priority'] ?? 'Medium'); ?></span></td>
                            <td style="width: 240px;">
                                <?php if ($req['status'] === 'Completed'): ?>
                                    <span class="badge badge-completed"><i class="fa-solid fa-circle-check"></i> Completed</span>
                                <?php elseif ($req['status'] === 'In Progress'): ?>
                                    <span class="badge badge-progress"><i class="fa-solid fa-spinner fa-spin"></i> In Progress</span>
                                <?php elseif ($req['status'] === 'Cancelled'): ?>
                                    <span class="badge badge-cancelled"><i class="fa-solid fa-circle-xmark"></i> Cancelled</span>
                                <?php else: ?>
                                    <span class="badge badge-pending"><i class="fa-solid fa-clock"></i> Pending</span>
                                <?php endif; ?>
                                <?php if ($req['status'] !== 'Cancelled'): ?>
                                <div class="timeline-container" style="margin-top:6px;">
                                    <div class="timeline-step <?= in_array($req['status'], ['Pending', 'In Progress', 'Completed']) ? 'completed' : ''; ?>">
                                        <div class="timeline-icon"><i class="fa-solid fa-file"></i></div>
                                        <span class="timeline-label">Pending</span>
                                    </div>
                                    <div class="timeline-step <?= in_array($req['status'], ['In Progress', 'Completed']) ? 'completed' : ''; ?>">
                                        <div class="timeline-icon"><i class="fa-solid fa-wrench"></i></div>
                                        <span class="timeline-label">Progress</span>
                                    </div>
                                    <div class="timeline-step <?= $req['status'] === 'Completed' ? 'completed' : ''; ?>">
                                        <div class="timeline-icon"><i class="fa-solid fa-check"></i></div>
                                        <span class="timeline-label">Done</span>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </td>
                            <td><?= date('d M Y', strtotime($req['created_at'] ?? 'now')); ?></td>
                            <?php if ($is_admin_or_staff): ?>
                                <td>
                                    <form action="dashboard.php" method="POST" style="display: flex; gap: 0.5rem;">
                                        <input type="hidden" name="csrf_token" value="<?= csrf_token(); ?>">
                                        <input type="hidden" name="action" value="update_status">
                                        <input type="hidden" name="request_id" value="<?= $req['id']; ?>">
                                        <select name="status" style="height: 36px; padding: 0 8px; font-size: 0.8rem;">
                                            <option value="Pending" <?= $req['status'] === 'Pending' ? 'selected' : ''; ?>>Pending</option>
                                            <option value="In Progress" <?= $req['status'] === 'In Progress' ? 'selected' : ''; ?>>In Progress</option>
                                            <option value="Completed" <?= $req['status'] === 'Completed' ? 'selected' : ''; ?>>Completed</option>
                                            <option value="Cancelled" <?= $req['status'] === 'Cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                        </select>
                                        <button type="submit" class="btn" style="padding: 4px 12px; font-size: 0.8rem;">Save</button>
                                    </form>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="<?= $is_admin_or_staff ? '8' : '7'; ?>" style="text-align: center; color: var(--text-muted); padding: 2rem;">No requests found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include 'includes/footer.php'; ?>