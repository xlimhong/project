<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/db.php';
require_once 'includes/helpers.php';

require_auth();

$user_role = strtolower($_SESSION['role'] ?? 'student');

// Restrict access: Only Admin, Staff, and Technician can manage work orders
if (!in_array($user_role, ['admin', 'staff', 'technician'])) {
    set_flash('error', "Access denied. Work orders are restricted to Staff or Technician and Admin.");
    header("Location: dashboard.php");
    exit();
}

// Handle Status & Priority Updates
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_work_order') {
    verify_csrf();

    $req_id     = (int)($_POST['request_id'] ?? 0);
    $new_status = trim($_POST['status'] ?? 'Pending');
    $priority   = trim($_POST['priority'] ?? 'Medium');

    try {
        // Fetch ticket details prior to update to send targeted user notification
        $ticketStmt = $pdo->prepare("SELECT ticket_no, user_id, category FROM maintenance_requests WHERE id = ?");
        $ticketStmt->execute([$req_id]);
        $ticket = $ticketStmt->fetch(PDO::FETCH_ASSOC);

        // Update database status and priority
        $stmt = $pdo->prepare("UPDATE maintenance_requests SET status = ?, priority = ? WHERE id = ?");
        $stmt->execute([$new_status, $priority, $req_id]);

        // Trigger notification to the requester
        if ($ticket && !empty($ticket['user_id'])) {
            $ticket_label = !empty($ticket['ticket_no']) ? $ticket['ticket_no'] : '#' . str_pad((string)$req_id, 4, '0', STR_PAD_LEFT);

            if ($new_status === 'Completed') {
                $notifTitle = "Work Order Completed";
                $notifMsg   = "Great news! Your maintenance request {$ticket_label} ({$ticket['category']}) has been marked as completed.";
                $notifType  = 'success';
            } elseif ($new_status === 'In Progress') {
                $notifTitle = "Work Order In Progress";
                $notifMsg   = "A technician is currently working on your request {$ticket_label}.";
                $notifType  = 'info';
            } elseif ($new_status === 'Cancelled') {
                $notifTitle = "Work Order Cancelled";
                $notifMsg   = "Your request {$ticket_label} was cancelled.";
                $notifType  = 'danger';
            } else {
                $notifTitle = "Work Order Updated";
                $notifMsg   = "Your request {$ticket_label} status was updated to '{$new_status}'.";
                $notifType  = 'info';
            }

            create_notification(
                $pdo,
                $notifTitle,
                $notifMsg,
                $notifType,
                'history.php',
                (int)$ticket['user_id'],
                null
            );
        }

        set_flash('success', "Work Order #{$req_id} updated successfully and notification dispatched.");
    } catch (PDOException $e) {
        set_flash('error', "Failed to update work order: " . $e->getMessage());
    }

    header("Location: work_orders.php");
    exit();
}

// Filter handling
$status_filter = trim($_GET['status'] ?? '');

$sql = "SELECT r.*, COALESCE(u.name, 'Unknown User') as requester_name 
        FROM maintenance_requests r 
        LEFT JOIN users u ON r.user_id = u.id 
        WHERE 1=1";
$params = [];

if (!empty($status_filter)) {
    $sql .= " AND r.status = ?";
    $params[] = $status_filter;
}

$sql .= " ORDER BY CASE r.priority 
            WHEN 'Emergency' THEN 1 
            WHEN 'High' THEN 2 
            WHEN 'Medium' THEN 3 
            WHEN 'Low' THEN 4 
            ELSE 5 END, r.id DESC";

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $work_orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $work_orders = [];
    set_flash('error', "Database error loading work orders: " . $e->getMessage());
}
?>

<?php include 'includes/header.php'; ?>

<style>
:root {
    --wo-ink: #14202B;
    --wo-muted: #64748b;
    --wo-border: #e6e9ee;
    --wo-maroon: #800000;
    --wo-maroon-dark: #650000;
    --wo-emergency: #C43E30;
    --wo-high: #C8862A;
    --wo-green: #2F8659;
    --wo-blue: #2C6BB0;
    --wo-slate: #8A93A0;
}

@keyframes wo-fade-up {
    from { opacity: 0; transform: translateY(12px); }
    to   { opacity: 1; transform: translateY(0); }
}

@keyframes wo-fade-in {
    from { opacity: 0; }
    to   { opacity: 1; }
}

@keyframes wo-pulse-dot {
    0%, 100% { box-shadow: 0 0 0 0 rgba(196, 62, 48, 0.45); }
    50%      { box-shadow: 0 0 0 6px rgba(196, 62, 48, 0); }
}

.page-content .card {
    animation: wo-fade-in 0.4s ease both;
}

.card-header h2 i {
    color: var(--wo-maroon);
}

.wo-filter-bar {
    display: flex;
    gap: 1rem;
    align-items: center;
    margin-bottom: 1.5rem;
    padding: 0.85rem 1rem;
    background: #f8f9fb;
    border: 1px solid var(--wo-border);
    border-radius: 10px;
    flex-wrap: wrap;
}

.wo-filter-bar label {
    font-weight: 600;
    color: var(--wo-ink);
    font-size: 0.88rem;
}

.wo-filter-bar select {
    max-width: 200px;
    height: 38px;
    border-radius: 8px;
    border: 1px solid var(--wo-border);
    padding: 0 10px;
    transition: border-color 0.2s ease, box-shadow 0.2s ease;
}

.wo-filter-bar select:focus,
.wo-filter-bar select:hover {
    border-color: var(--wo-maroon);
    box-shadow: 0 0 0 3px rgba(128,0,0,0.08);
}

.wo-filter-bar .btn-secondary {
    padding: 6px 12px;
    font-size: 0.85rem;
    border-radius: 8px;
    transition: transform 0.2s ease;
}

.wo-filter-bar .btn-secondary:hover {
    transform: translateY(-2px);
}

.ticket-list {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.ticket-card {
    border: 1px solid var(--wo-border);
    padding: 1.5rem;
    border-radius: 12px;
    margin-bottom: 0;
    background: #fff;
    box-shadow: 0 2px 8px rgba(20, 32, 43, 0.03);
    opacity: 0;
    animation: wo-fade-up 0.5s ease forwards;
    transition: box-shadow 0.25s ease, transform 0.25s ease, border-color 0.25s ease;
    position: relative;
    overflow: hidden;
}

.ticket-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    bottom: 0;
    width: 4px;
    background: var(--wo-slate);
    transition: width 0.25s ease;
}

.ticket-card[data-priority="Emergency"]::before { background: var(--wo-emergency); }
.ticket-card[data-priority="High"]::before { background: var(--wo-high); }
.ticket-card[data-priority="Medium"]::before { background: var(--wo-blue); }
.ticket-card[data-priority="Low"]::before { background: var(--wo-slate); }

.ticket-card:hover {
    box-shadow: 0 12px 26px rgba(20, 32, 43, 0.08);
    transform: translateY(-3px);
    border-color: transparent;
}

.ticket-card:hover::before {
    width: 6px;
}

.ticket-list .ticket-card:nth-child(1) { animation-delay: 0.03s; }
.ticket-list .ticket-card:nth-child(2) { animation-delay: 0.08s; }
.ticket-list .ticket-card:nth-child(3) { animation-delay: 0.13s; }
.ticket-list .ticket-card:nth-child(4) { animation-delay: 0.18s; }
.ticket-list .ticket-card:nth-child(5) { animation-delay: 0.23s; }
.ticket-list .ticket-card:nth-child(n+6) { animation-delay: 0.28s; }

.ticket-tag {
    display: inline-block;
    background: #EFE7E7;
    color: var(--wo-maroon-dark);
    font-weight: 700;
    font-size: 0.78rem;
    padding: 3px 9px;
    border-radius: 6px;
    letter-spacing: 0.02em;
}

.ticket-card h3 {
    margin-bottom: 0.75rem;
}

.ticket-card p {
    margin: 0.3rem 0;
    font-size: 0.92rem;
    color: var(--wo-ink);
}

.ticket-card p strong {
    color: var(--wo-muted);
    font-weight: 600;
    font-size: 0.82rem;
    text-transform: uppercase;
    letter-spacing: 0.02em;
    margin-right: 0.25rem;
}

.wo-priority-tag {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    font-weight: 700;
    padding: 2px 10px;
    border-radius: 999px;
    font-size: 0.8rem;
}

.wo-priority-Emergency { background: #FBEAE8; color: var(--wo-emergency); }
.wo-priority-High      { background: #FBF1E1; color: var(--wo-high); }
.wo-priority-Medium    { background: #E7EEF4; color: var(--wo-blue); }
.wo-priority-Low       { background: #EEF1F4; color: var(--wo-slate); }

.wo-priority-Emergency .wo-dot {
    animation: wo-pulse-dot 1.6s infinite;
}

.wo-dot {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: currentColor;
    display: inline-block;
}

.btn-view {
    padding: 7px 16px;
    font-size: 0.85rem;
    background-color: var(--wo-maroon);
    color: #fff;
    text-decoration: none;
    border-radius: 8px;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    transition: background-color 0.2s ease, transform 0.2s ease, box-shadow 0.2s ease;
}

.btn-view:hover {
    background-color: var(--wo-maroon-dark);
    transform: translateY(-2px);
    box-shadow: 0 6px 14px rgba(128,0,0,0.25);
}

.wo-photo-wrap {
    text-align: center;
}

.wo-photo-wrap img {
    max-width: 180px;
    max-height: 140px;
    object-fit: cover;
    border-radius: 10px;
    border: 2px solid #007bff;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    transition: transform 0.25s ease, box-shadow 0.25s ease;
}

.wo-photo-wrap a:hover img {
    transform: scale(1.04);
    box-shadow: 0 8px 18px rgba(0,0,0,0.18);
}

.wo-no-photo {
    background: #f8f9fa;
    border: 1px dashed #ccc;
    padding: 1rem;
    border-radius: 10px;
    color: #888;
    font-size: 0.85rem;
    text-align: center;
    min-width: 140px;
    transition: border-color 0.2s ease, background 0.2s ease;
}

.ticket-card:hover .wo-no-photo {
    border-color: var(--wo-maroon);
    background: #fdfaf8;
}

.wo-update-form {
    display: flex;
    gap: 0.75rem;
    align-items: center;
    flex-wrap: wrap;
    margin-top: 1rem;
    padding-top: 1rem;
    border-top: 1px solid #eee;
}

.wo-update-form label {
    font-size: 0.8rem;
    font-weight: 600;
    color: var(--wo-muted);
    display: flex;
    align-items: center;
    gap: 6px;
}

.wo-update-form select {
    height: 32px;
    font-size: 0.8rem;
    padding: 2px 8px;
    border-radius: 6px;
    border: 1px solid var(--wo-border);
    transition: border-color 0.2s ease;
}

.wo-update-form select:focus {
    border-color: var(--wo-maroon);
}

.wo-update-form button {
    padding: 7px 16px;
    font-size: 0.8rem;
    border-radius: 8px;
    background: var(--wo-ink);
    color: #fff;
    border: none;
    cursor: pointer;
    transition: transform 0.2s ease, background 0.2s ease;
}

.wo-update-form button:hover {
    background: var(--wo-maroon);
    transform: translateY(-2px);
}

.wo-update-form button:active {
    transform: translateY(0) scale(0.97);
}

.wo-empty-state {
    text-align: center;
    color: var(--wo-muted);
    padding: 3rem 1rem;
    animation: wo-fade-in 0.5s ease both;
}

.wo-empty-state i {
    font-size: 2rem;
    display: block;
    margin-bottom: 0.75rem;
    opacity: 0.5;
}

@media (prefers-reduced-motion: reduce) {
    .ticket-card, .page-content .card, .wo-empty-state {
        animation: none !important;
        opacity: 1 !important;
    }
    .ticket-card:hover, .btn-view:hover, .wo-update-form button:hover, .wo-photo-wrap a:hover img {
        transform: none;
    }
    .wo-priority-Emergency .wo-dot { animation: none; }
}
</style>

<div class="page-content">
    <?= display_flash(); ?>

    <div class="card">
        <div class="card-header" style="flex-wrap: wrap; gap: 1rem;">
            <div>
                <h2><i class="fa-solid fa-gears"></i> Work Order Management</h2>
                <p style="color: var(--text-muted); font-size: 0.85rem; margin-top: 0.25rem;">
                    Manage, assign, and update campus maintenance tasks.
                </p>
            </div>
        </div>

        <!-- Filter Bar -->
        <form action="work_orders.php" method="GET" class="wo-filter-bar">
            <label for="status"><i class="fa-solid fa-filter"></i> Filter by Status:</label>
            <select name="status" id="status" onchange="this.form.submit()">
                <option value="">All Statuses</option>
                <option value="Pending" <?= $status_filter === 'Pending' ? 'selected' : ''; ?>>Pending</option>
                <option value="In Progress" <?= $status_filter === 'In Progress' ? 'selected' : ''; ?>>In Progress</option>
                <option value="Completed" <?= $status_filter === 'Completed' ? 'selected' : ''; ?>>Completed</option>
                <option value="Cancelled" <?= $status_filter === 'Cancelled' ? 'selected' : ''; ?>>Cancelled</option>
            </select>
            <?php if (!empty($status_filter)): ?>
                <a href="work_orders.php" class="btn btn-secondary">Reset Filter</a>
            <?php endif; ?>
            <?php if (!empty($work_orders)): ?>
                <span style="margin-left: auto; font-size: 0.82rem; color: var(--wo-muted);">
                    <?= count($work_orders); ?> order<?= count($work_orders) === 1 ? '' : 's'; ?> found
                </span>
            <?php endif; ?>
        </form>

        <!-- Work Order Cards -->
        <div class="ticket-list">
            <?php if (!empty($work_orders)): ?>
                <?php foreach ($work_orders as $order):
                    $ticket_label = !empty($order['ticket_no'])
                        ? $order['ticket_no']
                        : '#' . str_pad($order['id'], 4, '0', STR_PAD_LEFT);

                    $location = $order['location'] ?? trim(($order['block_location'] ?? '') . ' ' . ($order['room_number'] ?? ''));
                    $priority = $order['priority'] ?? 'Medium';
                ?>
                    <div class="ticket-card" data-priority="<?= htmlspecialchars($priority); ?>">
                        <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 1rem; flex-wrap: wrap;">

                            <!-- Details -->
                            <div style="flex: 1; min-width: 240px;">
                                <h3 style="display: flex; justify-content: space-between; align-items: center; gap: 0.75rem; flex-wrap: wrap;">
                                    <span>
                                        <span class="ticket-tag"><?= htmlspecialchars($ticket_label); ?></span>
                                        &mdash; <?= htmlspecialchars($order['category'] ?? 'General'); ?>
                                    </span>
                                    <a href="view_order.php?id=<?= $order['id']; ?>" class="btn-view">
                                        <i class="fa-solid fa-eye"></i> View &amp; Update
                                    </a>
                                </h3>
                                <p><strong>Reported By</strong> <?= htmlspecialchars($order['requester_name']); ?></p>
                                <p><strong>Location</strong> <?= htmlspecialchars($location); ?></p>
                                <p><strong>Description</strong> <?= htmlspecialchars($order['description'] ?? ''); ?></p>
                                <p>
                                    <strong>Priority</strong>
                                    <span class="wo-priority-tag wo-priority-<?= htmlspecialchars($priority); ?>">
                                        <span class="wo-dot"></span><?= htmlspecialchars($priority); ?>
                                    </span>
                                </p>
                                <p>
                                    <strong>Status</strong>
                                    <?php if ($order['status'] === 'Completed'): ?>
                                        <span class="badge badge-completed"><i class="fa-solid fa-circle-check"></i> Completed</span>
                                    <?php elseif ($order['status'] === 'In Progress'): ?>
                                        <span class="badge badge-progress"><i class="fa-solid fa-spinner fa-spin"></i> In Progress</span>
                                    <?php elseif ($order['status'] === 'Cancelled'): ?>
                                        <span class="badge badge-cancelled"><i class="fa-solid fa-circle-xmark"></i> Cancelled</span>
                                    <?php else: ?>
                                        <span class="badge badge-pending"><i class="fa-solid fa-clock"></i> Pending</span>
                                    <?php endif; ?>
                                </p>
                            </div>

                            <!-- Photo Preview -->
                            <?php if (!empty($order['attachment'])): ?>
                                <div class="wo-photo-wrap">
                                    <label style="font-size: 0.85rem; font-weight: bold; display: block; margin-bottom: 4px;">Uploaded Photo:</label>
                                    <a href="<?= htmlspecialchars($order['attachment']); ?>" target="_blank">
                                        <img src="<?= htmlspecialchars($order['attachment']); ?>"
                                             alt="Maintenance Evidence"
                                             loading="lazy">
                                    </a>
                                    <br>
                                    <small style="color: #666; font-size: 0.75rem;">(Click to view full size)</small>
                                </div>
                            <?php else: ?>
                                <div class="wo-no-photo">
                                    <i class="fa-solid fa-camera" style="font-size: 1.5rem; display: block; margin-bottom: 4px;"></i>
                                    No photo attached
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Update Form -->
                        <form action="work_orders.php" method="POST" class="wo-update-form">
                            <input type="hidden" name="csrf_token" value="<?= csrf_token(); ?>">
                            <input type="hidden" name="action" value="update_work_order">
                            <input type="hidden" name="request_id" value="<?= $order['id']; ?>">

                            <label>
                                Priority:
                                <select name="priority">
                                    <option value="Low" <?= $priority === 'Low' ? 'selected' : ''; ?>>Low</option>
                                    <option value="Medium" <?= $priority === 'Medium' ? 'selected' : ''; ?>>Medium</option>
                                    <option value="High" <?= $priority === 'High' ? 'selected' : ''; ?>>High</option>
                                    <option value="Emergency" <?= $priority === 'Emergency' ? 'selected' : ''; ?>>Emergency</option>
                                </select>
                            </label>

                            <label>
                                Status:
                                <select name="status">
                                    <option value="Pending" <?= $order['status'] === 'Pending' ? 'selected' : ''; ?>>Pending</option>
                                    <option value="In Progress" <?= $order['status'] === 'In Progress' ? 'selected' : ''; ?>>In Progress</option>
                                    <option value="Completed" <?= $order['status'] === 'Completed' ? 'selected' : ''; ?>>Completed</option>
                                    <option value="Cancelled" <?= $order['status'] === 'Cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                </select>
                            </label>

                            <button type="submit">Update</button>
                        </form>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="wo-empty-state">
                    <i class="fa-solid fa-clipboard-check"></i>
                    No work orders found.
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>