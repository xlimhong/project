<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/db.php';
require_once 'includes/helpers.php';

require_auth();

$user_id   = $_SESSION['user_id'] ?? 0;
$user_role = strtolower($_SESSION['role'] ?? 'student');
$is_admin_or_staff = in_array($user_role, ['admin', 'staff']);

$scope_sql  = $is_admin_or_staff ? "" : "WHERE user_id = :uid";
$scope_bind = $is_admin_or_staff ? [] : ['uid' => $user_id];

// 1. Monthly Trends
$monthly_labels = [];
$monthly_data   = [];
try {
    $stmt = $pdo->prepare("
        SELECT DATE_FORMAT(created_at, '%b %Y') AS ym, COUNT(*) AS cnt
        FROM maintenance_requests
        $scope_sql
        " . ($is_admin_or_staff ? "WHERE" : "AND") . " created_at >= (CURDATE() - INTERVAL 6 MONTH)
        GROUP BY YEAR(created_at), MONTH(created_at)
        ORDER BY YEAR(created_at), MONTH(created_at)
    ");
    $stmt->execute($scope_bind);
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $monthly_labels[] = $row['ym'];
        $monthly_data[]   = (int)$row['cnt'];
    }
} catch (PDOException $e) {}

// 2. Common Issues / Categories
$category_labels = [];
$category_data   = [];
try {
    $stmt = $pdo->prepare("
        SELECT category, COUNT(*) AS cnt
        FROM maintenance_requests
        $scope_sql
        GROUP BY category
        ORDER BY cnt DESC
        LIMIT 6
    ");
    $stmt->execute($scope_bind);
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $category_labels[] = $row['category'];
        $category_data[]   = (int)$row['cnt'];
    }
} catch (PDOException $e) {}

// 3. Completion Rates
$status_labels = ['Completed', 'In Progress', 'Pending', 'Cancelled'];
$status_data   = [0, 0, 0, 0];
try {
    $stmt = $pdo->prepare("
        SELECT status, COUNT(*) as cnt 
        FROM maintenance_requests 
        $scope_sql 
        GROUP BY status
    ");
    $stmt->execute($scope_bind);
    $counts = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    $status_data[0] = (int)($counts['Completed'] ?? 0);
    $status_data[1] = (int)($counts['In Progress'] ?? 0);
    $status_data[2] = (int)($counts['Pending'] ?? 0);
    $status_data[3] = (int)($counts['Cancelled'] ?? 0);
} catch (PDOException $e) {}

// 4. Top Locations
$location_labels = [];
$location_data   = [];
try {
    $stmt = $pdo->prepare("
        SELECT location, COUNT(*) AS cnt
        FROM maintenance_requests
        $scope_sql
        GROUP BY location
        ORDER BY cnt DESC
        LIMIT 5
    ");
    $stmt->execute($scope_bind);
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $location_labels[] = $row['location'];
        $location_data[]   = (int)$row['cnt'];
    }
} catch (PDOException $e) {}

// KPI summary figures derived from the status breakdown already queried above
$total_requests  = array_sum($status_data);
$completed_count = $status_data[0];
$open_count      = $status_data[1] + $status_data[2]; // In Progress + Pending
$completion_rate = $total_requests > 0 ? round(($completed_count / $total_requests) * 100) : 0;
?>

<?php include 'includes/header.php'; ?>

<style>
:root {
    --an-ink: #14202B;
    --an-muted: #64748b;
    --an-border: #e2e8f0;
    --an-navy: #2C4A63;
    --an-amber: #C8862A;
    --an-green: #2F8659;
    --an-red: #C43E30;
    --an-slate: #8A93A0;
    --an-purple: #7C5CA6;
}

/* ---------- Entrance animation keyframes ---------- */
@keyframes an-fade-up {
    from { opacity: 0; transform: translateY(14px); }
    to   { opacity: 1; transform: translateY(0); }
}

@keyframes an-fade-in {
    from { opacity: 0; }
    to   { opacity: 1; }
}

@keyframes an-pop {
    0%   { opacity: 0; transform: scale(0.85); }
    60%  { opacity: 1; transform: scale(1.03); }
    100% { opacity: 1; transform: scale(1); }
}

@keyframes an-shimmer {
    0%   { background-position: -200% 0; }
    100% { background-position: 200% 0; }
}

.an-hero-row {
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
    flex-wrap: wrap;
    gap: 1rem;
    animation: an-fade-up 0.5s ease both;
}

.an-hero-row .welcome-hero h1 {
    background: linear-gradient(90deg, var(--an-ink), var(--an-navy) 60%, var(--an-ink));
    background-size: 200% auto;
    -webkit-background-clip: text;
    background-clip: text;
}

/* ---------- KPI summary strip ---------- */
.an-kpis {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 1rem;
    margin: 1.5rem 0;
}

.an-kpi {
    position: relative;
    overflow: hidden;
    background: #fff;
    border: 1px solid var(--an-border);
    border-radius: 14px;
    padding: 1.1rem 1.25rem;
    display: flex;
    align-items: center;
    gap: 0.9rem;
    opacity: 0;
    animation: an-fade-up 0.55s ease forwards;
    transition: transform 0.25s ease, box-shadow 0.25s ease, border-color 0.25s ease;
    will-change: transform;
}

.an-kpi:hover {
    transform: translateY(-4px);
    box-shadow: 0 10px 24px rgba(20, 32, 43, 0.08);
    border-color: transparent;
}

.an-kpi::after {
    content: '';
    position: absolute;
    inset: 0;
    background: linear-gradient(120deg, transparent 30%, rgba(255,255,255,0.55) 48%, transparent 66%);
    background-size: 200% 100%;
    background-position: 200% 0;
    pointer-events: none;
    opacity: 0;
    transition: opacity 0.2s ease;
}

.an-kpi:hover::after {
    opacity: 1;
    animation: an-shimmer 1s ease;
}

.an-kpis .an-kpi:nth-child(1) { animation-delay: 0.05s; }
.an-kpis .an-kpi:nth-child(2) { animation-delay: 0.12s; }
.an-kpis .an-kpi:nth-child(3) { animation-delay: 0.19s; }
.an-kpis .an-kpi:nth-child(4) { animation-delay: 0.26s; }

.an-kpi-icon {
    width: 42px;
    height: 42px;
    border-radius: 11px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.05rem;
    flex-shrink: 0;
    transition: transform 0.25s ease;
}

.an-kpi:hover .an-kpi-icon {
    transform: scale(1.08) rotate(-4deg);
}

.an-kpi-value {
    font-size: 1.55rem;
    font-weight: 700;
    color: var(--an-ink);
    line-height: 1.1;
    font-variant-numeric: tabular-nums;
}

.an-kpi-label {
    font-size: 0.78rem;
    color: var(--an-muted);
    margin-top: 0.2rem;
}

/* ---------- Charts grid ---------- */
.analytics-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 1.5rem;
    margin-bottom: 2.5rem;
}

@media (max-width: 900px) {
    .analytics-grid { grid-template-columns: 1fr; }
    .an-kpis { grid-template-columns: repeat(2, 1fr); }
}

.analytics-card {
    background: #fff;
    border: 1px solid var(--an-border);
    border-radius: 14px;
    padding: 20px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.04);
    opacity: 0;
    animation: an-fade-up 0.6s ease forwards;
    transition: transform 0.28s ease, box-shadow 0.28s ease;
}

.analytics-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 14px 30px rgba(20, 32, 43, 0.09);
}

.analytics-grid .analytics-card:nth-child(1) { animation-delay: 0.15s; }
.analytics-grid .analytics-card:nth-child(2) { animation-delay: 0.25s; }
.analytics-grid .analytics-card:nth-child(3) { animation-delay: 0.35s; }
.analytics-grid .analytics-card:nth-child(4) { animation-delay: 0.45s; }

.analytics-card-header {
    display: flex;
    align-items: center;
    gap: 0.6rem;
    margin-bottom: 16px;
}

.analytics-card-header .icon {
    width: 28px;
    height: 28px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.8rem;
    flex-shrink: 0;
    transition: transform 0.3s ease;
}

.analytics-card:hover .analytics-card-header .icon {
    transform: scale(1.1) rotate(6deg);
}

.analytics-card h4 {
    margin: 0;
    font-size: 1rem;
    font-weight: 700;
    color: var(--an-ink);
}

.chart-container {
    position: relative;
    height: 300px;
    width: 100%;
    animation: an-fade-in 0.8s ease 0.3s both;
}

.chart-empty {
    height: 300px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    color: var(--an-slate);
    gap: 0.5rem;
    text-align: center;
    animation: an-fade-in 0.6s ease both;
}

.chart-empty i {
    font-size: 1.6rem;
    opacity: 0.6;
    animation: an-pop 0.5s ease both;
}

.chart-empty span {
    font-size: 0.85rem;
}

@media (prefers-reduced-motion: reduce) {
    .an-hero-row,
    .an-kpi,
    .analytics-card,
    .chart-container,
    .chart-empty,
    .chart-empty i {
        animation: none !important;
        opacity: 1 !important;
    }
    .an-kpi:hover,
    .analytics-card:hover {
        transform: none;
    }
}
</style>

<div class="an-hero-row">
    <div class="welcome-hero" style="margin: 0;">
        <h1>Analytics & Maintenance Insights 📊</h1>
        <p><?= $is_admin_or_staff ? 'Detailed performance reporting and asset operational trends across campus.' : 'Your personal maintenance request activity and trends.'; ?></p>
    </div>
</div>

<!-- KPI Summary Strip -->
<div class="an-kpis">
    <div class="an-kpi">
        <div class="an-kpi-icon" style="background: #E7EEF4; color: var(--an-navy);"><i class="fa-solid fa-clipboard-list"></i></div>
        <div>
            <div class="an-kpi-value" data-count="<?= (int)$total_requests; ?>">0</div>
            <div class="an-kpi-label">Total requests</div>
        </div>
    </div>
    <div class="an-kpi">
        <div class="an-kpi-icon" style="background: #E6F2EC; color: var(--an-green);"><i class="fa-solid fa-circle-check"></i></div>
        <div>
            <div class="an-kpi-value" data-count="<?= (int)$completed_count; ?>">0</div>
            <div class="an-kpi-label">Completed</div>
        </div>
    </div>
    <div class="an-kpi">
        <div class="an-kpi-icon" style="background: #FBF1E1; color: var(--an-amber);"><i class="fa-solid fa-hourglass-half"></i></div>
        <div>
            <div class="an-kpi-value" data-count="<?= (int)$open_count; ?>">0</div>
            <div class="an-kpi-label">Open (pending + in progress)</div>
        </div>
    </div>
    <div class="an-kpi">
        <div class="an-kpi-icon" style="background: #FBEAE8; color: var(--an-red);"><i class="fa-solid fa-gauge-high"></i></div>
        <div>
            <div class="an-kpi-value" data-count="<?= (int)$completion_rate; ?>" data-suffix="%">0%</div>
            <div class="an-kpi-label">Completion rate</div>
        </div>
    </div>
</div>

<div class="analytics-grid">
    <div class="analytics-card">
        <div class="analytics-card-header">
            <span class="icon" style="background: #E7EEF4; color: var(--an-navy);"><i class="fa-solid fa-chart-line"></i></span>
            <h4>Monthly Requests Trend</h4>
        </div>
        <?php if (!empty($monthly_data)): ?>
            <div class="chart-container"><canvas id="monthlyChart"></canvas></div>
        <?php else: ?>
            <div class="chart-empty"><i class="fa-solid fa-chart-line"></i><span>No requests in the last 6 months.</span></div>
        <?php endif; ?>
    </div>

    <div class="analytics-card">
        <div class="analytics-card-header">
            <span class="icon" style="background: #FBF1E1; color: var(--an-amber);"><i class="fa-solid fa-wrench"></i></span>
            <h4>Most Common Maintenance Issues</h4>
        </div>
        <?php if (!empty($category_data)): ?>
            <div class="chart-container"><canvas id="issuesChart"></canvas></div>
        <?php else: ?>
            <div class="chart-empty"><i class="fa-solid fa-wrench"></i><span>No category data yet.</span></div>
        <?php endif; ?>
    </div>

    <div class="analytics-card">
        <div class="analytics-card-header">
            <span class="icon" style="background: #E6F2EC; color: var(--an-green);"><i class="fa-solid fa-chart-pie"></i></span>
            <h4>Ticket Completion Rate</h4>
        </div>
        <?php if (!empty(array_filter($status_data))): ?>
            <div class="chart-container"><canvas id="completionChart"></canvas></div>
        <?php else: ?>
            <div class="chart-empty"><i class="fa-solid fa-chart-pie"></i><span>No tickets recorded yet.</span></div>
        <?php endif; ?>
    </div>

    <div class="analytics-card">
        <div class="analytics-card-header">
            <span class="icon" style="background: #FBEAE8; color: var(--an-red);"><i class="fa-solid fa-map-location-dot"></i></span>
            <h4>Top Locations with Issues</h4>
        </div>
        <?php if (!empty($location_data)): ?>
            <div class="chart-container"><canvas id="buildingsChart"></canvas></div>
        <?php else: ?>
            <div class="chart-empty"><i class="fa-solid fa-map-location-dot"></i><span>No location data yet.</span></div>
        <?php endif; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const inkColor    = '#14202B';
    const gridColor   = '#EEF1F4';
    const brandNavy   = '#2C4A63';
    const brandAmber  = '#C8862A';
    const brandGreen  = '#2F8659';
    const brandRed    = '#C43E30';
    const brandSlate  = '#8A93A0';
    const brandPurple = '#7C5CA6';

    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // ---------- Animated KPI count-up ----------
    function animateCount(el) {
        const target = parseFloat(el.dataset.count || '0');
        const suffix = el.dataset.suffix || '';
        if (reduceMotion || !isFinite(target)) {
            el.textContent = target.toLocaleString() + suffix;
            return;
        }
        const duration = 900;
        const start = performance.now();
        function tick(now) {
            const progress = Math.min((now - start) / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 3); // ease-out-cubic
            const value = Math.round(target * eased);
            el.textContent = value.toLocaleString() + suffix;
            if (progress < 1) requestAnimationFrame(tick);
        }
        requestAnimationFrame(tick);
    }
    document.querySelectorAll('.an-kpi-value[data-count]').forEach(animateCount);

    // ---------- Shared chart options ----------
    const baseOptions = {
        responsive: true,
        maintainAspectRatio: false,
        animation: reduceMotion ? false : { duration: 900, easing: 'easeOutQuart' },
        plugins: {
            legend: {
                position: 'bottom',
                labels: { color: inkColor, boxWidth: 10, padding: 14, font: { size: 11 } }
            },
            tooltip: {
                backgroundColor: '#14202B',
                titleColor: '#fff',
                bodyColor: '#e2e8f0',
                padding: 10,
                cornerRadius: 8,
                displayColors: true
            }
        }
    };

    const monthlyEl = document.getElementById('monthlyChart');
    if (monthlyEl) {
        new Chart(monthlyEl, {
            type: 'line',
            data: {
                labels: <?= json_encode($monthly_labels); ?>,
                datasets: [{
                    label: 'Requests',
                    data: <?= json_encode($monthly_data); ?>,
                    borderColor: brandNavy,
                    backgroundColor: 'rgba(44,74,99,0.08)',
                    pointBackgroundColor: brandNavy,
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 4,
                    pointHoverRadius: 6,
                    borderWidth: 2.5,
                    fill: true,
                    tension: 0.35
                }]
            },
            options: Object.assign({}, baseOptions, {
                plugins: Object.assign({}, baseOptions.plugins, { legend: { display: false } }),
                scales: {
                    x: { grid: { color: gridColor }, ticks: { color: '#64748b' } },
                    y: { grid: { color: gridColor }, ticks: { color: '#64748b', precision: 0 }, beginAtZero: true }
                },
                interaction: { intersect: false, mode: 'index' }
            })
        });
    }

    const issuesEl = document.getElementById('issuesChart');
    if (issuesEl) {
        new Chart(issuesEl, {
            type: 'doughnut',
            data: {
                labels: <?= json_encode($category_labels); ?>,
                datasets: [{
                    data: <?= json_encode($category_data); ?>,
                    backgroundColor: [brandNavy, brandAmber, brandGreen, brandRed, brandPurple, brandSlate],
                    borderWidth: 2,
                    borderColor: '#fff',
                    hoverOffset: 10
                }]
            },
            options: Object.assign({}, baseOptions, {
                cutout: '62%',
                animation: reduceMotion ? false : { animateRotate: true, animateScale: true, duration: 900, easing: 'easeOutQuart' }
            })
        });
    }

    const completionEl = document.getElementById('completionChart');
    if (completionEl) {
        new Chart(completionEl, {
            type: 'doughnut',
            data: {
                labels: <?= json_encode($status_labels); ?>,
                datasets: [{
                    data: <?= json_encode($status_data); ?>,
                    backgroundColor: [brandGreen, brandNavy, brandAmber, brandSlate],
                    borderWidth: 2,
                    borderColor: '#fff',
                    hoverOffset: 10
                }]
            },
            options: Object.assign({}, baseOptions, {
                cutout: '62%',
                animation: reduceMotion ? false : { animateRotate: true, animateScale: true, duration: 900, easing: 'easeOutQuart' }
            })
        });
    }

    const buildingsEl = document.getElementById('buildingsChart');
    if (buildingsEl) {
        new Chart(buildingsEl, {
            type: 'bar',
            data: {
                labels: <?= json_encode($location_labels); ?>,
                datasets: [{
                    label: 'Issues Reported',
                    data: <?= json_encode($location_data); ?>,
                    backgroundColor: brandNavy,
                    hoverBackgroundColor: brandAmber,
                    borderRadius: 6,
                    maxBarThickness: 42
                }]
            },
            options: Object.assign({}, baseOptions, {
                plugins: Object.assign({}, baseOptions.plugins, { legend: { display: false } }),
                scales: {
                    x: { grid: { display: false }, ticks: { color: '#64748b' } },
                    y: { grid: { color: gridColor }, ticks: { color: '#64748b', precision: 0 }, beginAtZero: true }
                }
            })
        });
    }
});
</script>

<?php include 'includes/footer.php'; ?>