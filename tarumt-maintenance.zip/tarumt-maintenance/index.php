<?php
require_once 'includes/helpers.php';
require_once 'config/db.php';

$error = '';

// If already logged in, redirect to dashboard
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate CSRF token on login
    verify_csrf();

    $tarumt_id = trim($_POST['tarumt_id'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!empty($tarumt_id) && !empty($password)) {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE tarumt_id = ?");
        $stmt->execute([$tarumt_id]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['role'] = $user['role'];
            header("Location: dashboard.php");
            exit();
        } else {
            $error = "Invalid TAR UMT ID or password.";
        }
    } else {
        $error = "Please fill in all fields.";
    }
}
?>

<?php include 'includes/header.php'; ?>

<div class="auth-card">
    <div class="auth-header">
        <h2>TAR UMT Portal</h2>
        <p>Enter your account credentials to log in</p>
    </div>

    <!-- Display system flash notifications (e.g. CSRF/Session redirects) -->
    <?= display_flash(); ?>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form action="index.php" method="POST">
        <input type="hidden" name="csrf_token" value="<?= csrf_token(); ?>">

        <div class="form-group">
            <label for="tarumt_id">TAR UMT ID / Student ID</label>
            <input type="text" id="tarumt_id" name="tarumt_id" placeholder="e.g. 22AAB12345" required autocomplete="username">
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" placeholder="••••••••" required autocomplete="current-password">
        </div>
        <button type="submit" class="btn">Login</button>
        <p class="form-footer">Don't have an account? <a href="register.php">Register here</a></p>
    </form>
</div>

<?php include 'includes/footer.php'; ?>