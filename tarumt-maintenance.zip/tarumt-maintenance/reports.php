<?php
require_once 'config/db.php';
require_once 'includes/helpers.php';
require_auth(['admin', 'staff']);

// Filter Parameters
$status = $_GET['status'] ?? '';
$category_id = $_GET['category_id'] ?? '';
$priority = $_GET['priority'] ?? '';

// Build Query
$sql = "SELECT r.*, c.category_name, l.block_name, l.room_name, u.name as requester_name 
        FROM maintenance_requests r 
        JOIN categories c ON r.category_id=c.id 
        JOIN locations l ON r.location_id=l.id 
        JOIN users u ON r.user_id=u.id WHERE 1=1";

$params = [];

if (!empty($status)) {
    $sql .= " AND r.status = ?";
    $params[] = $status;
}
if (!empty($category_id)) {
    $sql .= " AND r.category_id = ?";
    $params[] = $category_id;
}
if (!empty($priority)) {
    $sql .= " AND r.priority = ?";
    $params[] = $priority;
}

$sql .= " ORDER BY r.created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$results = $stmt->fetchAll();

// KPI Calculations
$total_cost = $pdo->query("SELECT SUM(cost) FROM work_orders")->fetchColumn() ?: 0.00;
$categories = $pdo->query("SELECT * FROM categories")->fetchAll();
?>

<?php include 'includes/header.php'; ?>

<div class="container-centered">
    
    <!-- Filter Card -->
    <div class="card" style="padding: 1.5rem; margin-bottom: 2rem;">
        <div class="card-header" style="padding:0 0 1rem 0;">
            <h2>Search & Filter Reports</h2>
        </div>
        <form action="reports.php" method="GET" class="form-row">
            <div class="form-group">
                <label>Status</label>
                <select name="status">
                    <option value="">All Statuses</option>
                    <option value="Pending" <?= $status==='Pending'?'selected':''; ?>>Pending</option>
                    <option value="Assigned" <?= $status==='Assigned'?'selected':''; ?>>Assigned</option>
                    <option value="In Progress" <?= $status==='In Progress'?'selected':''; ?>>In Progress</option>
                    <option value="Completed" <?= $status==='Completed'?'selected':''; ?>>Completed</option>
                </select>
            </div>
            <div class="form-group">
                <label>Category</label>
                <select name="category_id">
                    <option value="">All Categories</option>
                    <?php foreach($categories as $cat): ?>
                        <option value="<?= $cat['id']; ?>" <?= $category_id==$cat['id']?'selected':''; ?>><?= $cat['category_name']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Priority</label>
                <select name="priority">
                    <option value="">All Priorities</option>
                    <option value="Low" <?= $priority==='Low'?'selected':''; ?>>Low</option>
                    <option value="Medium" <?= $priority==='Medium'?'selected':''; ?>>Medium</option>
                    <option value="High" <?= $priority==='High'?'selected':''; ?>>High</option>
                    <option value="Emergency" <?= $priority==='Emergency'?'selected':''; ?>>Emergency</option>
                </select>
            </div>
            <div class="form-group" style="display:flex; align-items:flex-end;">
                <button type="submit" class="btn">Apply Filter</button>
            </div>
        </form>
    </div>

    <!-- Filter Results Table -->
    <div class="card">
        <div class="card-header">
            <h2>Filtered Results (Total Maintenance Cost: RM <?= number_format($total_cost, 2); ?>)</h2>
        </div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Ticket No</th>
                        <th>Requester</th>
                        <th>Category</th>
                        <th>Location</th>
                        <th>Priority</th>
                        <th>Status</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($results as $res): ?>
                        <tr>
                            <td><strong><?= $res['ticket_no']; ?></strong></td>
                            <td><?= htmlspecialchars($res['requester_name']); ?></td>
                            <td><?= htmlspecialchars($res['category_name']); ?></td>
                            <td><?= htmlspecialchars($res['block_name'].' '.$res['room_name']); ?></td>
                            <td><span class="priority-<?= strtolower($res['priority']); ?>"><?= $res['priority']; ?></span></td>
                            <td><span class="badge status-<?= strtolower(str_replace(' ', '-', $res['status'])); ?>"><?= $res['status']; ?></span></td>
                            <td><?= date('d M Y', strtotime($res['created_at'])); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>