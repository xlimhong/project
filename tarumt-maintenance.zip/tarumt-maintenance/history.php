<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/db.php';
require_once 'includes/helpers.php';

require_auth();

$user_id           = $_SESSION['user_id'];
$user_role         = strtolower($_SESSION['role'] ?? 'student');
$is_admin_or_staff = in_array($user_role, ['admin', 'staff']);

$status_filter = trim($_GET['status'] ?? '');
$search_query  = trim($_GET['search'] ?? '');

// Handle Status Updates directly from History page (Admin / Staff only)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_status') {
    verify_csrf();
    if ($is_admin_or_staff) {
        $req_id     = (int)($_POST['request_id'] ?? 0);
        $new_status = trim($_POST['status'] ?? 'Pending');

        try {
            // Fetch ticket details prior to update to notify user
            $info_stmt = $pdo->prepare("SELECT user_id, ticket_no, category FROM maintenance_requests WHERE id = ?");
            $info_stmt->execute([$req_id]);
            $ticket = $info_stmt->fetch(PDO::FETCH_ASSOC);

            $stmt = $pdo->prepare("UPDATE maintenance_requests SET status = ? WHERE id = ?");
            $stmt->execute([$new_status, $req_id]);

            // Send notification to the user
            if ($ticket && !empty($ticket['user_id'])) {
                $ticket_label  = !empty($ticket['ticket_no']) ? $ticket['ticket_no'] : '#' . str_pad((string)$req_id, 4, '0', STR_PAD_LEFT);
                $notif_type    = $new_status === 'Completed' ? 'success' : ($new_status === 'Cancelled' ? 'danger' : 'info');
                $notif_title   = $new_status === 'Completed' ? "Request Completed" : "Ticket Status Updated";
                $notif_message = $new_status === 'Completed'
                    ? "Great news! Your request {$ticket_label} ({$ticket['category']}) has been completed."
                    : "Your request {$ticket_label} status was changed to '{$new_status}'.";

                create_notification(
                    $pdo,
                    $notif_title,
                    $notif_message,
                    $notif_type,
                    'history.php',
                    (int)$ticket['user_id'],
                    null
                );
            }

            set_flash('success', "Ticket #{$req_id} status updated to {$new_status}.");
        } catch (PDOException $e) {
            set_flash('error', "Failed to update ticket status.");
        }
    }
    header("Location: history.php" . ($status_filter ? "?status=" . urlencode($status_filter) : ""));
    exit();
}

// Handle Delete requests (Owner can delete their own; Admin / Staff can delete any)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_request') {
    verify_csrf();

    $req_id = (int)($_POST['request_id'] ?? 0);

    try {
        // Confirm the record exists and check ownership before deleting
        $check = $pdo->prepare("SELECT user_id, attachment FROM maintenance_requests WHERE id = ?");
        $check->execute([$req_id]);
        $record = $check->fetch(PDO::FETCH_ASSOC);

        if (!$record) {
            set_flash('error', "Ticket #{$req_id} was not found.");
        } elseif (!$is_admin_or_staff && (int)$record['user_id'] !== (int)$user_id) {
            set_flash('error', "You can only delete your own tickets.");
        } else {
            $stmt = $pdo->prepare("DELETE FROM maintenance_requests WHERE id = ?");
            $stmt->execute([$req_id]);

            // Best-effort cleanup of the uploaded attachment file
            if (!empty($record['attachment']) && is_file($record['attachment'])) {
                @unlink($record['attachment']);
            }

            set_flash('success', "Ticket #{$req_id} was deleted.");
        }
    } catch (PDOException $e) {
        set_flash('error', "Failed to delete ticket: " . $e->getMessage());
    }

    header("Location: history.php" . ($status_filter ? "?status=" . urlencode($status_filter) : ""));
    exit();
}

// Build Search & Filter SQL Query
$sql = "SELECT r.*, u.name as requester_name FROM maintenance_requests r LEFT JOIN users u ON r.user_id = u.id WHERE 1=1";
$params = [];

if (!$is_admin_or_staff) {
    $sql .= " AND r.user_id = ?";
    $params[] = $user_id;
}

if (!empty($status_filter)) {
    $sql .= " AND r.status = ?";
    $params[] = $status_filter;
}

if (!empty($search_query)) {
    $sql .= " AND (r.location LIKE ? OR r.category LIKE ? OR r.description LIKE ?)";
    $params[] = "%{$search_query}%";
    $params[] = "%{$search_query}%";
    $params[] = "%{$search_query}%";
}

$sql .= " ORDER BY r.id DESC";

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $history = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $history = [];
}
?>

<?php include 'includes/header.php'; ?>

<style>
    /* Keyframe Animations */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(12px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    @keyframes modalZoom {
        from {
            opacity: 0;
            transform: scale(0.85);
        }
        to {
            opacity: 1;
            transform: scale(1);
        }
    }

    @keyframes pulseSoft {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.6; }
    }

    /* Container & Toolbar */
    .hist-controls {
        display: flex;
        gap: 0.75rem;
        margin-bottom: 1.5rem;
        flex-wrap: wrap;
        background: rgba(255, 255, 255, 0.8);
        padding: 1rem;
        border-radius: 12px;
        border: 1px solid #e2e8f0;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.03);
        backdrop-filter: blur(6px);
    }

    .hist-controls input[type="text"],
    .hist-controls select {
        height: 42px;
        font-size: 0.9rem;
        border-radius: 8px;
        border: 1px solid #cbd5e1;
        padding: 0 0.85rem;
        transition: all 0.2s ease-in-out;
        outline: none;
    }

    .hist-controls input[type="text"]:focus,
    .hist-controls select:focus {
        border-color: #3b82f6;
        box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.15);
    }

    /* Modern Table Styling */
    .data-table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0;
    }

    .data-table th {
        background: #f8fafc;
        color: #475569;
        font-weight: 600;
        font-size: 0.8rem;
        text-transform: uppercase;
        letter-spacing: 0.04em;
        padding: 0.85rem 1rem;
        border-bottom: 2px solid #e2e8f0;
    }

    .data-table td {
        padding: 0.9rem 1rem;
        border-bottom: 1px solid #f1f5f9;
        vertical-align: middle;
        font-size: 0.9rem;
    }

    /* Staggered Row Animation */
    .data-table tbody tr {
        animation: fadeInUp 0.4s ease forwards;
        opacity: 0;
        transition: background-color 0.2s ease, transform 0.2s ease;
    }

    .data-table tbody tr:nth-child(1) { animation-delay: 0.05s; }
    .data-table tbody tr:nth-child(2) { animation-delay: 0.10s; }
    .data-table tbody tr:nth-child(3) { animation-delay: 0.15s; }
    .data-table tbody tr:nth-child(4) { animation-delay: 0.20s; }
    .data-table tbody tr:nth-child(5) { animation-delay: 0.25s; }
    .data-table tbody tr:nth-child(n+6) { animation-delay: 0.30s; }

    .data-table tbody tr:hover {
        background-color: #f8fafc;
    }

    /* Tags & Badges */
    .ticket-tag {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-weight: 700;
        background: #f1f5f9;
        color: #334155;
        padding: 0.25rem 0.55rem;
        border-radius: 6px;
        font-size: 0.825rem;
        border: 1px solid #e2e8f0;
    }

    .badge {
        display: inline-flex;
        align-items: center;
        gap: 0.4rem;
        padding: 0.35rem 0.75rem;
        border-radius: 50px;
        font-size: 0.8rem;
        font-weight: 600;
        box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
    }

    .badge-completed { background: #dcfce7; color: #15803d; border: 1px solid #bbf7d0; }
    .badge-progress  { background: #e0f2fe; color: #0369a1; border: 1px solid #bae6fd; }
    .badge-pending   { background: #fef3c7; color: #b45309; border: 1px solid #fde68a; }
    .badge-cancelled { background: #fee2e2; color: #b91c1c; border: 1px solid #fecaca; }

    .badge-progress i {
        animation: pulseSoft 1.5s infinite ease-in-out;
    }

    /* Priority Pills */
    .priority-pill {
        padding: 0.2rem 0.5rem;
        border-radius: 4px;
        font-weight: 600;
        font-size: 0.8rem;
    }

    /* Buttons & Actions */
    .btn {
        transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        border-radius: 8px;
    }

    .btn:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }

    .btn:active {
        transform: translateY(0);
    }

    .row-actions {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        flex-wrap: wrap;
    }

    .btn-icon-danger {
        background: #fff;
        border: 1px solid #fca5a5;
        color: #dc2626;
        width: 34px;
        height: 34px;
        border-radius: 8px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.2s ease;
        flex-shrink: 0;
    }

    .btn-icon-danger:hover {
        background: #fee2e2;
        border-color: #ef4444;
        color: #991b1b;
        transform: translateY(-1px);
        box-shadow: 0 2px 8px rgba(220, 38, 38, 0.15);
    }

    /* Image Preview Thumbnail */
    .thumb-img {
        width: 44px;
        height: 44px;
        object-fit: cover;
        border-radius: 8px;
        border: 1px solid #cbd5e1;
        cursor: pointer;
        transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
        box-shadow: 0 1px 3px rgba(0,0,0,0.08);
    }

    .thumb-img:hover {
        transform: scale(1.12);
        box-shadow: 0 6px 16px rgba(0,0,0,0.15);
        border-color: #3b82f6;
    }

    .thumb-none {
        color: #94a3b8;
        font-size: 0.8rem;
        white-space: nowrap;
    }

    /* Image Modal Overlay */
    .modal-overlay {
        display: none;
        position: fixed;
        z-index: 99999;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background-color: rgba(15, 23, 42, 0.75);
        backdrop-filter: blur(8px);
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: opacity 0.3s ease;
    }

    .modal-content {
        max-width: 85vw;
        max-height: 85vh;
        border-radius: 12px;
        box-shadow: 0 20px 40px rgba(0,0,0,0.3);
        object-fit: contain;
        animation: modalZoom 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
    }

    .modal-close {
        position: absolute;
        top: 25px;
        right: 35px;
        color: #f8fafc;
        font-size: 32px;
        font-weight: 300;
        transition: transform 0.2s ease, color 0.2s ease;
    }

    .modal-close:hover {
        transform: scale(1.2);
        color: #ef4444;
    }
</style>

<div class="page-content">
    <?= display_flash(); ?>

    <div class="card" style="border-radius: 14px; border: 1px solid #e2e8f0; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.03);">
        <div class="card-header" style="flex-wrap: wrap; gap: 1rem; padding: 1.25rem 1.5rem; background: #fff;">
            <div>
                <h2 style="display: flex; align-items: center; gap: 0.5rem; font-size: 1.35rem; color: #1e293b;">
                    <i class="fa-solid fa-clock-rotate-left" style="color: #3b82f6;"></i> Maintenance Request History
                </h2>
                <p style="color: #64748b; font-size: 0.875rem; margin-top: 0.25rem;">
                    <?= $is_admin_or_staff ? 'Complete log of all campus maintenance reports.' : 'Complete record of your reported issues.'; ?>
                </p>
            </div>
            <a href="submit_request.php" class="btn btn-primary" style="display: inline-flex; align-items: center; gap: 0.5rem; padding: 0.6rem 1.2rem;">
                <i class="fa-solid fa-plus"></i> Report New Issue
            </a>
        </div>

        <div style="padding: 1.25rem 1.5rem;">
            <!-- Filter & Search Controls -->
            <form action="history.php" method="GET" class="hist-controls">
                <div style="flex: 1; min-width: 220px;">
                    <input type="text" name="search" value="<?= htmlspecialchars($search_query); ?>" placeholder="Search location, category, description..." style="width: 100%;">
                </div>
                <div style="width: 180px;">
                    <select name="status" onchange="this.form.submit()" style="width: 100%;">
                        <option value="">All Statuses</option>
                        <option value="Pending" <?= $status_filter === 'Pending' ? 'selected' : ''; ?>>Pending</option>
                        <option value="In Progress" <?= $status_filter === 'In Progress' ? 'selected' : ''; ?>>In Progress</option>
                        <option value="Completed" <?= $status_filter === 'Completed' ? 'selected' : ''; ?>>Completed</option>
                        <option value="Cancelled" <?= $status_filter === 'Cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-secondary" style="height: 42px; padding: 0 18px; display: inline-flex; align-items: center; gap: 0.4rem;">
                    <i class="fa-solid fa-filter"></i> Filter
                </button>
                <?php if (!empty($status_filter) || !empty($search_query)): ?>
                    <a href="history.php" class="btn btn-secondary" style="height: 42px; padding: 0 14px; display: inline-flex; align-items: center; gap: 0.3rem;">
                        <i class="fa-solid fa-xmark"></i> Clear
                    </a>
                <?php endif; ?>
            </form>

            <!-- History Records Table -->
            <div class="table-responsive" style="border-radius: 10px; border: 1px solid #e2e8f0;">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Ticket ID</th>
                            <?php if ($is_admin_or_staff): ?><th>Reported By</th><?php endif; ?>
                            <th>Location</th>
                            <th>Category</th>
                            <th>Description</th>
                            <th>Photo</th>
                            <th>Priority</th>
                            <th>Status</th>
                            <th>Date Reported</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($history)): ?>
                            <?php foreach ($history as $req):
                                $can_delete = $is_admin_or_staff || (int)$req['user_id'] === (int)$user_id;
                                $ticket_tag = '#' . str_pad($req['id'], 4, '0', STR_PAD_LEFT);
                            ?>
                                <tr>
                                    <td><span class="ticket-tag"><?= $ticket_tag; ?></span></td>
                                    <?php if ($is_admin_or_staff): ?>
                                        <td><strong><?= htmlspecialchars($req['requester_name'] ?? 'User'); ?></strong></td>
                                    <?php endif; ?>
                                    <td><?= htmlspecialchars($req['location'] ?? 'N/A'); ?></td>
                                    <td><span style="background: #f1f5f9; padding: 0.2rem 0.5rem; border-radius: 6px; font-size: 0.85rem; border: 1px solid #e2e8f0;"><?= htmlspecialchars($req['category'] ?? 'General'); ?></span></td>
                                    <td style="max-width: 220px; word-break: break-word; color: #475569;"><?= htmlspecialchars($req['description'] ?? ''); ?></td>

                                    <!-- Photo Attachment -->
                                    <td>
                                        <?php if (!empty($req['attachment'])): ?>
                                            <img src="<?= htmlspecialchars($req['attachment']); ?>"
                                                 alt="Evidence"
                                                 class="thumb-img"
                                                 onclick="openImageModal('<?= htmlspecialchars($req['attachment']); ?>')"
                                                 title="Click to zoom image">
                                        <?php else: ?>
                                            <span class="thumb-none"><i class="fa-solid fa-image-slash"></i> None</span>
                                        <?php endif; ?>
                                    </td>

                                    <td>
                                        <span class="priority-pill">
                                            <?= htmlspecialchars($req['priority'] ?? 'Medium'); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($req['status'] === 'Completed'): ?>
                                            <span class="badge badge-completed"><i class="fa-solid fa-circle-check"></i> Completed</span>
                                        <?php elseif ($req['status'] === 'In Progress'): ?>
                                            <span class="badge badge-progress"><i class="fa-solid fa-spinner fa-spin"></i> In Progress</span>
                                        <?php elseif ($req['status'] === 'Cancelled'): ?>
                                            <span class="badge badge-cancelled"><i class="fa-solid fa-circle-xmark"></i> Cancelled</span>
                                        <?php else: ?>
                                            <span class="badge badge-pending"><i class="fa-solid fa-clock"></i> Pending</span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="color: #64748b; font-size: 0.85rem; white-space: nowrap;"><?= date('d M Y, h:i A', strtotime($req['created_at'] ?? 'now')); ?></td>
                                    <td>
                                        <div class="row-actions">
                                            <?php if ($is_admin_or_staff): ?>
                                                <form action="history.php" method="POST" style="display: flex; gap: 0.4rem; align-items: center;">
                                                    <input type="hidden" name="csrf_token" value="<?= csrf_token(); ?>">
                                                    <input type="hidden" name="action" value="update_status">
                                                    <input type="hidden" name="request_id" value="<?= $req['id']; ?>">
                                                    <select name="status" style="height: 34px; padding: 0 8px; font-size: 0.8rem; border-radius: 6px; border: 1px solid #cbd5e1;">
                                                        <option value="Pending" <?= $req['status'] === 'Pending' ? 'selected' : ''; ?>>Pending</option>
                                                        <option value="In Progress" <?= $req['status'] === 'In Progress' ? 'selected' : ''; ?>>In Progress</option>
                                                        <option value="Completed" <?= $req['status'] === 'Completed' ? 'selected' : ''; ?>>Completed</option>
                                                        <option value="Cancelled" <?= $req['status'] === 'Cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                                    </select>
                                                    <button type="submit" class="btn btn-secondary" style="padding: 4px 10px; font-size: 0.78rem; height: 34px;">Save</button>
                                                </form>
                                            <?php endif; ?>

                                            <?php if ($can_delete): ?>
                                                <form action="history.php" method="POST"
                                                      onsubmit="return confirm('Delete ticket <?= $ticket_tag; ?>? This action cannot be undone.');">
                                                    <input type="hidden" name="csrf_token" value="<?= csrf_token(); ?>">
                                                    <input type="hidden" name="action" value="delete_request">
                                                    <input type="hidden" name="request_id" value="<?= $req['id']; ?>">
                                                    <button type="submit" class="btn-icon-danger" title="Delete ticket <?= $ticket_tag; ?>">
                                                        <i class="fa-solid fa-trash-can"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="<?= $is_admin_or_staff ? '10' : '9'; ?>" style="text-align: center; color: #94a3b8; padding: 3rem 1rem;">
                                    <i class="fa-solid fa-box-open" style="font-size: 2.5rem; margin-bottom: 0.75rem; color: #cbd5e1; display: block;"></i>
                                    No maintenance history records match your query.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Image Modal Overlay -->
<div id="imageModal" class="modal-overlay" onclick="closeImageModal()">
    <span class="modal-close">&times;</span>
    <img id="modalImg" class="modal-content" src="" alt="Enlarged evidence photo">
</div>

<script>
function openImageModal(imgSrc) {
    const modal = document.getElementById('imageModal');
    const img = document.getElementById('modalImg');
    img.src = imgSrc;
    modal.style.display = 'flex';
}

function closeImageModal() {
    document.getElementById('imageModal').style.display = 'none';
}

// Close modal when pressing the Escape key
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        closeImageModal();
    }
});
</script>

<?php include 'includes/footer.php'; ?>