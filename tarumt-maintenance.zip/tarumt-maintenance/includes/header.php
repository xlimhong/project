<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$currentPage = basename($_SERVER['PHP_SELF']);
$role = strtolower($_SESSION['role'] ?? 'student');
$userId = $_SESSION['user_id'] ?? 0;

$unreadNotifications = [];
$unreadCount = 0;

if ($userId > 0 && isset($pdo)) {
    try {
        // Auto-check and create missing columns if legacy 'notifications' table exists
        $notifColumns = $pdo->query("SHOW COLUMNS FROM notifications")->fetchAll(PDO::FETCH_COLUMN);
        if (!in_array('role', $notifColumns)) {
            $pdo->exec("ALTER TABLE notifications ADD COLUMN role VARCHAR(50) NULL");
        }
        if (!in_array('link', $notifColumns)) {
            $pdo->exec("ALTER TABLE notifications ADD COLUMN link VARCHAR(255) DEFAULT 'dashboard.php'");
        }

        // Admin, staff, and technician all share the same "management" notification pool
        // so a ticket notified to 'technician' is still visible when an admin logs in.
        $is_management = in_array($role, ['admin', 'staff', 'technician']);

        if ($is_management) {
            $stmt = $pdo->prepare("
                SELECT * FROM notifications 
                WHERE (user_id = :user_id 
                       OR LOWER(role) IN ('admin', 'staff', 'technician')
                       OR (user_id IS NULL AND role IS NULL))
                  AND is_read = 0 
                ORDER BY created_at DESC 
                LIMIT 5
            ");
            $stmt->execute([':user_id' => $userId]);
        } else {
            $stmt = $pdo->prepare("
                SELECT * FROM notifications 
                WHERE (user_id = :user_id 
                       OR LOWER(role) = :role
                       OR (user_id IS NULL AND role IS NULL))
                  AND is_read = 0 
                ORDER BY created_at DESC 
                LIMIT 5
            ");
            $stmt->execute([
                ':user_id' => $userId,
                ':role'    => $role
            ]);
        }
        $unreadNotifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $unreadCount = count($unreadNotifications);
    } catch (PDOException $e) {
        error_log("Notification error: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TAR UMT School Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* ===== Navbar motion & polish layer (does not touch css/style.css) ===== */

        @keyframes navSlideFade {
            from { opacity: 0; transform: translateY(-8px) scale(0.98); }
            to   { opacity: 1; transform: translateY(0) scale(1); }
        }

        @keyframes navItemRise {
            from { opacity: 0; transform: translateX(-6px); }
            to   { opacity: 1; transform: translateX(0); }
        }

        @keyframes navBadgePop {
            0%   { transform: scale(0); opacity: 0; }
            60%  { transform: scale(1.25); opacity: 1; }
            100% { transform: scale(1); opacity: 1; }
        }

        @keyframes navBellRing {
            0%, 100% { transform: rotate(0deg); }
            15% { transform: rotate(14deg); }
            30% { transform: rotate(-12deg); }
            45% { transform: rotate(8deg); }
            60% { transform: rotate(-6deg); }
            75% { transform: rotate(3deg); }
        }

        @keyframes navUnreadPulse {
            0%   { box-shadow: 0 0 0 0 rgba(200, 16, 46, 0.35); }
            70%  { box-shadow: 0 0 0 6px rgba(200, 16, 46, 0); }
            100% { box-shadow: 0 0 0 0 rgba(200, 16, 46, 0); }
        }

        @media (prefers-reduced-motion: reduce) {
            .nav-dropdown-menu, .notif-dropdown, .notif-badge, .notif-item, .notification-btn.has-unread {
                animation: none !important;
                transition: none !important;
            }
        }

        .menu-toggle-btn {
            transition: background-color 0.15s ease, transform 0.15s ease;
        }

        .menu-toggle-btn:hover {
            transform: translateY(-1px);
        }

        .menu-toggle-btn i {
            transition: transform 0.25s ease;
        }

        .menu-toggle-btn.active i {
            transform: rotate(90deg);
        }

        .notification-btn {
            position: relative;
            transition: transform 0.15s ease;
        }

        .notification-btn:hover {
            transform: translateY(-1px);
        }

        .notification-btn.has-unread i {
            animation: navBellRing 1.8s ease-in-out infinite;
            transform-origin: top center;
        }

        .notif-badge {
            animation: navBadgePop 0.35s cubic-bezier(0.34, 1.56, 0.64, 1) both;
        }

        /* Dropdown menu entrance */
        .nav-dropdown-menu {
            transform-origin: top center;
            transition: opacity 0.18s ease, transform 0.18s ease, visibility 0.18s ease;
        }

        .nav-dropdown-menu.show {
            animation: navSlideFade 0.2s ease both;
        }

        .dropdown-nav-list li {
            opacity: 0;
        }

        .nav-dropdown-menu.show .dropdown-nav-list li {
            animation: navItemRise 0.28s ease both;
        }

        .nav-dropdown-menu.show .dropdown-nav-list li:nth-child(1)  { animation-delay: 0.02s; }
        .nav-dropdown-menu.show .dropdown-nav-list li:nth-child(2)  { animation-delay: 0.05s; }
        .nav-dropdown-menu.show .dropdown-nav-list li:nth-child(3)  { animation-delay: 0.08s; }
        .nav-dropdown-menu.show .dropdown-nav-list li:nth-child(4)  { animation-delay: 0.11s; }
        .nav-dropdown-menu.show .dropdown-nav-list li:nth-child(5)  { animation-delay: 0.14s; }
        .nav-dropdown-menu.show .dropdown-nav-list li:nth-child(6)  { animation-delay: 0.17s; }
        .nav-dropdown-menu.show .dropdown-nav-list li:nth-child(7)  { animation-delay: 0.20s; }
        .nav-dropdown-menu.show .dropdown-nav-list li:nth-child(8)  { animation-delay: 0.23s; }
        .nav-dropdown-menu.show .dropdown-nav-list li:nth-child(9)  { animation-delay: 0.26s; }
        .nav-dropdown-menu.show .dropdown-nav-list li:nth-child(10) { animation-delay: 0.29s; }

        .dropdown-nav-list a {
            position: relative;
            transition: background-color 0.15s ease, color 0.15s ease, padding-left 0.15s ease;
        }

        .dropdown-nav-list a:hover {
            padding-left: 22px;
        }

        .dropdown-nav-list a.active::before {
            content: "";
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 3px;
            height: 60%;
            background: #c8102e;
            border-radius: 0 3px 3px 0;
        }

        .dropdown-nav-list a i {
            transition: transform 0.15s ease;
        }

        .dropdown-nav-list a:hover i {
            transform: scale(1.12);
        }

        /* Notification dropdown entrance */
        .notif-dropdown {
            transform-origin: top right;
        }

        .notif-dropdown.show {
            animation: navSlideFade 0.2s ease both;
        }

        .notif-item {
            transition: background-color 0.15s ease;
            position: relative;
        }

        .notif-item::before {
            content: "";
            position: absolute;
            left: 6px;
            top: 50%;
            transform: translateY(-50%);
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: #c8102e;
            animation: navUnreadPulse 2s infinite;
        }

        .notif-item a {
            padding-left: 18px !important;
        }

        .notif-item:hover {
            background-color: #f8fafc;
        }

        .mark-read-btn {
            transition: opacity 0.15s ease;
        }

        .mark-read-btn:hover {
            opacity: 0.75;
        }

        .user-badge, .nav-logout, .nav-auth-link {
            transition: transform 0.15s ease, opacity 0.15s ease;
        }

        .user-badge:hover, .nav-logout:hover, .nav-auth-link:hover {
            transform: translateY(-1px);
        }

        .nav-brand {
            transition: opacity 0.15s ease;
        }

        .nav-brand:hover {
            opacity: 0.85;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="nav-left">
            <button class="menu-toggle-btn" id="menuToggleBtn" type="button" aria-label="Toggle Navigation">
                <i class="fa-solid fa-bars"></i>
            </button>

            <a href="dashboard.php" class="nav-brand">
                <i class="fa-solid fa-screwdriver-wrench"></i>
                <div class="nav-brand-text">
                    <span class="brand-title">TAR UMT</span>
                    <span class="brand-subtitle">Maintenance System</span>
                </div>
            </a>
        </div>

        <div class="nav-right">
            <?php if (isset($_SESSION['user_id'])): ?>
                <!-- Notification Bell Toggle -->
                <div class="notification-wrapper">
                    <button class="notification-btn <?= $unreadCount > 0 ? 'has-unread' : ''; ?>" id="notifBtn" type="button" aria-label="Notifications">
                        <i class="fa-solid fa-bell"></i>
                        <?php if ($unreadCount > 0): ?>
                            <span class="notif-badge"><?= $unreadCount; ?></span>
                        <?php endif; ?>
                    </button>

                    <!-- Notification Dropdown -->
                    <div class="notif-dropdown" id="notifDropdown">
                        <div class="notif-header">
                            <span>Notifications</span>
                            <a href="notifications.php" class="mark-read-btn">View All</a>
                        </div>
                        <ul class="notif-list">
                            <?php if (!empty($unreadNotifications)): ?>
                                <?php foreach ($unreadNotifications as $notif): ?>
                                    <li class="notif-item">
                                        <a href="<?= htmlspecialchars($notif['link'] ?? 'dashboard.php'); ?>">
                                            <strong><?= htmlspecialchars($notif['title']); ?></strong>
                                            <p><?= htmlspecialchars($notif['message']); ?></p>
                                            <small><?= date('d M, g:i a', strtotime($notif['created_at'])); ?></small>
                                        </a>
                                    </li>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <li class="notif-empty">No unread notifications</li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>

                <a href="profile.php" class="user-badge <?= $currentPage === 'profile.php' ? 'active' : ''; ?>">
                    <i class="fa-solid fa-user"></i> <?= htmlspecialchars($_SESSION['name'] ?? 'Profile'); ?> (<?= strtoupper($role); ?>)
                </a>
                <a href="logout.php" class="nav-logout">
                    <i class="fa-solid fa-right-from-bracket"></i> Logout
                </a>
            <?php else: ?>
                <a href="index.php" class="nav-auth-link"><i class="fa-solid fa-right-to-bracket"></i> Login</a>
                <a href="register.php" class="nav-auth-link"><i class="fa-solid fa-user-plus"></i> Register</a>
            <?php endif; ?>
        </div>

        <div class="nav-dropdown-menu" id="navDropdownMenu">
            <ul class="dropdown-nav-list">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <li>
                        <a href="dashboard.php" class="<?= $currentPage === 'dashboard.php' ? 'active' : ''; ?>">
                            <i class="fa-solid fa-gauge"></i> Dashboard
                        </a>
                    </li>
                    <li>
                        <a href="analytics.php" class="<?= $currentPage === 'analytics.php' ? 'active' : ''; ?>">
                            <i class="fa-solid fa-chart-pie"></i> Analytics & Insights
                        </a>
                    </li>
                    <li>
                        <a href="submit_request.php" class="<?= $currentPage === 'submit_request.php' ? 'active' : ''; ?>">
                            <i class="fa-solid fa-pen-to-square"></i> Submit Ticket
                        </a>
                    </li>
                    <li>
                        <a href="history.php" class="<?= $currentPage === 'history.php' ? 'active' : ''; ?>">
                            <i class="fa-solid fa-clock-rotate-left"></i> History
                        </a>
                    </li>
                    <li>
                        <a href="feedback.php" class="<?= $currentPage === 'feedback.php' ? 'active' : ''; ?>">
                            <i class="fa-solid fa-comment-dots"></i> Feedback
                        </a>
                    </li>

                    <?php if (in_array($role, ['admin', 'staff', 'technician'])): ?>
                        <li class="menu-divider">STAFF & ADMIN or TECHNICIAN</li>
                        <li>
                            <a href="scheduled_maintenance.php" class="<?= $currentPage === 'scheduled_maintenance.php' ? 'active' : ''; ?>">
                                <i class="fa-solid fa-calendar-check"></i> Scheduled Maintenance
                            </a>
                        </li>
                        <li>
                            <a href="work_orders.php" class="<?= $currentPage === 'work_orders.php' ? 'active' : ''; ?>">
                                <i class="fa-solid fa-gears"></i> Work Orders
                            </a>
                        </li>
                        <li>
                            <a href="assets.php" class="<?= $currentPage === 'assets.php' ? 'active' : ''; ?>">
                                <i class="fa-solid fa-boxes-stacked"></i> Assets
                            </a>
                        </li>
                        <li>
                            <a href="inventory.php" class="<?= $currentPage === 'inventory.php' ? 'active' : ''; ?>">
                                <i class="fa-solid fa-warehouse"></i> Inventory
                            </a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const menuBtn = document.getElementById('menuToggleBtn');
            const dropdownMenu = document.getElementById('navDropdownMenu');
            const notifBtn = document.getElementById('notifBtn');
            const notifDropdown = document.getElementById('notifDropdown');

            if (menuBtn && dropdownMenu) {
                menuBtn.addEventListener('click', function(e) {
                    e.stopPropagation();
                    dropdownMenu.classList.toggle('show');
                    menuBtn.classList.toggle('active');
                    if (notifDropdown) notifDropdown.classList.remove('show');
                });
            }

            if (notifBtn && notifDropdown) {
                notifBtn.addEventListener('click', function(e) {
                    e.stopPropagation();
                    notifDropdown.classList.toggle('show');
                    notifBtn.classList.remove('has-unread'); // stop the ring once opened
                    if (dropdownMenu) dropdownMenu.classList.remove('show');
                });
            }

            document.addEventListener('click', function(e) {
                if (dropdownMenu && !dropdownMenu.contains(e.target) && !menuBtn.contains(e.target)) {
                    dropdownMenu.classList.remove('show');
                    if (menuBtn) menuBtn.classList.remove('active');
                }
                if (notifDropdown && !notifDropdown.contains(e.target) && !notifBtn.contains(e.target)) {
                    notifDropdown.classList.remove('show');
                }
            });
        });
    </script>
    <div class="page-content">