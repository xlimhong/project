<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Enforce authentication and role-based access without infinite loops
 */
function require_auth(array $allowed_roles = []): void {
    $currentPage = basename($_SERVER['PHP_SELF']);

    // 1. If not logged in, redirect to index.php (unless already on index.php)
    if (!isset($_SESSION['user_id'])) {
        if ($currentPage !== 'index.php') {
            header("Location: index.php");
            exit();
        }
        return;
    }

    // 2. Normalize roles to lowercase to fix case-sensitivity
    $user_role = strtolower($_SESSION['role'] ?? 'student');
    $allowed_roles_lower = array_map('strtolower', $allowed_roles);

    // 3. If user lacks permissions, redirect to dashboard
    if (!empty($allowed_roles_lower) && !in_array($user_role, $allowed_roles_lower)) {
        if ($currentPage !== 'dashboard.php') {
            set_flash('error', "Access denied. You do not have permission to access that page.");
            header("Location: dashboard.php");
            exit();
        }
    }
}

/**
 * Generate CSRF Token for Forms
 */
function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verify CSRF Token on Form POST
 * Replaced die() with a graceful redirect and user notification.
 */
function verify_csrf(): bool {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $token = $_POST['csrf_token'] ?? '';
        
        if (empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
            set_flash('error', "Your session expired or was routed to a new server. Please try submitting again.");
            $referer = $_SERVER['HTTP_REFERER'] ?? 'dashboard.php';
            header("Location: " . $referer);
            exit();
        }
    }
    return true;
}

/**
 * Flash notification helpers
 */
function set_flash(string $type, string $message): void {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function display_flash(): string {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        $typeClass = $flash['type'] === 'success' ? 'alert-success' : ($flash['type'] === 'error' ? 'alert-danger' : 'alert-info');
        return "<div class='alert {$typeClass}'>" . htmlspecialchars($flash['message']) . "</div>";
    }
    return '';
}

/**
 * Dispatch a notification to a specific user or target role
 */
function create_notification(PDO $pdo, string $title, string $message, string $type = 'info', ?string $link = null, ?int $user_id = null, ?string $target_role = null): bool {
    try {
        $stmt = $pdo->prepare("INSERT INTO notifications (user_id, role, title, message, type, link) VALUES (?, ?, ?, ?, ?, ?)");
        return $stmt->execute([$user_id, $target_role ? strtolower($target_role) : null, $title, $message, $type, $link]);
    } catch (PDOException $e) {
        return false;
    }
}

/**
 * Retrieve notifications for the current logged-in user or their role
 */
function get_user_notifications(PDO $pdo, int $user_id, string $user_role, int $limit = 10): array {
    try {
        $stmt = $pdo->prepare("
            SELECT * FROM notifications 
            WHERE user_id = ? OR role = ? OR role = 'all'
            ORDER BY created_at DESC 
            LIMIT ?
        ");
        $stmt->bindValue(1, $user_id, PDO::PARAM_INT);
        $stmt->bindValue(2, strtolower($user_role), PDO::PARAM_STR);
        $stmt->bindValue(3, $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        return [];
    }
}