</div> <!-- Closes .page-content from header.php -->

    <footer class="site-footer">
        <div class="footer-content">
            <div>
                &copy; <?= date('Y'); ?> Tunku Abdul Rahman University Management and Technology <strong>(TAR UMT)</strong> &bull; 
            </div>
            <div>
                Need help? <a href="mailto:support@tarumt.edu.my"><i class="fa-solid fa-envelope"></i> Contact IT Support</a>
            </div>
        </div>
    </footer>
</body>
</html>