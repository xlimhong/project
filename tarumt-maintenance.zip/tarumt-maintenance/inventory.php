<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/db.php';
require_once 'includes/helpers.php';

require_auth();

$user_role = strtolower($_SESSION['role'] ?? 'student');

// Restrict access: Only Admin, Staff, and Technician can manage inventory
if (!in_array($user_role, ['admin', 'staff', 'technician'])) {
    set_flash('error', "Access denied. Inventory management is restricted to Staff, Technician, or Admin.");
    header("Location: dashboard.php");
    exit();
}

// Auto-create inventory table and automatically patch missing columns if table already existed
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS inventory (
        id INT AUTO_INCREMENT PRIMARY KEY,
        item_name VARCHAR(255) NOT NULL,
        category VARCHAR(100) NOT NULL DEFAULT 'General',
        quantity INT NOT NULL DEFAULT 0,
        min_stock INT NOT NULL DEFAULT 5,
        unit VARCHAR(50) DEFAULT 'pcs',
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )");

    // Safety checks: Add missing columns if table was created in an older schema version
    $columns = $pdo->query("SHOW COLUMNS FROM inventory")->fetchAll(PDO::FETCH_COLUMN);
    
    if (!in_array('category', $columns)) {
        $pdo->exec("ALTER TABLE inventory ADD COLUMN category VARCHAR(100) NOT NULL DEFAULT 'General' AFTER item_name");
    }
    if (!in_array('min_stock', $columns)) {
        $pdo->exec("ALTER TABLE inventory ADD COLUMN min_stock INT NOT NULL DEFAULT 5 AFTER quantity");
    }
    if (!in_array('unit', $columns)) {
        $pdo->exec("ALTER TABLE inventory ADD COLUMN unit VARCHAR(50) DEFAULT 'pcs' AFTER min_stock");
    }
} catch (PDOException $e) {
    die("Database table initialization error: " . $e->getMessage());
}

// Handle Add Item
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_item') {
    verify_csrf();

    $name      = trim($_POST['item_name'] ?? '');
    $category  = trim($_POST['category'] ?? 'General');
    $quantity  = (int)($_POST['quantity'] ?? 0);
    $min_stock = (int)($_POST['min_stock'] ?? 5);
    $unit      = trim($_POST['unit'] ?? 'pcs');

    if (!empty($name)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO inventory (item_name, category, quantity, min_stock, unit) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$name, $category, $quantity, $min_stock, $unit]);
            set_flash('success', "Item '{$name}' added to inventory.");
        } catch (PDOException $e) {
            set_flash('error', "Failed to add item: " . $e->getMessage());
        }
    } else {
        set_flash('error', "Item name is required.");
    }
    header("Location: inventory.php");
    exit();
}

// Handle Update Stock
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_stock') {
    verify_csrf();

    $item_id = (int)($_POST['item_id'] ?? 0);
    $new_qty = (int)($_POST['quantity'] ?? 0);

    try {
        $stmt = $pdo->prepare("UPDATE inventory SET quantity = ? WHERE id = ?");
        $stmt->execute([$new_qty, $item_id]);
        set_flash('success', "Inventory quantity updated.");
    } catch (PDOException $e) {
        set_flash('error', "Failed to update stock: " . $e->getMessage());
    }
    header("Location: inventory.php");
    exit();
}

// Fetch Inventory Items
$search = trim($_GET['search'] ?? '');
$sql = "SELECT * FROM inventory WHERE 1=1";
$params = [];

if (!empty($search)) {
    $sql .= " AND (item_name LIKE ? OR category LIKE ?)";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
}

$sql .= " ORDER BY id DESC";

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $inventory_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $inventory_items = [];
}
?>

<?php include 'includes/header.php'; ?>

<div class="page-content">
    <?= display_flash(); ?>

    <!-- Add Item Form Section -->
    <div class="card" style="margin-bottom: 2rem;">
        <div class="card-header">
            <h2><i class="fa-solid fa-plus-circle"></i> Add New Inventory Item</h2>
        </div>
        <form action="inventory.php" method="POST" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 1rem; align-items: end;">
            <input type="hidden" name="csrf_token" value="<?= csrf_token(); ?>">
            <input type="hidden" name="action" value="add_item">

            <div class="form-group" style="margin-bottom: 0;">
                <label for="item_name">Item Name *</label>
                <input type="text" id="item_name" name="item_name" placeholder="e.g. LED Tube Light 18W" required>
            </div>

            <div class="form-group" style="margin-bottom: 0;">
                <label for="category">Category</label>
                <select id="category" name="category">
                    <option value="Electrical">Electrical</option>
                    <option value="Plumbing">Plumbing</option>
                    <option value="Air-Conditioning">Air-Conditioning</option>
                    <option value="Furniture">Furniture</option>
                    <option value="Cleaning">Cleaning</option>
                    <option value="General">General</option>
                </select>
            </div>

            <div class="form-group" style="margin-bottom: 0;">
                <label for="quantity">Initial Quantity</label>
                <input type="number" id="quantity" name="quantity" min="0" value="10" required>
            </div>

            <div class="form-group" style="margin-bottom: 0;">
                <label for="min_stock">Min. Alert Stock</label>
                <input type="number" id="min_stock" name="min_stock" min="1" value="5" required>
            </div>

            <div class="form-group" style="margin-bottom: 0;">
                <label for="unit">Unit Type</label>
                <input type="text" id="unit" name="unit" placeholder="pcs, rolls, boxes" value="pcs">
            </div>

            <button type="submit" class="btn" style="height: 42px;"><i class="fa-solid fa-floppy-disk"></i> Save Item</button>
        </form>
    </div>

    <!-- Inventory Stock Table -->
    <div class="card">
        <div class="card-header" style="flex-wrap: wrap; gap: 1rem;">
            <h2><i class="fa-solid fa-warehouse"></i> Inventory Stock Control</h2>
            <form action="inventory.php" method="GET" style="display: flex; gap: 0.5rem;">
                <input type="text" name="search" value="<?= htmlspecialchars($search); ?>" placeholder="Search inventory..." style="height: 38px; font-size: 0.85rem;">
                <button type="submit" class="btn btn-secondary" style="height: 38px; padding: 0 12px;"><i class="fa-solid fa-magnifying-glass"></i></button>
            </form>
        </div>

        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Item Name</th>
                        <th>Category</th>
                        <th>Current Stock</th>
                        <th>Status</th>
                        <th>Last Updated</th>
                        <th>Quick Update Stock</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($inventory_items)): ?>
                        <?php foreach ($inventory_items as $item): ?>
                            <tr>
                                <td>#<?= str_pad($item['id'], 3, '0', STR_PAD_LEFT); ?></td>
                                <td><strong><?= htmlspecialchars($item['item_name']); ?></strong></td>
                                <td><?= htmlspecialchars($item['category'] ?? 'General'); ?></td>
                                <td><strong><?= (int)$item['quantity']; ?></strong> <?= htmlspecialchars($item['unit'] ?? 'pcs'); ?></td>
                                <td>
                                    <?php if ($item['quantity'] <= 0): ?>
                                        <span class="badge badge-cancelled"><i class="fa-solid fa-triangle-exclamation"></i> Out of Stock</span>
                                    <?php elseif ($item['quantity'] <= ($item['min_stock'] ?? 5)): ?>
                                        <span class="badge badge-pending"><i class="fa-solid fa-circle-exclamation"></i> Low Stock</span>
                                    <?php else: ?>
                                        <span class="badge badge-completed"><i class="fa-solid fa-check"></i> In Stock</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= date('d M Y, h:i A', strtotime($item['updated_at'])); ?></td>
                                <td>
                                    <form action="inventory.php" method="POST" style="display: flex; gap: 0.4rem; align-items: center;">
                                        <input type="hidden" name="csrf_token" value="<?= csrf_token(); ?>">
                                        <input type="hidden" name="action" value="update_stock">
                                        <input type="hidden" name="item_id" value="<?= $item['id']; ?>">
                                        <input type="number" name="quantity" value="<?= (int)$item['quantity']; ?>" min="0" style="width: 80px; height: 32px; padding: 2px 6px; font-size: 0.85rem;" required>
                                        <button type="submit" class="btn" style="padding: 4px 10px; font-size: 0.78rem;">Set</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" style="text-align: center; color: var(--text-muted); padding: 2rem;">No inventory items found. Add your first item using the form above.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>