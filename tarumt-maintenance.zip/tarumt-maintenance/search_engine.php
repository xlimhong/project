<?php
// search_engine.php - Handles standalone or AJAX search queries
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$host = 'localhost';
$db   = 'maintenance_db';
$user = 'root';
$pass = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException $e) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Database connection failed']);
    exit();
}

$search = trim($_GET['search'] ?? '');

if (!empty($search)) {
    $stmt = $pdo->prepare("SELECT * FROM maintenance_requests 
                            WHERE ticket_id LIKE :q 
                               OR category LIKE :q 
                               OR description LIKE :q 
                               OR location LIKE :q 
                               OR item_name LIKE :q 
                            ORDER BY id DESC");
    $stmt->execute(['q' => "%{$search}%"]);
    $results = $stmt->fetchAll();
} else {
    $stmt = $pdo->query("SELECT * FROM maintenance_requests ORDER BY id DESC LIMIT 10");
    $results = $stmt->fetchAll();
}

// Returns clean JSON output for JavaScript AJAX
header('Content-Type: application/json');
echo json_encode($results);
exit();