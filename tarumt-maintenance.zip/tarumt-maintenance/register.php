<?php
session_start();
require_once 'config/db.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tarumt_id = trim($_POST['tarumt_id']);
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $role = $_POST['role'] ?? 'requester';

    if (!empty($tarumt_id) && !empty($name) && !empty($email) && !empty($password)) {
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);
        try {
            $stmt = $pdo->prepare("INSERT INTO users (tarumt_id, name, email, password, role) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$tarumt_id, $name, $email, $hashed_password, $role]);
            $success = "Registration successful. You can now <a href='index.php'>login</a>.";
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                $error = "TAR UMT ID or Email is already registered.";
            } else {
                $error = "Registration error: " . $e->getMessage();
            }
        }
    } else {
        $error = "All fields are required.";
    }
}
?>

<?php include 'includes/header.php'; ?>

<div class="container">
    <h2>Register Account</h2>
    <?php if ($error): ?><p class="alert error"><?= $error; ?></p><?php endif; ?>
    <?php if ($success): ?><p class="alert success"><?= $success; ?></p><?php endif; ?>

    <form action="register.php" method="POST">
        <div class="form-group">
            <label>TAR UMT ID</label>
            <input type="text" name="tarumt_id" placeholder="e.g. 22AAB12345 or S10492" required>
        </div>
        <div class="form-group">
            <label>Full Name</label>
            <input type="text" name="name" required>
        </div>
        <div class="form-group">
            <label>Email Address</label>
            <input type="email" name="email" placeholder="name@tarc.edu.my" required>
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" required>
        </div>
        <div class="form-group">
            <label>Role</label>
            <select name="role">
                <option value="requester">Student / Staff (Requester)</option>
                <option value="technician">Technician / Maintenance Staff</option>
            </select>
        </div>
        <button type="submit" class="btn">Register</button>
        <p class="form-footer">Already registered? <a href="index.php">Login here</a></p>
    </form>
</div>

<?php include 'includes/footer.php'; ?>