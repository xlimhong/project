<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/db.php';
require_once 'includes/helpers.php';

require_auth();

$user_role   = strtolower($_SESSION['role'] ?? 'student');
$can_manage  = in_array($user_role, ['admin', 'staff', 'technician']);

// Ensure the schedules table exists
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS preventive_schedules (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        location VARCHAR(255) NOT NULL,
        frequency_days INT NOT NULL DEFAULT 30,
        last_performed DATE NULL,
        created_by INT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
} catch (PDOException $e) {
    die("Database initialization failed: " . $e->getMessage());
}

// Handle new routine submission (Admin / Staff / Technician only)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create_schedule') {
    verify_csrf();

    if (!$can_manage) {
        set_flash('error', "You don't have permission to schedule maintenance routines.");
        header("Location: preventive_maintenance.php");
        exit();
    }

    $title          = trim($_POST['title'] ?? '');
    $location       = trim($_POST['location'] ?? '');
    $frequency_days = (int)($_POST['frequency_days'] ?? 0);
    $last_performed = trim($_POST['last_performed'] ?? '');
    $created_by     = $_SESSION['user_id'] ?? null;

    // Validate last_performed as a real date, default to today if blank
    if (empty($last_performed) || !strtotime($last_performed)) {
        $last_performed = date('Y-m-d');
    } else {
        $last_performed = date('Y-m-d', strtotime($last_performed));
    }

    if (!empty($title) && !empty($location) && $frequency_days > 0) {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO preventive_schedules (title, location, frequency_days, last_performed, created_by)
                VALUES (?, ?, ?, ?, ?)
            ");
            $stmt->execute([$title, $location, $frequency_days, $last_performed, $created_by]);
            set_flash('success', "Routine \"{$title}\" was scheduled successfully.");
        } catch (PDOException $e) {
            set_flash('error', "Failed to schedule routine: " . $e->getMessage());
        }
    } else {
        set_flash('error', "Please fill in the task, location, and a valid frequency.");
    }

    header("Location: preventive_maintenance.php");
    exit();
}

// Handle delete (Admin / Staff / Technician only)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_schedule') {
    verify_csrf();

    if ($can_manage) {
        $sched_id = (int)($_POST['schedule_id'] ?? 0);
        try {
            $stmt = $pdo->prepare("DELETE FROM preventive_schedules WHERE id = ?");
            $stmt->execute([$sched_id]);
            set_flash('success', "Routine removed.");
        } catch (PDOException $e) {
            set_flash('error', "Failed to remove routine.");
        }
    } else {
        set_flash('error', "You don't have permission to remove routines.");
    }

    header("Location: preventive_maintenance.php");
    exit();
}

// Handle "Mark as serviced" (resets last_performed to today, Admin / Staff / Technician only)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'mark_serviced') {
    verify_csrf();

    if ($can_manage) {
        $sched_id = (int)($_POST['schedule_id'] ?? 0);
        try {
            $stmt = $pdo->prepare("UPDATE preventive_schedules SET last_performed = ? WHERE id = ?");
            $stmt->execute([date('Y-m-d'), $sched_id]);
            set_flash('success', "Routine marked as serviced today.");
        } catch (PDOException $e) {
            set_flash('error', "Failed to update routine.");
        }
    } else {
        set_flash('error', "You don't have permission to update routines.");
    }

    header("Location: preventive_maintenance.php");
    exit();
}

// Fetch schedules and compute due dates / status in PHP
try {
    $stmt = $pdo->query("SELECT * FROM preventive_schedules ORDER BY last_performed ASC");
    $raw_schedules = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $raw_schedules = [];
}

$today = new DateTime('today');
$schedules = [];
$status_counts = ['Overdue' => 0, 'Due Soon' => 0, 'Pending' => 0];

foreach ($raw_schedules as $row) {
    $last = new DateTime($row['last_performed']);
    $next = (clone $last)->modify('+' . (int)$row['frequency_days'] . ' days');

    $days_until = (int)$today->diff($next)->format('%r%a'); // signed day diff

    if ($days_until < 0) {
        $status = 'Overdue';
    } elseif ($days_until <= 30) {
        $status = 'Due Soon';
    } else {
        $status = 'Pending';
    }
    $status_counts[$status]++;

    $freq = (int)$row['frequency_days'];
    if ($freq % 30 === 0 && $freq <= 360) {
        $freq_label = 'Every ' . ($freq / 30 == 1 ? 'month' : ($freq / 30) . ' months');
    } elseif ($freq === 365) {
        $freq_label = 'Every year';
    } else {
        $freq_label = 'Every ' . $freq . ' days';
    }

    $schedules[] = [
        'id'             => $row['id'],
        'title'          => $row['title'],
        'location'       => $row['location'],
        'frequency'      => $freq_label,
        'last_performed' => $last->format('d M Y'),
        'next_due'       => $next->format('d M Y'),
        'days_until'     => $days_until,
        'status'         => $status,
    ];
}

$status_map = [
    'Overdue'  => ['label' => 'Overdue',   'bg' => '#FBEAE8', 'fg' => '#A6362A', 'dot' => '#C43E30'],
    'Due Soon' => ['label' => 'Due soon',  'bg' => '#FBF1E1', 'fg' => '#93611B', 'dot' => '#C8862A'],
    'Pending'  => ['label' => 'Scheduled', 'bg' => '#E7EEF4', 'fg' => '#2C4A63', 'dot' => '#3E6488'],
];

$frequency_options = [
    7   => 'Weekly (7 days)',
    14  => 'Every 2 weeks',
    30  => 'Monthly (30 days)',
    60  => 'Every 2 months',
    90  => 'Quarterly (90 days)',
    180 => 'Every 6 months',
    365 => 'Yearly (365 days)',
];
?>

<?php include 'includes/header.php'; ?>

<style>
    .pm-wrap {
        padding: 24px;
        max-width: 1200px;
        margin: 0 auto;
    }

    .pm-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        gap: 1.5rem;
        flex-wrap: wrap;
        margin-bottom: 1.75rem;
    }

    .pm-header h2 {
        margin: 0;
        color: #14202B;
        font-size: 1.4rem;
    }

    .pm-header p {
        color: #64748b;
        margin: 0.35rem 0 0 0;
        font-size: 0.9rem;
        max-width: 46ch;
    }

    .pm-flash {
        margin-bottom: 1.25rem;
    }

    .pm-btn-new {
        background: #14202B;
        color: #fff;
        border: none;
        padding: 0.65rem 1.25rem;
        border-radius: 8px;
        font-weight: 600;
        font-size: 0.88rem;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        transition: background 0.15s ease;
        white-space: nowrap;
    }

    .pm-btn-new:hover {
        background: #0B141C;
    }

    /* Summary strip */
    .pm-stats {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 0.9rem;
        margin-bottom: 1.5rem;
    }

    .pm-stat {
        background: #fff;
        border: 1px solid #E7EAEE;
        border-radius: 10px;
        padding: 1rem 1.1rem;
        display: flex;
        align-items: center;
        gap: 0.85rem;
    }

    .pm-stat-count {
        font-size: 1.6rem;
        font-weight: 700;
        color: #14202B;
        line-height: 1;
    }

    .pm-stat-label {
        font-size: 0.8rem;
        color: #64748b;
        margin-top: 0.25rem;
    }

    .pm-stat-dot {
        width: 10px;
        height: 10px;
        border-radius: 50%;
        flex-shrink: 0;
    }

    /* Table card */
    .pm-card {
        background: #fff;
        border-radius: 12px;
        border: 1px solid #e2e8f0;
        overflow: hidden;
    }

    .pm-table {
        width: 100%;
        border-collapse: collapse;
        text-align: left;
        font-size: 0.88rem;
    }

    .pm-table thead tr {
        background: #F8FAFC;
        border-bottom: 1px solid #e2e8f0;
    }

    .pm-table th {
        padding: 13px 16px;
        color: #64748b;
        font-weight: 600;
        font-size: 0.78rem;
        letter-spacing: 0.01em;
    }

    .pm-table td {
        padding: 14px 16px;
        border-bottom: 1px solid #f1f5f9;
        vertical-align: middle;
    }

    .pm-table tbody tr:last-child td {
        border-bottom: none;
    }

    .pm-table tbody tr {
        transition: background-color 0.12s ease;
    }

    .pm-table tbody tr:hover {
        background-color: #FAFBFC;
    }

    .pm-task {
        font-weight: 700;
        color: #14202B;
    }

    .pm-task-freq {
        display: block;
        font-weight: 400;
        color: #94A3B8;
        font-size: 0.78rem;
        margin-top: 0.15rem;
    }

    .pm-location,
    .pm-serviced {
        color: #475569;
    }

    .pm-due {
        font-weight: 600;
        color: #14202B;
    }

    .pm-due-sub {
        display: block;
        font-weight: 400;
        font-size: 0.76rem;
        margin-top: 0.1rem;
    }

    .pm-status-pill {
        display: inline-flex;
        align-items: center;
        gap: 0.4rem;
        padding: 0.3rem 0.7rem;
        border-radius: 20px;
        font-weight: 600;
        font-size: 0.72rem;
    }

    .pm-status-pill .dot {
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: currentColor;
    }

    .pm-row-actions {
        display: flex;
        gap: 0.4rem;
        align-items: center;
    }

    .pm-icon-btn {
        width: 32px;
        height: 32px;
        border-radius: 6px;
        border: 1px solid #D8DEE5;
        background: #fff;
        color: #5B6472;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.15s ease;
        flex-shrink: 0;
    }

    .pm-icon-btn:hover {
        border-color: #14202B;
        color: #14202B;
    }

    .pm-icon-btn.danger:hover {
        border-color: #B4432F;
        color: #B4432F;
        background: #FBEEEC;
    }

    .pm-empty {
        text-align: center;
        color: #94A3B8;
        padding: 3rem 1rem;
    }

    /* Modal */
    .pm-modal-overlay {
        display: none;
        position: fixed;
        inset: 0;
        background: rgba(15, 23, 33, 0.55);
        z-index: 9999;
        align-items: center;
        justify-content: center;
        padding: 1.5rem;
    }

    .pm-modal-overlay.is-open {
        display: flex;
    }

    .pm-modal {
        background: #fff;
        border-radius: 12px;
        width: 100%;
        max-width: 460px;
        overflow: hidden;
        box-shadow: 0 20px 50px rgba(15, 23, 33, 0.25);
    }

    .pm-modal-header {
        padding: 1.25rem 1.5rem;
        border-bottom: 1px solid #EEF1F4;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .pm-modal-header h3 {
        margin: 0;
        font-size: 1.05rem;
        color: #14202B;
    }

    .pm-modal-close {
        background: none;
        border: none;
        font-size: 1.3rem;
        color: #94A3B8;
        cursor: pointer;
        line-height: 1;
    }

    .pm-modal-close:hover {
        color: #14202B;
    }

    .pm-modal-body {
        padding: 1.5rem;
    }

    .pm-field {
        margin-bottom: 1rem;
    }

    .pm-field:last-child {
        margin-bottom: 0;
    }

    .pm-field label {
        display: block;
        font-size: 0.82rem;
        font-weight: 600;
        color: #465063;
        margin-bottom: 0.4rem;
    }

    .pm-field input,
    .pm-field select {
        width: 100%;
        border: 1px solid #D3D8DE;
        border-radius: 7px;
        padding: 0.6rem 0.75rem;
        font-size: 0.9rem;
        color: #1E2A35;
        background: #FBFBFA;
    }

    .pm-field input:focus,
    .pm-field select:focus {
        outline: none;
        border-color: #14202B;
        box-shadow: 0 0 0 3px rgba(20, 32, 43, 0.1);
        background: #fff;
    }

    .pm-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 1rem;
    }

    .pm-modal-footer {
        padding: 1.1rem 1.5rem;
        border-top: 1px solid #EEF1F4;
        display: flex;
        justify-content: flex-end;
        gap: 0.75rem;
    }

    .pm-btn-cancel {
        background: transparent;
        border: 1px solid #D3D8DE;
        color: #5B6472;
        padding: 0.6rem 1.1rem;
        border-radius: 7px;
        font-weight: 600;
        font-size: 0.88rem;
        cursor: pointer;
    }

    .pm-btn-cancel:hover {
        border-color: #AEB8C2;
        color: #14202B;
    }

    @media (max-width: 720px) {
        .pm-stats { grid-template-columns: 1fr; }
        .pm-table { font-size: 0.82rem; }
        .pm-table th, .pm-table td { padding: 10px; }
        .pm-row { grid-template-columns: 1fr; }
    }
</style>

<div class="pm-wrap">
    <div class="pm-header">
        <div>
            <h2><i class="fa-solid fa-calendar-check"></i> Preventive Scheduled Maintenance</h2>
            <p>Automatic reminders for equipment servicing before breakdowns happen.</p>
        </div>
        <?php if ($can_manage): ?>
            <button type="button" class="pm-btn-new" onclick="pmOpenModal()"><i class="fa-solid fa-plus"></i> Schedule new routine</button>
        <?php endif; ?>
    </div>

    <div class="pm-flash"><?= display_flash(); ?></div>

    <!-- Summary Strip -->
    <div class="pm-stats">
        <div class="pm-stat">
            <span class="pm-stat-dot" style="background: <?= $status_map['Overdue']['dot']; ?>;"></span>
            <div>
                <div class="pm-stat-count"><?= $status_counts['Overdue']; ?></div>
                <div class="pm-stat-label">Overdue tasks</div>
            </div>
        </div>
        <div class="pm-stat">
            <span class="pm-stat-dot" style="background: <?= $status_map['Due Soon']['dot']; ?>;"></span>
            <div>
                <div class="pm-stat-count"><?= $status_counts['Due Soon']; ?></div>
                <div class="pm-stat-label">Due within 30 days</div>
            </div>
        </div>
        <div class="pm-stat">
            <span class="pm-stat-dot" style="background: <?= $status_map['Pending']['dot']; ?>;"></span>
            <div>
                <div class="pm-stat-count"><?= $status_counts['Pending']; ?></div>
                <div class="pm-stat-label">Scheduled routines</div>
            </div>
        </div>
    </div>

    <!-- Schedule Table -->
    <div class="pm-card">
        <table class="pm-table">
            <thead>
                <tr>
                    <th>Maintenance task</th>
                    <th>Location</th>
                    <th>Last serviced</th>
                    <th>Next due</th>
                    <th>Status</th>
                    <?php if ($can_manage): ?><th>Actions</th><?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($schedules)): ?>
                    <?php foreach ($schedules as $item):
                        $s = $status_map[$item['status']] ?? $status_map['Pending'];

                        if ($item['days_until'] < 0) {
                            $due_sub = abs($item['days_until']) . ' day' . (abs($item['days_until']) == 1 ? '' : 's') . ' overdue';
                        } elseif ($item['days_until'] === 0) {
                            $due_sub = 'Due today';
                        } else {
                            $due_sub = 'In ' . $item['days_until'] . ' day' . ($item['days_until'] == 1 ? '' : 's');
                        }
                    ?>
                    <tr>
                        <td>
                            <span class="pm-task">
                                <?= htmlspecialchars($item['title']); ?>
                                <span class="pm-task-freq"><?= htmlspecialchars($item['frequency']); ?></span>
                            </span>
                        </td>
                        <td class="pm-location"><?= htmlspecialchars($item['location']); ?></td>
                        <td class="pm-serviced"><?= htmlspecialchars($item['last_performed']); ?></td>
                        <td class="pm-due">
                            <?= htmlspecialchars($item['next_due']); ?>
                            <span class="pm-due-sub" style="color: <?= $s['fg']; ?>;"><?= htmlspecialchars($due_sub); ?></span>
                        </td>
                        <td>
                            <span class="pm-status-pill" style="background: <?= $s['bg']; ?>; color: <?= $s['fg']; ?>;">
                                <span class="dot"></span><?= htmlspecialchars($s['label']); ?>
                            </span>
                        </td>
                        <?php if ($can_manage): ?>
                        <td>
                            <div class="pm-row-actions">
                                <form action="preventive_maintenance.php" method="POST" onsubmit="return confirm('Mark this routine as serviced today?');">
                                    <input type="hidden" name="csrf_token" value="<?= csrf_token(); ?>">
                                    <input type="hidden" name="action" value="mark_serviced">
                                    <input type="hidden" name="schedule_id" value="<?= $item['id']; ?>">
                                    <button type="submit" class="pm-icon-btn" title="Mark as serviced today">
                                        <i class="fa-solid fa-check"></i>
                                    </button>
                                </form>
                                <form action="preventive_maintenance.php" method="POST" onsubmit="return confirm('Remove this maintenance routine?');">
                                    <input type="hidden" name="csrf_token" value="<?= csrf_token(); ?>">
                                    <input type="hidden" name="action" value="delete_schedule">
                                    <input type="hidden" name="schedule_id" value="<?= $item['id']; ?>">
                                    <button type="submit" class="pm-icon-btn danger" title="Remove routine">
                                        <i class="fa-solid fa-trash-can"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="<?= $can_manage ? '6' : '5'; ?>" class="pm-empty">
                            No preventive routines scheduled yet.
                            <?php if ($can_manage): ?>Click "Schedule new routine" to add the first one.<?php endif; ?>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php if ($can_manage): ?>
<!-- New Routine Modal -->
<div class="pm-modal-overlay" id="pmModalOverlay">
    <div class="pm-modal">
        <form action="preventive_maintenance.php" method="POST">
            <input type="hidden" name="csrf_token" value="<?= csrf_token(); ?>">
            <input type="hidden" name="action" value="create_schedule">

            <div class="pm-modal-header">
                <h3>Schedule new routine</h3>
                <button type="button" class="pm-modal-close" onclick="pmCloseModal()">&times;</button>
            </div>

            <div class="pm-modal-body">
                <div class="pm-field">
                    <label for="pm-title">Maintenance task</label>
                    <input type="text" id="pm-title" name="title" placeholder="e.g. Fire Extinguisher & Alarm Check" required>
                </div>

                <div class="pm-field">
                    <label for="pm-location">Location</label>
                    <input type="text" id="pm-location" name="location" placeholder="e.g. Block DK Hall & Corridors" required>
                </div>

                <div class="pm-row">
                    <div class="pm-field">
                        <label for="pm-frequency">Frequency</label>
                        <select id="pm-frequency" name="frequency_days" required>
                            <?php foreach ($frequency_options as $days => $label): ?>
                                <option value="<?= $days; ?>" <?= $days === 90 ? 'selected' : ''; ?>><?= htmlspecialchars($label); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="pm-field">
                        <label for="pm-last-performed">Last serviced</label>
                        <input type="date" id="pm-last-performed" name="last_performed" value="<?= date('Y-m-d'); ?>" max="<?= date('Y-m-d'); ?>">
                    </div>
                </div>
            </div>

            <div class="pm-modal-footer">
                <button type="button" class="pm-btn-cancel" onclick="pmCloseModal()">Cancel</button>
                <button type="submit" class="pm-btn-new"><i class="fa-solid fa-calendar-plus"></i> Save routine</button>
            </div>
        </form>
    </div>
</div>

<script>
    function pmOpenModal() {
        document.getElementById('pmModalOverlay').classList.add('is-open');
    }
    function pmCloseModal() {
        document.getElementById('pmModalOverlay').classList.remove('is-open');
    }
    document.getElementById('pmModalOverlay').addEventListener('click', function (e) {
        if (e.target === this) pmCloseModal();
    });
    <?php if (!empty($_GET['open_modal'])): ?>
    pmOpenModal();
    <?php endif; ?>
</script>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>