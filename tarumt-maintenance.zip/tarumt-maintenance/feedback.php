<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/db.php';
require_once 'includes/helpers.php';

require_auth();

$user_id   = $_SESSION['user_id'] ?? 0;
$user_role = strtolower($_SESSION['role'] ?? 'student');
$is_admin  = ($user_role === 'admin');

// Auto-create database tables
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS feedback (
        id INT AUTO_INCREMENT PRIMARY KEY,
        request_id INT NULL,
        user_id INT NOT NULL,
        rating INT NOT NULL,
        comments TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
    $pdo->exec("ALTER TABLE feedback MODIFY request_id INT NULL");

    $pdo->exec("CREATE TABLE IF NOT EXISTS feedback_replies (
        id INT AUTO_INCREMENT PRIMARY KEY,
        feedback_id INT NOT NULL,
        user_id INT NOT NULL,
        reply_text TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (feedback_id) REFERENCES feedback(id) ON DELETE CASCADE
    )");
} catch (PDOException $e) {}

// Form Handler (Create, Reply, Delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';

    // 1. Submit New Feedback
    if ($action === 'create_feedback') {
        $request_id = !empty($_POST['request_id']) ? (int)$_POST['request_id'] : null;
        $rating     = (int)($_POST['rating'] ?? 5);
        $comments   = trim($_POST['comments'] ?? '');

        if (!empty($comments)) {
            try {
                $stmt = $pdo->prepare("INSERT INTO feedback (request_id, user_id, rating, comments) VALUES (?, ?, ?, ?)");
                $stmt->execute([$request_id, $user_id, $rating, $comments]);
                set_flash('success', 'Your feedback has been logged.');
            } catch (PDOException $e) {
                set_flash('error', 'Failed to submit feedback.');
            }
        } else {
            set_flash('error', 'Observations field cannot be empty.');
        }
    }

    // 2. Submit Reply
    elseif ($action === 'reply_feedback') {
        $feedback_id = (int)($_POST['feedback_id'] ?? 0);
        $reply_text  = trim($_POST['reply_text'] ?? '');

        if ($feedback_id > 0 && !empty($reply_text)) {
            try {
                $stmt = $pdo->prepare("INSERT INTO feedback_replies (feedback_id, user_id, reply_text) VALUES (?, ?, ?)");
                $stmt->execute([$feedback_id, $user_id, $reply_text]);
                set_flash('success', 'Reply posted successfully.');
            } catch (PDOException $e) {
                set_flash('error', 'Failed to post reply.');
            }
        }
    }

    // 3. Delete Feedback (Author or Admin)
    elseif ($action === 'delete_feedback') {
        $feedback_id = (int)($_POST['feedback_id'] ?? 0);
        
        try {
            // Verify ownership
            $stmt = $pdo->prepare("SELECT user_id FROM feedback WHERE id = ?");
            $stmt->execute([$feedback_id]);
            $owner_id = $stmt->fetchColumn();

            if ($owner_id == $user_id || $is_admin) {
                $del = $pdo->prepare("DELETE FROM feedback WHERE id = ?");
                $del->execute([$feedback_id]);
                set_flash('success', 'Feedback entry deleted.');
            } else {
                set_flash('error', 'You are not authorized to delete this feedback.');
            }
        } catch (PDOException $e) {
            set_flash('error', 'Deletion failed.');
        }
    }

    // 4. Delete Reply (Author or Admin)
    elseif ($action === 'delete_reply') {
        $reply_id = (int)($_POST['reply_id'] ?? 0);

        try {
            $stmt = $pdo->prepare("SELECT user_id FROM feedback_replies WHERE id = ?");
            $stmt->execute([$reply_id]);
            $owner_id = $stmt->fetchColumn();

            if ($owner_id == $user_id || $is_admin) {
                $del = $pdo->prepare("DELETE FROM feedback_replies WHERE id = ?");
                $del->execute([$reply_id]);
                set_flash('success', 'Reply deleted.');
            } else {
                set_flash('error', 'Unauthorized operation.');
            }
        } catch (PDOException $e) {
            set_flash('error', 'Deletion failed.');
        }
    }

    header("Location: feedback.php");
    exit();
}

// Fetch Tickets for Dropdown
try {
    $stmt = $pdo->prepare("SELECT id, description, status FROM maintenance_requests WHERE user_id = ? ORDER BY id DESC");
    $stmt->execute([$user_id]);
    $user_tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $user_tickets = [];
}

// Fetch All Feedback Items with Author Names
try {
    $feed_stmt = $pdo->query("
        SELECT f.*, COALESCE(u.name, 'Anonymous') as author_name, COALESCE(u.role, 'student') as author_role 
        FROM feedback f 
        LEFT JOIN users u ON f.user_id = u.id 
        ORDER BY f.id DESC
    ");
    $feedback_list = $feed_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $feedback_list = [];
}
?>

<?php include 'includes/header.php'; ?>

<div class="container-centered" style="max-width: 800px;">
    <?= display_flash(); ?>

    <!-- Feedback Form Card -->
    <div class="card">
        <div class="card-header">
            <div>
                <h2><i class="fa-solid fa-comment-dots"></i> Submit Feedback</h2>
                <p style="color: var(--text-muted); font-size: 0.85rem;">Rate completed maintenance services or leave suggestions.</p>
            </div>
        </div>

        <form action="feedback.php" method="POST">
            <input type="hidden" name="csrf_token" value="<?= csrf_token(); ?>">
            <input type="hidden" name="action" value="create_feedback">

            <div class="form-group">
                <label for="request_id">Target Maintenance Ticket (Optional)</label>
                <select id="request_id" name="request_id">
                    <option value="">-- General Campus Feedback (No Ticket) --</option>
                    <?php foreach($user_tickets as $t): ?>
                        <option value="<?= $t['id']; ?>">
                            Ticket #<?= str_pad($t['id'], 4, '0', STR_PAD_LEFT); ?> — <?= htmlspecialchars(substr($t['description'] ?? 'Issue', 0, 30)); ?>... [<?= strtoupper(htmlspecialchars($t['status'])); ?>]
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="rating">Rating</label>
                <select id="rating" name="rating" required>
                    <option value="5">⭐⭐⭐⭐⭐ 5/5 — Outstanding</option>
                    <option value="4">⭐⭐⭐⭐ 4/5 — Satisfactory</option>
                    <option value="3">⭐⭐⭐ 3/5 — Adequate</option>
                    <option value="2">⭐⭐ 2/5 — Requires Improvement</option>
                    <option value="1">⭐ 1/5 — Unsatisfactory</option>
                </select>
            </div>

            <div class="form-group">
                <label for="comments">Observations & Comments</label>
                <textarea id="comments" name="comments" rows="3" placeholder="Write your experience or observations..." required></textarea>
            </div>

            <button type="submit" class="btn" style="width: 100%;"><i class="fa-solid fa-paper-plane"></i> Post Feedback</button>
        </form>
    </div>

    <!-- Public Feedback Feed & Replies -->
    <h2 style="font-family: var(--font-heading); margin-bottom: 1rem;"><i class="fa-solid fa-comments"></i> Community Feedback & Responses</h2>

    <?php if (!empty($feedback_list)): ?>
        <?php foreach ($feedback_list as $fb): ?>
            <div class="card" style="padding: 1.5rem; margin-bottom: 1.25rem;">
                <!-- Feedback Header -->
                <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                    <div>
                        <strong><?= htmlspecialchars($fb['author_name']); ?></strong> 
                        <span class="badge" style="background:#f1f5f9; color:#475569; font-size: 0.7rem; padding: 2px 8px; margin-left: 4px;">
                            <?= strtoupper(htmlspecialchars($fb['author_role'])); ?>
                        </span>
                        <div style="color: var(--text-muted); font-size: 0.8rem; margin-top: 2px;">
                            <?= date('d M Y, h:i A', strtotime($fb['created_at'])); ?>
                            <?php if (!empty($fb['request_id'])): ?>
                                &bull; <span class="ticket-tag">Ticket #<?= str_pad($fb['request_id'], 4, '0', STR_PAD_LEFT); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div style="display: flex; align-items: center; gap: 0.75rem;">
                        <span style="color: #f59e0b; font-weight: bold; font-size: 0.9rem;">
                            <?= str_repeat('⭐', $fb['rating']); ?>
                        </span>

                        <!-- Delete Feedback Button (Only if Author or Admin) -->
                        <?php if ($fb['user_id'] == $user_id || $is_admin): ?>
                            <form action="feedback.php" method="POST" onsubmit="return confirm('Delete this feedback?');" style="margin:0;">
                                <input type="hidden" name="csrf_token" value="<?= csrf_token(); ?>">
                                <input type="hidden" name="action" value="delete_feedback">
                                <input type="hidden" name="feedback_id" value="<?= $fb['id']; ?>">
                                <button type="submit" style="background: none; border: none; color: #dc2626; cursor: pointer; font-size: 0.9rem;" title="Delete Feedback">
                                    <i class="fa-solid fa-trash-can"></i>
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Feedback Text -->
                <p style="margin-top: 0.75rem; color: var(--text-main); font-size: 0.95rem;">
                    <?= nl2br(htmlspecialchars($fb['comments'])); ?>
                </p>

                <!-- Nested Replies Section -->
                <?php
                try {
                    $rep_stmt = $pdo->prepare("
                        SELECT r.*, COALESCE(u.name, 'User') as replier_name, COALESCE(u.role, 'student') as replier_role 
                        FROM feedback_replies r 
                        LEFT JOIN users u ON r.user_id = u.id 
                        WHERE r.feedback_id = ? 
                        ORDER BY r.id ASC
                    ");
                    $rep_stmt->execute([$fb['id']]);
                    $replies = $rep_stmt->fetchAll(PDO::FETCH_ASSOC);
                } catch (PDOException $e) {
                    $replies = [];
                }
                ?>

                <?php if (!empty($replies)): ?>
                    <div style="margin-top: 1rem; padding-left: 1rem; border-left: 3px solid var(--border); display: flex; flex-direction: column; gap: 0.75rem;">
                        <?php foreach ($replies as $rep): ?>
                            <div style="background: #f8fafc; padding: 0.75rem 1rem; border-radius: 8px;">
                                <div style="display: flex; justify-content: space-between; align-items: center;">
                                    <div>
                                        <strong style="font-size: 0.85rem;"><?= htmlspecialchars($rep['replier_name']); ?></strong>
                                        <span class="badge" style="background:#e2e8f0; color:#334155; font-size: 0.65rem; padding: 1px 6px;">
                                            <?= strtoupper(htmlspecialchars($rep['replier_role'])); ?>
                                        </span>
                                        <span style="font-size: 0.75rem; color: var(--text-muted); margin-left: 6px;">
                                            <?= date('d M Y, h:i A', strtotime($rep['created_at'])); ?>
                                        </span>
                                    </div>

                                    <!-- Delete Reply Button (Only if Author or Admin) -->
                                    <?php if ($rep['user_id'] == $user_id || $is_admin): ?>
                                        <form action="feedback.php" method="POST" onsubmit="return confirm('Delete this reply?');" style="margin:0;">
                                            <input type="hidden" name="csrf_token" value="<?= csrf_token(); ?>">
                                            <input type="hidden" name="action" value="delete_reply">
                                            <input type="hidden" name="reply_id" value="<?= $rep['id']; ?>">
                                            <button type="submit" style="background: none; border: none; color: #dc2626; cursor: pointer; font-size: 0.8rem;" title="Delete Reply">
                                                <i class="fa-solid fa-trash"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                                <p style="font-size: 0.875rem; margin-top: 0.25rem; color: #334155;">
                                    <?= nl2br(htmlspecialchars($rep['reply_text'])); ?>
                                </p>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <!-- Inline Reply Form -->
                <form action="feedback.php" method="POST" style="margin-top: 1rem; display: flex; gap: 0.5rem;">
                    <input type="hidden" name="csrf_token" value="<?= csrf_token(); ?>">
                    <input type="hidden" name="action" value="reply_feedback">
                    <input type="hidden" name="feedback_id" value="<?= $fb['id']; ?>">
                    <input type="text" name="reply_text" placeholder="Write a reply..." required style="height: 38px; font-size: 0.85rem; padding-left: 12px; flex: 1; border: 1px solid var(--border); border-radius: 8px;">
                    <button type="submit" class="btn btn-secondary" style="padding: 0 16px; height: 38px; font-size: 0.85rem;"><i class="fa-solid fa-reply"></i> Reply</button>
                </form>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div class="card" style="padding: 2rem; text-align: center; color: var(--text-muted);">
            No feedback entries submitted yet.
        </div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>