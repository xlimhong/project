<?php
require_once 'config/db.php';
require_once 'includes/helpers.php';
require_auth();

$user_id   = $_SESSION['user_id'];
$user_role = strtolower($_SESSION['role'] ?? 'student');

// Mark a notification as read if requested
if (isset($_GET['mark_read'])) {
    $notif_id = (int)$_GET['mark_read'];
    $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND (user_id = ? OR role = ?)");
    $stmt->execute([$notif_id, $user_id, $user_role]);
    header("Location: notifications.php");
    exit();
}

// Fetch user-specific and role-specific notifications
$stmt = $pdo->prepare("
    SELECT * FROM notifications 
    WHERE user_id = ? OR role = ? 
    ORDER BY created_at DESC
");
$stmt->execute([$user_id, $user_role]);
$notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);

include 'includes/header.php';
?>

<div class="page-content">
    <h2><i class="fa-solid fa-bell"></i> Your Notifications</h2>
    <div class="card" style="padding: 1rem; margin-top: 1rem;">
        <?php if (!empty($notifications)): ?>
            <ul style="list-style: none; padding: 0;">
                <?php foreach ($notifications as $n): ?>
                    <li style="padding: 0.75rem; border-bottom: 1px solid #eee; background: <?= $n['is_read'] ? '#fff' : '#f0f7ff'; ?>;">
                        <strong><?= htmlspecialchars($n['title']); ?></strong>
                        <p><?= htmlspecialchars($n['message']); ?></p>
                        <small><?= date('d M Y, h:i A', strtotime($n['created_at'])); ?></small>
                        <a href="<?= htmlspecialchars($n['link']); ?>">View Details</a>
                        <?php if (!$n['is_read']): ?>
                            | <a href="notifications.php?mark_read=<?= $n['id']; ?>">Mark as read</a>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p>No notifications found.</p>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>