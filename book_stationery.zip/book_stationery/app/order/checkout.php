<?php
require '../_base.php';
auth('member');

$cart = get_cart();
if (empty($cart)) {
    temp('info', 'Your cart is empty. Please add items before checking out.');
    redirect('cart.php');
}

$ids = array_keys($cart);
$placeholders = str_repeat('?,', count($ids) - 1) . '?';
$stm = $_db->prepare("SELECT * FROM products WHERE product_id IN ($placeholders)");
$stm->execute($ids);
$products_in_cart = $stm->fetchAll();

$grand_total = 0;
foreach ($products_in_cart as $p) {
    $qty = $cart[$p->product_id];
    $grand_total += ($p->price * $qty);
}


if (is_post()) {
    $shipping_address = post('shipping_address');

    if (empty($shipping_address)) {
        $_err['shipping_address'] = 'Shipping address is required.';
    }

    if (empty($_err)) {
        $_SESSION['shipping_address'] = $shipping_address;
        
        redirect('../stripe_checkout.php');
    }
}

$_title = 'Checkout';
require '../_head.php';
?>

<main>
    <h1><?= $_title ?></h1>
    <?php err('general'); ?>

    <div style="display: flex; gap: 40px; flex-wrap: wrap;">
        <div style="flex: 1; min-width: 300px;">
            <h3>Shipping Information</h3>
            <form action="" method="POST">
                <div style="margin-bottom: 15px;">
                    <label for="shipping_address" style="display: block; margin-bottom: 5px;"><strong>Full Shipping Address:</strong></label>
                    <textarea id="shipping_address" name="shipping_address" rows="5" style="width: 100%; padding: 10px; border-radius: 4px; border: 1px solid #ccc;"></textarea>
                    <?php err('shipping_address'); ?>
                </div>

                <div style="padding: 15px; background: #e9ecef; border-radius: 4px; margin-bottom: 20px;">
                    <p><strong>Payment Method:</strong> Stripe Secure Payment 💳</p>
                    <p style="font-size: 0.9em; color: #666;">You will be redirected to Stripe to securely complete your payment.</p>
                </div>

                <button type="submit" style="width: 100%; padding: 12px; background: #635bff; color: white; border: none; border-radius: 4px; font-size: 1.1em; cursor: pointer; font-weight: bold;">
                    Pay via Stripe
                </button>
            </form>
        </div>

        <div style="flex: 1; min-width: 300px; background: #f8f9fa; padding: 20px; border-radius: 8px; border: 1px solid #ddd;">
            <h3>Order Summary</h3>
            <hr style="margin-bottom: 15px;">
            <table style="width: 100%; border-collapse: collapse;">
                <tbody>
                    <?php foreach ($products_in_cart as $p): ?>
                        <?php 
                            $qty = $cart[$p->product_id];
                            $subtotal = $p->price * $qty;
                        ?>
                        <tr>
                            <td style="padding: 8px 0;"><?= encode($p->product_name) ?> <strong>x <?= $qty ?></strong></td>
                            <td style="padding: 8px 0; text-align: right;">RM <?= number_format($subtotal, 2) ?></td>
                        </tr>
                    <?php endforeach ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td style="padding-top: 15px; font-size: 1.2em;"><strong>Grand Total:</strong></td>
                        <td style="padding-top: 15px; text-align: right; font-size: 1.2em; color: #e44d26;">
                            <strong>RM <?= number_format($grand_total, 2) ?></strong>
                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</main>

<?php require '../_foot.php'; ?>