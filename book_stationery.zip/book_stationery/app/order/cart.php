<?php

require '../_base.php';

auth('member');

// REMOVE ITEM
$remove_id = get('remove');

if ($remove_id) {
    update_cart($remove_id, 0);
    temp('info', 'Item removed from cart.');

    header("Location: cart.php");
    exit;
}

//UPDATE CART 
if (is_post()) {

    $action = post('action');

    if ($action == 'update') {

        $units = post('units');

        if (is_array($units)) {
            foreach ($units as $id => $unit) {
                $unit = max(1, (int)$unit);
                update_cart($id, $unit);
            }
        }

        if (!isset($_SESSION['temp_info'])) {
            temp('info', 'Cart updated successfully!');
        }

        header("Location: cart.php");
        exit;
    }
}


$cart = get_cart();
$products_in_cart = [];
$grand_total = 0;

if ($cart) {
    $ids = array_keys($cart);

    $placeholders = str_repeat('?,', count($ids) - 1) . '?';

    $stm = $_db->prepare("SELECT * FROM products WHERE product_id IN ($placeholders)");
    $stm->execute($ids);

    $products_in_cart = $stm->fetchAll();
}

$_title = 'Shopping Cart';
require '../_head.php';

?>

<main>

    <h1><?= $_title ?></h1>

    <?php $info = temp('info'); if ($info): ?>
        <div style="background: #ffc107; padding: 15px; margin-bottom: 20px; border-radius: 4px; text-align: center; font-weight: bold; color: #333;">
            <?= $info ?>
        </div>
    <?php endif; ?>
    
    <?php if (empty($cart)): ?>
        <div style="text-align: center; padding: 50px; border: 1px dashed #ccc; margin-top: 20px;">
            <h3>Your shopping cart is empty.</h3>
            <a href="../product/list.php" style="display: inline-block; margin-top: 10px; padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 4px;">Continue Shopping</a>
        </div>
    <?php else: ?>

        <form action="" method="POST">
            <input type="hidden" name="action" value="update">

            <table style="width: 100%; border-collapse: collapse; margin-top: 20px;">
                <thead>
                    <tr style="background: #f4f4f4; border-bottom: 2px solid #ddd;">
                        <th style="padding: 10px; text-align: left;">Photo</th>
                        <th style="padding: 10px; text-align: left;">Product Name</th>
                        <th style="padding: 10px; text-align: right;">Unit Price</th>
                        <th style="padding: 10px; text-align: center;">Quantity</th>
                        <th style="padding: 10px; text-align: right;">Subtotal</th>
                        <th style="padding: 10px; text-align: center;">Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php foreach ($products_in_cart as $p): ?>
                        <?php 
                            $qty = $cart[$p->product_id];
                            $subtotal = $p->price * $qty;
                            $grand_total += $subtotal;
                        ?>
                        <tr style="border-bottom: 1px solid #eee;">
                            <td style="padding: 10px;">
                                <img src="../image/product_photos/<?= encode($p->photo) ?>" 
                                     style="width: 50px; height: 50px; object-fit: cover; border-radius: 4px;">
                            </td>

                            <td style="padding: 10px;">
                                <?= encode($p->product_name) ?>
                            </td>

                            <td style="padding: 10px; text-align: right;">
                                RM <?= number_format($p->price, 2) ?>
                            </td>

                            <td style="padding: 10px; text-align: center;">
                                <input type="number" 
                                       name="units[<?= $p->product_id ?>]" 
                                       value="<?= $qty ?>" 
                                       min="1"
                                       onchange="this.form.submit()" 
                                       style="width: 60px; padding: 5px;">
                            </td>

                            <td style="padding: 10px; text-align: right; font-weight: bold;">
                                RM <?= number_format($subtotal, 2) ?>
                            </td>

                            <td style="padding: 10px; text-align: center;">
                                <a href="?remove=<?= $p->product_id ?>" 
                                   onclick="return confirm('Remove this item?')" 
                                   style="padding: 5px 10px; background: #dc3545; color: white; text-decoration: none; border-radius: 4px; font-size: 0.9em;">
                                   Remove
                                </a>
                            </td>
                        </tr>
                    <?php endforeach ?>
                </tbody>

                <tfoot>
                    <tr>
                        <td colspan="4" style="padding: 15px 10px; text-align: right; font-size: 1.2em;">
                            <strong>Grand Total:</strong>
                        </td>
                        <td style="padding: 15px 10px; text-align: right; font-size: 1.2em; color: #e44d26;">
                            <strong>RM <?= number_format($grand_total, 2) ?></strong>
                        </td>
                        <td></td>
                    </tr>
                </tfoot>
            </table>

            <div style="margin-top: 20px; text-align: right;">
                <a href="../product/list.php" 
                   style="display: inline-block; padding: 10px 20px; background: #6c757d; color: white; text-decoration: none; border-radius: 4px; margin-right: 10px;">
                    Continue Shopping
                </a>

                <a href="checkout.php" 
                   style="display: inline-block; padding: 10px 20px; background: #28a745; color: white; text-decoration: none; border-radius: 4px;">
                    Proceed to Checkout
                </a>
            </div>

        </form>

    <?php endif ?>

</main>

<?php require '../_foot.php'; ?>