<?php
require_once '../_base.php';

auth();

$stm = $_db->prepare('
    SELECT * FROM orders 
    WHERE user_id = ?
    ORDER BY order_id DESC
');
$stm->execute([$_users->id]);
$arr = $stm->fetchAll();

$_title = 'My Orders';
require_once '../_head.php';
?>

<style>
    .order-container {
        max-width: 900px;
        margin: 0 auto;
        padding: 30px;
        border-radius: 8px;
        border: 1px solid #dfdfdf;
    }

    .table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    .table th, .table td {
        padding: 12px 15px;
        border-bottom: 1px solid #444;
        text-align: left;
        vertical-align: middle;
    }

    .table th { font-size: 14px; }
    .right { text-align: right !important; }
    .center { text-align: center !important; }

    .btn-view {
        padding: 6px 12px;
        background: #111;
        color: white;
        text-decoration: none;
        border-radius: 4px;
        font-size: 13px;
        transition: 0.2s;
        display: inline-block;
    }
    .btn-view:hover { background: #333; }
    
    .status-badge {
        padding: 5px 10px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: bold;
        color: white;
        display: inline-block;
        min-width: 80px;
        text-align: center;
        text-transform: uppercase;
    }
    .status-paid { background-color: #ffc107; color: #333; }
    .status-shipped { background-color: #17a2b8; }
    .status-completed { background-color: #28a745; }
    .status-cancelled { background-color: #dc3545; }

    .btn-cancel {
        padding: 6px 12px; 
        background: #dc3545; 
        color: white; 
        text-decoration: none; 
        border-radius: 4px; 
        font-size: 13px; 
        margin-left: 5px; 
        display: inline-block;
        transition: 0.2s;
    }
    .btn-cancel:hover { background: #a71d2a; }

    [data-theme="dark"] .orders-wrapper {
    background: #1e1e1e !important;
    color: #f1f1f1 !important;
    border: 1px solid #333 !important;
    }

    [data-theme="dark"] .orders-wrapper table,
    [data-theme="dark"] .orders-wrapper th,
    [data-theme="dark"] .orders-wrapper td {
        background: transparent !important;
        color: #f1f1f1 !important;
        border-color: #333 !important;
    }
</style>

<div class="order-container">
    <h2>📦 My Orders</h2>
    <p>You have <strong><?= count($arr) ?></strong> order(s).</p>

    <?php if (count($arr) > 0): ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Order Date</th>
                    <th class="center">Status</th>
                    <th class="right">Total (RM)</th>
                    <th class="center">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($arr as $o): ?>
                <tr>
                    <td><strong>#<?= encode($o->order_id) ?></strong></td>
                    
                    <td><?= encode($o->order_date) ?></td>
                    
                    <td class="center">
                        <?php 
                            $status = $o->status ?? 'Paid'; 
                            $badge_class = 'status-paid';
                            if ($status == 'Shipped') $badge_class = 'status-shipped';
                            if ($status == 'Completed') $badge_class = 'status-completed';
                            if ($status == 'Cancelled') $badge_class = 'status-cancelled';
                        ?>
                        <span class="status-badge <?= $badge_class ?>"><?= encode($status) ?></span>
                    </td>

                    <td class="right" style="font-weight:bold;">
                        <?= number_format((float)$o->total_amount, 2) ?>
                    </td>
                    
                    <td class="center">
                        <a href="order_detail.php?id=<?= $o->order_id ?>" class="btn-view">View Detail</a>

                        <?php if (($o->status ?? 'Paid') == 'Paid'): ?>
                            <a href="order_cancel.php?id=<?= $o->order_id ?>" 
                               onclick="return confirm('Confirm cancel this order? Item stocks will be returned.')"
                               class="btn-cancel">
                               Cancel
                            </a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    <?php else: ?>
        <p style="color: #666; margin-top: 20px;">You haven't placed any orders yet. Go buy some books! 📚</p>
    <?php endif; ?>
</div>

<?php require_once '../_foot.php'; ?>