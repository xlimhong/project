<?php
require_once '../_base.php';


auth('member');

// Return order (based on id) belong to the user
$id = req('id'); 
$stm = $_db->prepare('
    SELECT * FROM orders 
    WHERE order_id = ? AND user_id = ?
');
$stm->execute([$id, $_users->id]);
$o = $stm->fetch();

// If order doesn't exist or isn't theirs, redirect back
if (!$o) {
    redirect('order_history.php');
}

//  Return items (and products) belong to the order
$stm = $_db->prepare('
    SELECT i.*, p.product_name, p.photo
    FROM order_items AS i
    JOIN products AS p ON i.product_id = p.product_id
    WHERE i.order_id = ?
');
$stm->execute([$id]);
$arr = $stm->fetchAll();

// calculate how many product for this order
$total_units = 0;
foreach($arr as $i) {
    $total_units += $i->quantity;
}

$_title = 'Order | Detail';
require_once '../_head.php';
?>

<style>
    .order-container {
        max-width: 1000px;
        margin: 0 auto;
        padding: 30px;
        border-radius: 8px;
        border: 1px solid #555; 
    }

    .order-summary {
        padding: 20px;
        border-radius: 6px;
        border: 1px solid #555; 
        margin-bottom: 20px;
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 15px;
    }

    .table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .table th, .table td {
        padding: 12px;
        border-bottom: 1px solid #555;
        text-align: left;
    }
    
 
    .right { text-align: right !important; }
    
    .item-img {
        width: 50px;
        height: 50px;
        object-fit: cover;
        border: 1px solid #ccc;
        vertical-align: middle;
        margin-left: 10px;
    }

    .btn-back {
        display: inline-block;
        padding: 8px 16px;
        background: #444; 
        color: #fff;      
        text-decoration: none;
        border-radius: 4px;
        margin-top: 20px;
    }
    
    .btn-back:hover { background: #222; }
</style>

<div class="order-container">
    <h2>Order Details</h2>

    <div class="order-summary">
        <div>
            <label><strong>Order ID:</strong></label> #<?= encode($o->order_id) ?><br><br>
            <label><strong>Datetime:</strong></label> <?= encode($o->order_date) ?>
        </div>
        <div class="right">
            <label><strong>Total Items:</strong></label> <?= $total_units ?><br><br>
            <label><strong>Total Amount:</strong></label> RM <?= number_format((float)$o->total_amount, 2) ?>
        </div>
    </div>

    <p><strong><?= count($arr) ?></strong> item(s) in this order.</p>

    <table class="table">
        <tr>
            <th>Product ID</th>
            <th>Product Name</th>
            <th class="right">Price (RM)</th>
            <th class="right">Quantity</th>
            <th class="right">Subtotal (RM)</th>
        </tr>

        <?php foreach ($arr as $i): ?>
        <?php 
            //calculate subtotal
            $subtotal = $i->price * $i->quantity; 
        ?>
        <tr>
            <td><?= encode($i->product_id) ?></td>
            <td><?= encode($i->product_name) ?></td>
            <td class="right"><?= number_format((float)$i->price, 2) ?></td>
            <td class="right"><?= encode($i->quantity) ?></td>
            <td class="right">
                <?= number_format((float)$subtotal, 2) ?>
                <img src="../image/product_photos/<?= encode($i->photo) ?>" class="item-img" alt="Product Image">
            </td>
        </tr>
        <?php endforeach ?>

        <tr>
            <th colspan="3" class="right">Grand Total:</th>
            <th class="right"><?= $total_units ?> Units</th>
            <th class="right">RM <?= number_format((float)$o->total_amount, 2) ?></th>
        </tr>
    </table>

    <a href="order_history.php" class="btn-back">← Back to History</a>
</div>

<?php require_once '../_foot.php'; ?>