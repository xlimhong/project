<?php
require '../_base.php';

$wishlisted_items = [];
if (isset($_users) && $_users->role === 'member') {
    $stm_wl = $_db->prepare("SELECT product_id FROM wishlist WHERE user_id = ?");
    $stm_wl->execute([$_users->id]); 
    $wishlisted_items = $stm_wl->fetchAll(PDO::FETCH_COLUMN); 
}
// ------------------------------------------------

// get 4 top selling
$stm_top = $_db->query('
    SELECT p.product_id, p.product_name, p.photo, p.price, SUM(oi.quantity) AS total_sold
    FROM order_items oi
    JOIN products p ON oi.product_id = p.product_id
    GROUP BY p.product_id
    ORDER BY total_sold DESC
    LIMIT 4
');
$top_products = $stm_top->fetchAll();
// ------------------------------------


// 1. Get search and category parameters from URL
$search = get('search');
$category_id = get('category_id');

// 2. Build the SQL query dynamically
// Start with the basic search filter
$sql = "SELECT * FROM products WHERE product_name LIKE ?";
$params = ["%$search%"];

// 3. If a category is selected, append the category filter
if ($category_id) {
    $sql .= " AND category_id = ?";
    $params[] = $category_id;
}

$stm = $_db->prepare($sql);
$stm->execute($params);
$products = $stm->fetchAll();

$_title = 'Product List';
require '../_head.php';
?>

<main>

    <style>
        .top-selling-container { margin: 0 0 40px 0; padding: 20px; background: #fff3cd; border-radius: 8px; border: 1px solid #ffeeba; }
        .top-selling-title { color: #856404; margin-top: 0; margin-bottom: 20px; font-size: 1.5em; font-weight: bold; }
        .product-grid-top { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; }
        .product-card-top { background: white; border: 1px solid #ddd; border-radius: 8px; padding: 15px; text-align: center; box-shadow: 0 2px 5px rgba(0,0,0,0.05); position: relative; display: flex; flex-direction: column; align-items: center; }
        .badge-hot { position: absolute; top: -10px; right: -10px; background: #dc3545; color: white; padding: 5px 10px; border-radius: 50%; font-weight: bold; font-size: 12px; box-shadow: 0 2px 4px rgba(0,0,0,0.2); }
        .sold-count { font-size: 13px; color: #e44d26; font-weight: bold; margin-top: 10px; background: #ffe8e3; padding: 3px 8px; border-radius: 4px; display: inline-block; margin-bottom: 15px;}
        .btn-wish { transition: transform 0.2s; }
        .btn-wish:hover { transform: scale(1.15); }
    </style>

    <div class="top-selling-container">
        <div class="top-selling-title">🔥 Top Selling Products</div>
        
        <?php if (empty($top_products)): ?>
            <p style="color: #856404;">No sales data yet! Be the first to buy something.</p>
        <?php else: ?>
            <div class="product-grid-top">
                <?php foreach ($top_products as $index => $tp): ?>
                    <div class="product-card-top">
                        <?php if ($index == 0): ?>
                            <div class="badge-hot">#1 Top</div>
                        <?php endif; ?>
                        
                        <img src="../image/product_photos/<?= encode($tp->photo) ?>" 
                             alt="<?= encode($tp->product_name) ?>" 
                             style="max-width: 100%; height: 150px; object-fit: cover; margin-bottom: 10px;">
                        
                        <h3 style="min-height: 3.2em; margin: 0 0 10px 0; font-size: 1em;"><?= encode($tp->product_name) ?></h3>
                        <p style="margin: 0; color: #555;">RM <?= number_format((float)$tp->price, 2) ?></p>
                        
                        <div class="sold-count">
                            <?= $tp->total_sold ?> units sold!
                        </div>

                        <div style="display: flex; gap: 8px; margin-top: auto; width: 100%; justify-content: center;">
                            <a href="detail.php?id=<?= $tp->product_id ?>" 
                               style="padding: 5px 10px; background: #0058a3; color: white; text-decoration: none; border-radius: 4px; flex-grow: 1;">
                                View Detail
                            </a>
                            <a href="../wishlist_toggle.php?product_id=<?= $tp->product_id ?>" class="btn-wish"
                               style="padding: 5px 10px; background: #f8f9fa; border: 1px solid #ddd; text-decoration: none; border-radius: 4px; font-size: 1.1em;" 
                               title="Toggle Wishlist">
                                <?= in_array($tp->product_id, $wishlisted_items) ? '❤️' : '🤍' ?>
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    
    <h2 style="margin-bottom: 20px; color: #333; border-bottom: 2px solid #eee; padding-bottom: 10px;">All Products</h2>

    <div class="product-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 20px;">
        
        <?php foreach ($products as $p): ?>
            <div class="product-card" style="border: 1px solid #ccc; padding: 15px; text-align: center; border-radius: 8px; display: flex; flex-direction: column; align-items: center;">
                
                <h3 style="min-height: 3.2em; margin: 0 0 10px 0; font-size: 1em;"><?= encode($p->product_name) ?></h3>
                
                <img src="../image/product_photos/<?= encode($p->photo) ?>" 
                     alt="<?= encode($p->product_name) ?>" 
                     style="max-width: 100%; height: 150px; object-fit: cover; margin-bottom: 10px;">
                
                <p style="margin: 8px 0 15px 0;">RM <?= number_format($p->price, 2) ?></p>
                
                <div style="display: flex; gap: 8px; margin-top: auto; width: 100%; justify-content: center;">
                    <a href="detail.php?id=<?= $p->product_id ?>" 
                       style="padding: 5px 10px; background: #0058a3; color: white; text-decoration: none; border-radius: 4px; flex-grow: 1;">
                        View Detail
                    </a>
                    <a href="../wishlist_toggle.php?product_id=<?= $p->product_id ?>" class="btn-wish"
                       style="padding: 5px 10px; background: #f8f9fa; border: 1px solid #ddd; text-decoration: none; border-radius: 4px; font-size: 1.1em;" 
                       title="Toggle Wishlist">
                        <?= in_array($p->product_id, $wishlisted_items) ? '❤️' : '🤍' ?>
                    </a>
                </div>
            </div>
        <?php endforeach; ?>

    </div>

    <?php if (count($products) == 0): ?>
        <p style="text-align: center; margin-top: 50px;">No products found.</p>
    <?php endif; ?>

</main>
<?php require '../_foot.php'; ?>



