<?php
require_once '../_base.php';

// (1) Authorization (admin) 
auth('admin');

$id = req('id');

if (is_post() && post('action') == 'update_status') {
    $new_status = post('status');
    
    $stm = $_db->prepare('UPDATE `orders` SET status = ? WHERE order_id = ?');
    $stm->execute([$new_status, $id]);
    
    temp('info', "Success: Order status has been updated to '$new_status'.");
    redirect("order_detail.php?id=$id");
}
// ==========================================

// (2) Fetch order details
$stm = $_db->prepare('
    SELECT * FROM `orders`
    WHERE order_id = ?
');
$stm->execute([$id]);
$o = $stm->fetch();

if (!$o) {
    redirect('order_list.php');
}

$stm = $_db->prepare('
    SELECT i.*, p.product_name, p.photo, (i.price * i.quantity) AS subtotal
    FROM order_items AS i
    JOIN products AS p ON i.product_id = p.product_id
    WHERE i.order_id = ?
');
$stm->execute([$id]);
$arr = $stm->fetchAll();


$total_units = 0;
foreach ($arr as $i) {
    $total_units += $i->quantity;
}

$_title = 'Admin | Order Detail';
require_once '../_head.php';
?>

<style>
    .admin-container {
        max-width: 1000px;
        margin: 0 auto;
        background: #fff;
        padding: 30px;
        border-radius: 8px;
        border: 1px solid #dfdfdf;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    }

    .order-summary {
        background: #f1f8ff; 
        padding: 20px;
        border-radius: 6px;
        border: 1px solid #cce5ff;
        margin-bottom: 20px;
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 15px;
    }

    .status-panel {
        background: #fff3cd; 
        padding: 15px 20px;
        border-radius: 6px;
        border: 1px solid #ffeeba;
        margin-bottom: 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .table {
        width: 100%;
        border-collapse: collapse;
    }
    .table th, .table td {
        padding: 12px;
        border-bottom: 1px solid #eee;
        text-align: left;
    }
    .table th { background-color: #f5f5f5; color: #333; }
    .right { text-align: right !important; }
    
    .item-img {
        width: 50px;
        height: 50px;
        object-fit: cover;
        border: 1px solid #ccc;
        vertical-align: middle;
        margin-left: 10px;
    }

    .btn-back {
        display: inline-block;
        padding: 8px 16px;
        background: #eee;
        color: #333;
        text-decoration: none;
        border-radius: 4px;
        margin-top: 20px;
        transition: 0.2s;
    }
    .btn-back:hover { background: #ddd; }

    .badge-buyer {
        display: inline-block;
        background: #0058a3;
        color: white;
        padding: 3px 8px;
        border-radius: 4px;
        font-size: 12px;
        margin-left: 10px;
    }
</style>

<main class="admin-container">
    <h2>📦 Manage Order Details</h2>
    
    <?php err('info'); ?>

    <?php if ($o->status === 'Cancelled'): ?>
        
        <div class="status-panel" style="background: #ffebeb; border-color: #cf182a; justify-content: center;">
            <span style="color: #cf182a; font-weight: bold; font-size: 16px;">
                ❌ This order has been cancelled and its status can no longer be updated.
            </span>
        </div>

    <?php else: ?>

        <div class="status-panel">
            <form method="POST" action="" style="margin: 0; display: flex; gap: 15px; align-items: center; width: 100%;">
                <input type="hidden" name="action" value="update_status">
                
                <div style="flex-grow: 1;">
                    <label style="font-weight: bold; color: #856404; margin-right: 10px;">Update Order Status:</label>
                    <select name="status" style="padding: 8px; border-radius: 4px; border: 1px solid #ccc; font-size: 14px; width: 200px;">
                        <option value="Paid" <?= $o->status == 'Paid' ? 'selected' : '' ?>>📦 Paid (To Ship)</option>
                        <option value="Shipped" <?= $o->status == 'Shipped' ? 'selected' : '' ?>>🚚 Shipped</option>
                        <option value="Completed" <?= $o->status == 'Completed' ? 'selected' : '' ?>>✅ Completed</option>
                        <option value="Cancelled" <?= $o->status == 'Cancelled' ? 'selected' : '' ?>>❌ Cancelled</option>
                    </select>
                </div>
                
                <button type="submit" style="background: #28a745; color: white; border: none; padding: 8px 20px; border-radius: 4px; cursor: pointer; font-weight: bold; transition: 0.2s;">
                    Save Status
                </button>
            </form>
        </div>

    <?php endif; ?>

    <div class="order-summary">
        <div>
            <label><strong>Order ID:</strong></label> #<?= encode($o->order_id) ?><br><br>
            <label><strong>Buyer:</strong></label> User #<?= encode($o->user_id) ?> 
            <span class="badge-buyer">Customer</span><br><br>
            <label><strong>Datetime:</strong></label> <?= encode($o->order_date) ?>
        </div>
        <div class="right">
            <label><strong>Current Status:</strong></label> 
            <span style="font-weight: bold; font-size: 1.1em; color: <?= $o->status == 'Cancelled' ? '#dc3545' : '#28a745' ?>;">
                <?= encode($o->status) ?>
            </span><br><br>
            <label><strong>Total Items:</strong></label> <?= $total_units ?> Units<br><br>
            <label><strong>Total Amount:</strong></label> RM <?= number_format((float)$o->total_amount, 2) ?>
        </div>
    </div>

    <p>This order contains <strong><?= count($arr) ?></strong> item(s).</p>

    <table class="table">
        <tr>
            <th>Product ID</th>
            <th>Product Name</th>
            <th class="right">Price (RM)</th>
            <th class="right">Unit</th>
            <th class="right">Subtotal (RM)</th>
        </tr>

        <?php foreach ($arr as $i): ?>
        <tr>
            <td><?= encode($i->product_id) ?></td>
            <td><?= encode($i->product_name) ?></td>
            <td class="right"><?= number_format((float)$i->price, 2) ?></td>
            <td class="right"><?= encode($i->quantity) ?></td>
            <td class="right">
                <?= number_format((float)$i->subtotal, 2) ?>
                <img src="/image/product_photos/<?= encode($i->photo) ?>" class="item-img" alt="Product Image" onerror="this.style.display='none'">
            </td>
        </tr>
        <?php endforeach ?>

        <tr>
            <th colspan="3" class="right" style="font-size: 16px;">Grand Total:</th>
            <th class="right" style="font-size: 16px;"><?= $total_units ?> Units</th>
            <th class="right" style="font-size: 16px; color: #0058a3;">RM <?= number_format((float)$o->total_amount, 2) ?></th>
        </tr>
    </table>

    <a href="order_list.php" class="btn-back">← Back to All Orders</a>
</main>

<?php require_once '../_foot.php'; ?>