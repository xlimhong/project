<?php
include '../_base.php';

auth('admin');

    $stm = $_db->prepare("
        SELECT ar.*, u.name, u.email, u.photo
        FROM admin_request ar
        JOIN users u ON ar.user_id = u.id
        WHERE ar.status = 'pending'
        ORDER BY ar.created_at DESC
    ");
    $stm->execute();
    $req = $stm->fetchAll();

    $_title = 'Admin Request List';
    include '../_head.php';
    ?>

<style>
    .request-page {
        background: #f5f6fa;
        border-radius: 16px;
        padding: 24px;
        margin-top: 20px;
        margin-bottom: 20px;
    }

    .request-hero {
        background: linear-gradient(135deg, #0058a3, #0b7ad1);
        color: white;
        border-radius: 16px;
        padding: 24px 28px;
        margin-bottom: 20px;
        box-shadow: 0 10px 24px rgba(0, 88, 163, 0.16);
    }

    .request-hero h1 {
        margin: 0 0 8px;
        font-size: 32px;
        font-weight: 800;
    }

    .request-hero p {
        margin: 0;
        font-size: 14px;
        opacity: 0.95;
    }

    .summary-box {
        display: inline-block;
        background: white;
        border-radius: 14px;
        padding: 16px 20px;
        margin-bottom: 20px;
        box-shadow: 0 4px 14px rgba(0,0,0,0.06);
    }

    .summary-box .label {
        font-size: 13px;
        color: #666;
        margin-bottom: 6px;
    }

    .summary-box .value {
        font-size: 28px;
        font-weight: 800;
        color: #111;
    }

    .request-table-card {
        background: white;
        border-radius: 16px;
        overflow: hidden;
        box-shadow: 0 4px 14px rgba(0,0,0,0.06);
    }

    .request-table-header {
        padding: 18px 20px;
        border-bottom: 1px solid #eee;
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 10px;
    }

    .request-table-header h3 {
        margin: 0;
        font-size: 18px;
        color: #111;
    }

    .request-table-header span {
        font-size: 13px;
        color: #666;
        background: #f3f4f6;
        padding: 6px 10px;
        border-radius: 999px;
    }

    .table-wrap {
        overflow-x: auto;
    }

    .request-table {
        width: 100%;
        border-collapse: collapse;
        min-width: 950px;
    }

    .request-table thead {
        background: #f8f8f8;
    }

    .request-table th,
    .request-table td {
        padding: 16px 18px;
        text-align: left;
        border-bottom: 1px solid #eee;
        font-size: 14px;
        vertical-align: middle;
    }

    .request-table th {
        font-weight: 700;
        color: #333;
    }

    .request-table tbody tr:hover {
        background: #fcfcfc;
    }

    .request-id {
        font-weight: 700;
        color: #0058a3;
        word-break: break-all;
    }

    .photo-box img {
        width: 64px;
        height: 64px;
        object-fit: cover;
        border-radius: 50%;
        border: 2px solid #eee;
        background: #f5f5f5;
    }

    .user-name {
        font-weight: 700;
        color: #111;
    }

    .user-email {
        color: #666;
    }

    .date-text {
        color: #333;
        font-weight: 600;
        white-space: nowrap;
    }

    .action-group {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
        align-items: center;
    }

    .btn-action {
        display: inline-block;
        border: none;
        border-radius: 8px;
        padding: 9px 14px;
        font-size: 14px;
        font-weight: 700;
        text-decoration: none;
        cursor: pointer;
        transition: 0.2s ease;
    }

    .btn-action:hover {
        transform: translateY(-1px);
        opacity: 0.95;
    }

    .btn-approve {
        background: #16a34a;
        color: white;
    }

    .btn-reject {
        background: #dc2626;
        color: white;
    }

    .empty-state {
        padding: 40px 20px;
        text-align: center;
        color: #666;
    }

    [data-theme="dark"] .request-page {
        background: #181818;
    }

    [data-theme="dark"] .summary-box,
    [data-theme="dark"] .request-table-card {
        background: #222;
        box-shadow: none;
    }

    [data-theme="dark"] .request-table thead {
        background: #2a2a2a;
    }

    [data-theme="dark"] .request-table th,
    [data-theme="dark"] .request-table td,
    [data-theme="dark"] .request-table-header,
    [data-theme="dark"] .request-table-header h3,
    [data-theme="dark"] .user-name,
    [data-theme="dark"] .date-text,
    [data-theme="dark"] .summary-box .value {
        color: #f1f1f1;
    }

    [data-theme="dark"] .user-email,
    [data-theme="dark"] .empty-state,
    [data-theme="dark"] .summary-box .label,
    [data-theme="dark"] .request-table-header span {
        color: #bbb;
    }

    [data-theme="dark"] .request-table th,
    [data-theme="dark"] .request-table td,
    [data-theme="dark"] .request-table-header {
        border-color: #333;
    }

    [data-theme="dark"] .request-table-header span {
        background: #2f2f2f;
    }

    @media (max-width: 768px) {
        .request-hero h1 {
            font-size: 24px;
        }

        .action-group {
            flex-direction: column;
            align-items: flex-start;
        }
    }
</style>

<div class="request-page">

    <div class="request-hero">
        <h1>Admin Request List</h1>
        <p>Review all pending admin access requests here.</p>
    </div>

    <div class="summary-box">
        <div class="label">Pending Requests</div>
        <div class="value"><?= count($req) ?></div>
    </div>

    <div class="request-table-card">
        <div class="request-table-header">
            <h3>Pending Request List</h3>
            <span>Total: <?= count($req) ?> record(s)</span>
        </div>

        <?php if (!$req): ?>
            <div class="empty-state">No pending request.</div>
        <?php else: ?>
            <div class="table-wrap">
                <table class="request-table">
                    <thead>
                        <tr>
                            <th>Request ID</th>
                            <th>Photo</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Created At</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                <tbody>
                    <?php foreach ($req as $r): ?>
                    <tr>
                        <td class="request-id"><?= htmlspecialchars($r->id) ?></td>

                        <td class="photo-box">
                            <img src="/image/user_photos/<?= htmlspecialchars($r->photo ?: 'default.png') ?>" alt="User Photo">
                        </td>

                        <td class="user-name"><?= htmlspecialchars($r->name) ?></td>
                        <td class="user-email"><?= htmlspecialchars($r->email) ?></td>
                        <td class="date-text"><?= htmlspecialchars($r->created_at) ?></td>

                        <td>
                            <div class="action-group">
                                <a class="btn-action btn-approve"
                                    href="admin_request_action.php?id=<?= urlencode($r->id) ?>&action=approve"
                                    onclick="return confirm('Approve this request?')">
                                    Approve
                                </a>

                                <a class="btn-action btn-reject"
                                    href="admin_request_action.php?id=<?= urlencode($r->id) ?>&action=reject"
                                    onclick="return confirm('Reject this request?')">
                                    Reject
                                </a>
                        </div>
                    </td>
                    </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
            </div>
        <?php endif; ?>
    </div>

</div>

<?php include '../_foot.php'; ?>