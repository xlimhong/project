<?php
require '../_base.php';

// Strict Authorization
auth('admin');

$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. Get the form data (Now including the ID)
    $id = trim($_POST['id'] ?? '');
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    // Basic validation
    if (empty($id) || empty($name) || empty($email) || empty($password)) {
        $error_message = "Please fill in all fields, including the ID.";
    } else {
        try {
            // Check if email OR ID already exists
            $stm = $_db->prepare("SELECT * FROM users WHERE email = ? OR id = ?");
            $stm->execute([$email, $id]);
            $existing_user = $stm->fetch();
            
            if ($existing_user) {
                if ($existing_user->email === $email) {
                    $error_message = "This email is already registered.";
                } else {
                    $error_message = "This Admin ID is already in use. Please choose another.";
                }
            } else {
                // Hash password and insert into database (Now including the ID)
                $hash = password_hash($password, PASSWORD_DEFAULT);
                
                $stm = $_db->prepare("INSERT INTO users (id, name, email, password, role) VALUES (?, ?, ?, ?, 'admin')");
                $stm->execute([$id, $name, $email, $hash]);

                // Success redirect back to the admin list
                header('Location:admin_list.php');
                exit;
            }
        } catch (PDOException $e) {
            $error_message = "Database Error: " . $e->getMessage();
        }
    }
}

$_title = 'Add New Admin';
require '../_head.php';
?>

<div style="max-width: 500px; margin: 40px auto; padding: 20px; border: 1px solid #ccc; border-radius: 8px; background: #fff;">
    <h2 style="text-align: center; margin-bottom: 20px;">+ Create New Admin</h2>

    <?php if ($error_message): ?>
        <div style="background: #ffdddd; color: red; padding: 10px; margin-bottom: 15px; border: 1px solid red; border-radius: 5px;">
            <?= htmlspecialchars($error_message) ?>
        </div>
    <?php endif; ?>

    <form method="post" action="">
        <div style="margin-bottom: 15px;">
            <label style="display: block; font-weight: bold; margin-bottom: 5px;">Admin ID:</label>
            <input type="text" name="id" required style="width: 100%; padding: 8px; box-sizing: border-box;" placeholder="e.g. ADM001">
        </div>

        <div style="margin-bottom: 15px;">
            <label style="display: block; font-weight: bold; margin-bottom: 5px;">Admin Name:</label>
            <input type="text" name="name" required style="width: 100%; padding: 8px; box-sizing: border-box;">
        </div>

        <div style="margin-bottom: 15px;">
            <label style="display: block; font-weight: bold; margin-bottom: 5px;">Email Address:</label>
            <input type="email" name="email" required style="width: 100%; padding: 8px; box-sizing: border-box;">
        </div>

        <div style="margin-bottom: 20px;">
            <label style="display: block; font-weight: bold; margin-bottom: 5px;">Password:</label>
            <input type="password" name="password" required style="width: 100%; padding: 8px; box-sizing: border-box;">
        </div>

        <button type="submit" style="width: 100%; background: green; color: white; padding: 10px; border: none; font-size: 16px; cursor: pointer; border-radius: 5px;">
            Create Admin
        </button>
        
        <div style="text-align: center; margin-top: 15px;">
            <a href="admin_list.php" style="color: #666; text-decoration: none;">Cancel and Go Back</a>
        </div>
    </form>
</div>

<?php require '../_foot.php'; ?>