<?php
include '../_base.php';

auth();

if (empty($_SESSION['password_token_id'])) {
    redirect('/user/change_password.php');
}

$token_id = $_SESSION['password_token_id'];

if (is_post()) {
    $code = req('code');

    if ($code == '') {
        $_err['code'] = 'Required';
    }
    else if (!preg_match('/^\d{6}$/', $code)) {
        $_err['code'] = 'Code must be 6 digits';
    }

    if (!$_err) {
        // 删除过期 token
        $stm = $_db->prepare('DELETE FROM token WHERE expire < NOW()');
        $stm->execute();

        // 查 token
        $stm = $_db->prepare('
            SELECT * FROM token
            WHERE id = ? AND user_id = ?
        ');
        $stm->execute([$token_id, $_users->id]);
        $t = $stm->fetch();

        if (!$t) {
            $_err['code'] = 'Code expired or invalid';
        }
        else if ($t->code != $code) {
            $_err['code'] = 'Wrong verification code';
        }
        else {
            // 正式更新密码
            $stm = $_db->prepare('
                UPDATE users
                SET password = ?
                WHERE id = ?
            ');
            $stm->execute([$t->new_password, $_users->id]);

            // 删除 token
            $stm = $_db->prepare('DELETE FROM token WHERE id = ?');
            $stm->execute([$token_id]);

            unset($_SESSION['password_token_id']);

            temp('info', 'Password updated successfully');
            redirect('/user/profile.php');
        }
    }
}

$_title = 'User | Verify Code';
include '../_head.php';
?>

<style>
    .verify-page {
        max-width: 860px;
        margin: 28px auto;
        padding: 0 20px 30px;
    }

    .verify-hero {
        background: linear-gradient(135deg, #0058a3, #0b7ad1);
        color: #fff;
        border-radius: 18px;
        padding: 28px 30px;
        margin-bottom: 20px;
        box-shadow: 0 10px 24px rgba(0, 88, 163, 0.16);
    }

    .verify-hero h1 {
        margin: 0 0 8px;
        font-size: 30px;
        font-weight: 800;
    }

    .verify-hero p {
        margin: 0;
        font-size: 14px;
        opacity: 0.96;
        line-height: 1.6;
    }

    .verify-layout {
        display: grid;
        grid-template-columns: 1.1fr 0.9fr;
        gap: 20px;
        align-items: start;
    }

    .verify-card,
    .verify-info-card {
        background: #fff;
        border-radius: 18px;
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.06);
        border: 1px solid #e5e7eb;
        overflow: hidden;
    }

    .verify-card-header,
    .verify-info-header {
        padding: 20px 24px;
        border-bottom: 1px solid #eee;
        background: #fafafa;
    }

    .verify-card-header h2,
    .verify-info-header h3 {
        margin: 0;
        font-size: 20px;
        font-weight: 800;
        color: #111;
    }

    .verify-card-body,
    .verify-info-body {
        padding: 24px;
    }

    .form-row {
        margin-bottom: 20px;
    }

    .form-row label {
        display: block;
        margin-bottom: 8px;
        font-size: 14px;
        font-weight: 700;
        color: #222;
    }

    .form-row input[type="text"] {
        width: 100%;
        padding: 14px 16px;
        border: 1px solid #d1d5db;
        border-radius: 12px;
        font-size: 20px;
        letter-spacing: 6px;
        text-align: center;
        background: #f9fafb;
        outline: none;
        transition: 0.2s ease;
        box-sizing: border-box;
        font-weight: 700;
    }

    .form-row input[type="text"]:focus {
        border-color: #0058a3;
        background: #fff;
        box-shadow: 0 0 0 4px rgba(0, 88, 163, 0.12);
    }

    .form-hint {
        margin-top: 8px;
        font-size: 12px;
        color: #6b7280;
        line-height: 1.5;
    }

    .err {
        display: block;
        margin-top: 6px;
        font-size: 13px;
        font-weight: 600;
        color: #cf182a;
    }

    .verify-actions {
        display: flex;
        gap: 12px;
        flex-wrap: wrap;
        margin-top: 28px;
    }

    .btn-verify,
    .btn-back {
        display: inline-block;
        text-decoration: none;
        border: none;
        border-radius: 12px;
        padding: 11px 18px;
        font-size: 14px;
        font-weight: 700;
        cursor: pointer;
        transition: 0.2s ease;
    }

    .btn-verify {
        background: #0058a3;
        color: #fff;
    }

    .btn-verify:hover {
        background: #00457f;
        transform: translateY(-1px);
    }

    .btn-back {
        background: #f3f4f6;
        color: #111;
    }

    .btn-back:hover {
        background: #e5e7eb;
        transform: translateY(-1px);
    }

    .info-list {
        display: grid;
        gap: 14px;
    }

    .info-item {
        background: #f8fafc;
        border: 1px solid #e5e7eb;
        border-radius: 14px;
        padding: 14px 15px;
    }

    .info-item b {
        display: block;
        margin-bottom: 6px;
        color: #111;
        font-size: 14px;
    }

    .info-item span {
        color: #555;
        font-size: 13px;
        line-height: 1.6;
    }

    .security-note {
        margin-top: 18px;
        padding: 14px 15px;
        border-radius: 14px;
        background: #eef6ff;
        border: 1px solid #cfe3fb;
        color: #114a7a;
        font-size: 13px;
        line-height: 1.6;
    }

    [data-theme="dark"] .verify-card,
    [data-theme="dark"] .verify-info-card {
        background: #1f1f1f;
        border-color: #333;
        box-shadow: none;
    }

    [data-theme="dark"] .verify-card-header,
    [data-theme="dark"] .verify-info-header {
        background: #252525;
        border-color: #333;
    }

    [data-theme="dark"] .verify-card-header h2,
    [data-theme="dark"] .verify-info-header h3,
    [data-theme="dark"] .form-row label,
    [data-theme="dark"] .info-item b {
        color: #f1f1f1;
    }

    [data-theme="dark"] .form-row input[type="text"] {
        background: #2a2a2a;
        border-color: #444;
        color: #fff;
    }

    [data-theme="dark"] .form-row input[type="text"]:focus {
        border-color: #4fa3e3;
        box-shadow: 0 0 0 4px rgba(79, 163, 227, 0.15);
        background: #2f2f2f;
    }

    [data-theme="dark"] .form-hint,
    [data-theme="dark"] .info-item span {
        color: #bdbdbd;
    }

    [data-theme="dark"] .btn-back {
        background: #2a2a2a;
        color: #f1f1f1;
    }

    [data-theme="dark"] .btn-back:hover {
        background: #343434;
    }

    [data-theme="dark"] .info-item {
        background: #262626;
        border-color: #383838;
    }

    [data-theme="dark"] .security-note {
        background: #1f3142;
        border-color: #2d4b68;
        color: #cfe6ff;
    }

    @media (max-width: 860px) {
        .verify-layout {
            grid-template-columns: 1fr;
        }
    }

    @media (max-width: 600px) {
        .verify-page {
            padding: 0 12px 24px;
        }

        .verify-hero {
            padding: 22px 20px;
        }

        .verify-hero h1 {
            font-size: 24px;
        }

        .verify-card-body,
        .verify-info-body,
        .verify-card-header,
        .verify-info-header {
            padding: 20px;
        }

        .verify-actions {
            flex-direction: column;
        }

        .btn-verify,
        .btn-back {
            width: 100%;
            text-align: center;
        }

        .form-row input[type="text"] {
            font-size: 18px;
            letter-spacing: 4px;
        }
    }
</style>

<div class="verify-page">
    <div class="verify-hero">
        <h1>Email Verification</h1>
        <p>
            A 6-digit verification code has been sent to your email.
            Enter the code below to confirm your password change.
        </p>
    </div>

    <div class="verify-layout">
        <div class="verify-card">
            <div class="verify-card-header">
                <h2>Enter Verification Code</h2>
            </div>

            <div class="verify-card-body">
                <form method="post" class="form" autocomplete="off">
                    <div class="form-row">
                        <label for="code">Verification Code</label>
                        <?= html_text('code', 'maxlength="6" placeholder="000000" inputmode="numeric"') ?>
                        <div class="form-hint">Enter the 6-digit code exactly as shown in your email. The code expires in 5 minutes.</div>
                        <?= err('code') ?>
                    </div>

                    <div class="verify-actions">
                        <button class="btn-verify">Verify Code</button>
                        <a href="change_password.php" class="btn-back">Back</a>
                    </div>
                </form>
            </div>
        </div>

        <div class="verify-info-card">
            <div class="verify-info-header">
                <h3>What Happens Next</h3>
            </div>

            <div class="verify-info-body">
                <div class="info-list">
                    <div class="info-item">
                        <b>Step 1</b>
                        <span>Check your email inbox for the verification code sent by the system.</span>
                    </div>

                    <div class="info-item">
                        <b>Step 2</b>
                        <span>Enter the 6-digit code into the input box on this page.</span>
                    </div>

                    <div class="info-item">
                        <b>Step 3</b>
                        <span>If the code is correct and not expired, your new password will be saved immediately.</span>
                    </div>
                </div>

                <div class="security-note">
                    For account safety, the system only changes your password after the correct email verification code is entered successfully.
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include '../_foot.php';
?>