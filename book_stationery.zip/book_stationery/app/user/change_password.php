<?php
include '../_base.php';

auth();

if (is_post()) {
    $password     = req('password');
    $new_password = req('new_password');
    $confirm      = req('confirm');
    
    $stm = $_db->prepare('SELECT * FROM users WHERE id = ?');
    $stm->execute([$_users->id]);
    $u = $stm->fetch();

    // Validate: current password
    if ($password == '') {
        $_err['password'] = 'Required';
    }
    else if (strlen($password) < 5 || strlen($password) > 100) {
        $_err['password'] = 'Between 5-100 characters';
    }
    else {
        $stm = $_db->prepare('
            SELECT COUNT(*) FROM users
            WHERE password = SHA1(?) AND id = ?
        ');
        $stm->execute([$password, $_users->id]);

        if ($stm->fetchColumn() == 0) {
            $_err['password'] = 'Current password not matched';
        }
    }

    // Validate: new password
    if ($new_password == '') {
        $_err['new_password'] = 'Required';
    }
    else if (strlen($new_password) < 5 || strlen($new_password) > 100) {
        $_err['new_password'] = 'Between 5-100 characters';
    }

    // Validate: confirm
    if ($confirm == '') {
        $_err['confirm'] = 'Required';
    }
    else if (strlen($confirm) < 5 || strlen($confirm) > 100) {
        $_err['confirm'] = 'Between 5-100 characters';
    }
    else if ($confirm != $new_password) {
        $_err['confirm'] = 'Not matched';
    }

    // Optional: prevent same password
    if (!$_err && $password == $new_password) {
        $_err['new_password'] = 'New password cannot be the same as current password';
    }

    // Send email code
    if (!$_err) {
        $id   = sha1(uniqid() . rand());
        $code = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
        $hash = SHA1($new_password);

        // delete old token
        $stm = $_db->prepare('DELETE FROM token WHERE user_id = ?');
        $stm->execute([$_users->id]);

        // new token
        $stm = $_db->prepare('
            INSERT INTO token (id, code, expire, user_id, new_password)
            VALUES (?, ?, ADDTIME(NOW(), "00:05"), ?, ?)
        ');
        $stm->execute([$id, $code, $_users->id, $hash]);

        // send email
        $m = get_mail('Password Verification');
        $m->addAddress($u->email, $u->name);
        $m->Subject = 'Password Verification Code';
        $m->isHTML(true);
        $m->Body = "
            <p>Dear $u->name,</p>
            <h2 style='color:#0058a3;'>Password Change Verification</h2>
            <p>Your verification code is:</p>
            <h1 style='letter-spacing: 4px;'>$code</h1>
            <p>This code will expire in 5 minutes.</p>
            <p>If you did not request this, please ignore this email.</p>
            <p>From,<br>Books & Stationery Store</p>
        ";
        $m->send();

        // record token id in session
        $_SESSION['password_token_id'] = $id;

        temp('info', 'Verification code sent to your email.');
        redirect('/user/password_code_verify.php');
    }
}

$_title = 'User | Password';
include '../_head.php';
?>

<style>
    .password-page {
        max-width: 860px;
        margin: 28px auto;
        padding: 0 20px 30px;
    }

    .password-hero {
        background: linear-gradient(135deg, #0058a3, #0b7ad1);
        color: #fff;
        border-radius: 18px;
        padding: 28px 30px;
        margin-bottom: 20px;
        box-shadow: 0 10px 24px rgba(0, 88, 163, 0.16);
    }

    .password-hero h1 {
        margin: 0 0 8px;
        font-size: 30px;
        font-weight: 800;
    }

    .password-hero p {
        margin: 0;
        font-size: 14px;
        opacity: 0.96;
        line-height: 1.6;
    }

    .password-layout {
        display: grid;
        grid-template-columns: 1.2fr 0.8fr;
        gap: 20px;
        align-items: start;
    }

    .password-card,
    .password-info-card {
        background: #fff;
        border-radius: 18px;
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.06);
        border: 1px solid #e5e7eb;
        overflow: hidden;
    }

    .password-card-header,
    .password-info-header {
        padding: 20px 24px;
        border-bottom: 1px solid #eee;
        background: #fafafa;
    }

    .password-card-header h2,
    .password-info-header h3 {
        margin: 0;
        font-size: 20px;
        font-weight: 800;
        color: #111;
    }

    .password-card-body,
    .password-info-body {
        padding: 24px;
    }

    .form-row {
        margin-bottom: 20px;
    }

    .form-row label {
        display: block;
        margin-bottom: 8px;
        font-size: 14px;
        font-weight: 700;
        color: #222;
    }

    .form-row input[type="password"] {
        width: 100%;
        padding: 12px 14px;
        border: 1px solid #d1d5db;
        border-radius: 12px;
        font-size: 15px;
        background: #f9fafb;
        outline: none;
        transition: 0.2s ease;
        box-sizing: border-box;
    }

    .form-row input[type="password"]:focus {
        border-color: #0058a3;
        background: #fff;
        box-shadow: 0 0 0 4px rgba(0, 88, 163, 0.12);
    }

    .form-hint {
        margin-top: 7px;
        font-size: 12px;
        color: #6b7280;
        line-height: 1.5;
    }

    .err {
        display: block;
        margin-top: 6px;
        font-size: 13px;
        font-weight: 600;
        color: #cf182a;
    }

    .password-actions {
        display: flex;
        gap: 12px;
        flex-wrap: wrap;
        margin-top: 28px;
    }

    .btn-submit,
    .btn-reset,
    .btn-back {
        display: inline-block;
        text-decoration: none;
        border: none;
        border-radius: 12px;
        padding: 11px 18px;
        font-size: 14px;
        font-weight: 700;
        cursor: pointer;
        transition: 0.2s ease;
    }

    .btn-submit {
        background: #0058a3;
        color: #fff;
    }

    .btn-submit:hover {
        background: #00457f;
        transform: translateY(-1px);
    }

    .btn-reset {
        background: #f3f4f6;
        color: #111;
    }

    .btn-reset:hover {
        background: #e5e7eb;
        transform: translateY(-1px);
    }

    .btn-back {
        background: #ffcc00;
        color: #111;
    }

    .btn-back:hover {
        background: #e6b800;
        transform: translateY(-1px);
    }

    .info-list {
        display: grid;
        gap: 14px;
    }

    .info-item {
        background: #f8fafc;
        border: 1px solid #e5e7eb;
        border-radius: 14px;
        padding: 14px 15px;
    }

    .info-item b {
        display: block;
        margin-bottom: 6px;
        color: #111;
        font-size: 14px;
    }

    .info-item span {
        color: #555;
        font-size: 13px;
        line-height: 1.6;
    }

    .security-note {
        margin-top: 18px;
        padding: 14px 15px;
        border-radius: 14px;
        background: #eef6ff;
        border: 1px solid #cfe3fb;
        color: #114a7a;
        font-size: 13px;
        line-height: 1.6;
    }

    [data-theme="dark"] .password-card,
    [data-theme="dark"] .password-info-card {
        background: #1f1f1f;
        border-color: #333;
        box-shadow: none;
    }

    [data-theme="dark"] .password-card-header,
    [data-theme="dark"] .password-info-header {
        background: #252525;
        border-color: #333;
    }

    [data-theme="dark"] .password-card-header h2,
    [data-theme="dark"] .password-info-header h3,
    [data-theme="dark"] .form-row label,
    [data-theme="dark"] .info-item b {
        color: #f1f1f1;
    }

    [data-theme="dark"] .form-row input[type="password"] {
        background: #2a2a2a;
        border-color: #444;
        color: #fff;
    }

    [data-theme="dark"] .form-row input[type="password"]:focus {
        border-color: #4fa3e3;
        box-shadow: 0 0 0 4px rgba(79, 163, 227, 0.15);
        background: #2f2f2f;
    }

    [data-theme="dark"] .form-hint,
    [data-theme="dark"] .info-item span {
        color: #bdbdbd;
    }

    [data-theme="dark"] .btn-reset {
        background: #2a2a2a;
        color: #f1f1f1;
    }

    [data-theme="dark"] .btn-reset:hover {
        background: #343434;
    }

    [data-theme="dark"] .info-item {
        background: #262626;
        border-color: #383838;
    }

    [data-theme="dark"] .security-note {
        background: #1f3142;
        border-color: #2d4b68;
        color: #cfe6ff;
    }

    @media (max-width: 860px) {
        .password-layout {
            grid-template-columns: 1fr;
        }
    }

    @media (max-width: 600px) {
        .password-page {
            padding: 0 12px 24px;
        }

        .password-hero {
            padding: 22px 20px;
        }

        .password-hero h1 {
            font-size: 24px;
        }

        .password-card-body,
        .password-info-body,
        .password-card-header,
        .password-info-header {
            padding: 20px;
        }

        .password-actions {
            flex-direction: column;
        }

        .btn-submit,
        .btn-reset,
        .btn-back {
            width: 100%;
            text-align: center;
        }
    }
</style>

<div class="password-page">
    <div class="password-hero">
        <h1>Change Password</h1>
        <p>
            Update your account password securely. After submission, a verification code
            will be sent to your email, and you must enter that code before the password
            change is completed.
        </p>
    </div>

    <div class="password-layout">
        <div class="password-card">
            <div class="password-card-header">
                <h2>Password Update Form</h2>
            </div>

            <div class="password-card-body">
                <form method="post" class="form">
                    <div class="form-row">
                        <label for="password">Current Password</label>
                        <?= html_password('password', 'maxlength="100"') ?>
                        <?= err('password') ?>
                    </div>

                    <div class="form-row">
                        <label for="new_password">New Password</label>
                        <?= html_password('new_password', 'maxlength="100"') ?>
                        <div class="form-hint">Use 5 to 100 characters and choose a password you have not used before.</div>
                        <?= err('new_password') ?>
                    </div>

                    <div class="form-row">
                        <label for="confirm">Confirm New Password</label>
                        <?= html_password('confirm', 'maxlength="100"') ?>
                        <div class="form-hint">Re-enter the new password exactly the same.</div>
                        <?= err('confirm') ?>
                    </div>

                    <div class="password-actions">
                        <button class="btn-submit">Send Verification Code</button>
                        <button type="reset" class="btn-reset">Reset</button>
                        <a href="profile.php" class="btn-back">Back to Profile</a>
                    </div>
                </form>
            </div>
        </div>

        <div class="password-info-card">
            <div class="password-info-header">
                <h3>Verification Steps</h3>
            </div>

            <div class="password-info-body">
                <div class="info-list">
                    <div class="info-item">
                    <b>Step 1</b>
                    <span>Enter your current password and your new password.</span>
                </div>

                <div class="info-item">
                    <b>Step 2</b>
                    <span>The system sends a 6-digit verification code to your registered email.</span>
                </div>

                <div class="info-item">
                    <b>Step 3</b>
                    <span>Enter the code on the next page to confirm the password change.</span>
                </div>
        </div>

        <div class="security-note">
            For your account safety, the password is not updated immediately. It will only be changed after email verification is completed successfully.
        </div>
    </div>
    </div>
    </div>
</div>

<?php
include '../_foot.php';
?>