<?php
include '../_base.php';

// ----------------------------------------------------------------------------

// Authenticated users
auth();

if (is_get()) {
    $stm = $_db->prepare('SELECT * FROM users WHERE id = ?');
    $stm->execute([$_users->id]);
    $u = $stm->fetch();

    if (!$u) {
        redirect('/');
    }

    extract((array)$u);
    $_SESSION['photo'] = $u->photo;
}

if (is_post()) {
    $email = req('email');
    $name  = req('name');
    $photo = $_SESSION['photo'] ?? '';
    $f     = get_file('photo');

    // Validate: email
    if ($email == '') {
        $_err['email'] = 'Required';
    }
    else if (strlen($email) > 100) {
        $_err['email'] = 'Maximum 100 characters';
    }
    else if (!is_email($email)) {
        $_err['email'] = 'Invalid email';
    }
    else {
        $stm = $_db->prepare('
            SELECT COUNT(*) FROM users
            WHERE email = ? AND id != ?
        ');
        $stm->execute([$email, $_users->id]);

        if ($stm->fetchColumn() > 0) {
            $_err['email'] = 'Duplicated';
        }
    }

    // Validate: name
    if ($name == '') {
        $_err['name'] = 'Required';
    }
    else if (strlen($name) > 100) {
        $_err['name'] = 'Maximum 100 characters';
    }

    // Validate: photo
    if ($f) {
        if (!str_starts_with($f->type, 'image/')) {
            $_err['photo'] = 'Must be image';
        }
        else if ($f->size > 1 * 1024 * 1024) {
            $_err['photo'] = 'Maximum 1MB';
        }
    }

    // DB operation
    if (!$_err) {
        // Only replace photo if user uploaded a new one
        if ($f) {
            if ($photo && file_exists(USER_PHOTO_PATH . "/$photo")) {
                unlink(USER_PHOTO_PATH . "/$photo");
            }

            $photo = save_photo($f, USER_PHOTO_PATH);
        }

        // Update user
        $stm = $_db->prepare('
            UPDATE users
            SET email = ?, name = ?, photo = ?
            WHERE id = ?
        ');
        $stm->execute([$email, $name, $photo, $_users->id]);

        // Update global user object
        $_users->email = $email;
        $_users->name  = $name;
        $_users->photo = $photo;

        // Update session photo too
        $_SESSION['photo'] = $photo;

        temp('info', 'Record updated');
        redirect('/homepage.php');
    }
}

// ----------------------------------------------------------------------------

$_title = 'User | Profile';
include '../_head.php';
?>

<style>
    .simple-profile {
        max-width: 500px;
        margin: 20px auto;
        padding: 20px;
        border: 1px solid #555;
        border-radius: 5px;
        font-family: sans-serif;
    }

    .simple-profile h2 {
        border-bottom: 1px solid #555;
        padding-bottom: 10px;
    }

    .simple-profile label {
        display: block;
        margin-top: 15px;
        font-weight: bold;
    }

    .simple-profile input[type="text"] {
        width: 100%;
        padding: 8px;
        margin-top: 5px;
        border: 1px solid #777;
        border-radius: 3px;
    }

    .profile-img {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        object-fit: cover;
        border: 1px solid #ddd;
        margin-bottom: 10px;
    }

    .btn-group {
        margin-top: 20px;
        display: flex;
        align-items: center;
        gap: 12px;
        flex-wrap: wrap;
    }

    .btn-save,
    .btn-password,
    .btn-delete {
        display: inline-block;
        text-decoration: none;
        padding: 10px 16px;
        border-radius: 4px;
        font-size: 15px;
        cursor: pointer;
    }

    .btn-save {
        background: #444;
        color: #fff;
        border: none;
    }

    .btn-save:hover {
        background: #000;
    }

    .btn-password {
        background: #0058a3;
        color: #fff;
    }

    .btn-password:hover {
        background: #00457f;
    }

    .btn-delete {
        color: #f00e0e;
        background: transparent;
    }

    .btn-delete:hover {
        text-decoration: underline;
    }

    .err-text {
        color: red;
        font-size: 12px;
        display: block;
    }
</style>

<div class="simple-profile">
    <h2>My Profile</h2>

    <form method="post" enctype="multipart/form-data">
        <div style="text-align: center;">
            <label class="upload" style="cursor: pointer;">
                <?= html_file('photo', 'image/*', 'hidden') ?>
                <img src="/image/user_photos/<?= htmlspecialchars($photo ?: 'default.png') ?>" class="profile-img">
                <div style="font-size: 12px; color: #888;">Click to change</div>
            </label>
            <span class="err-text"><?= err('photo') ?></span>
        </div>

        <label for="email">Email Address:</label>
        <?= html_text('email', 'maxlength="100"') ?>
        <span class="err-text"><?= err('email') ?></span>

        <label for="name">Full Name:</label>
        <?= html_text('name', 'maxlength="100"') ?>
        <span class="err-text"><?= err('name') ?></span>

        <div class="btn-group">
            <button class="btn-save">Update Profile</button>
            <a href="change_password.php" class="btn-password">Change Password</a>
            <a href="delete.php" class="btn-delete" onclick="return confirm('Delete account?')">Delete Account</a>
        </div>
    </form>
</div>

<?php
include '../_foot.php';
?>